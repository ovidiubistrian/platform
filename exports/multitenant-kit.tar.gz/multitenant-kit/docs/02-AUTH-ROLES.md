# 02 — Auth & Role System (super-admin vs tenant-admin)

All auth primitives live in **`reference-code/backend/src/core/security.py`**.
Roles are plain strings on `User.role` — **no enum table**.

## Roles observed

| Role | Meaning |
|---|---|
| `super_admin` | Platform operator. Bypasses tenant filters; owns `/api/super-admin/*`. Superset of everything. |
| `tenant_admin` | Owner/admin of a single tenant. Default role on registration. |
| `manager`, `cashier`, `sales` | Scoped staff roles. |
| `housekeeper` | Housekeeping console only. |
| `waiter`, `cook` | Restaurant POS / KDS only (hard-scoped to one screen on the frontend). |
| `owner` (via `OWNER_EMAIL`) | Even narrower than super-admin — single-person routes; fails **closed** with 404. |

> `admin` / `superadmin` appear as **legacy frontend aliases** only. Normalize to
> `tenant_admin` / `super_admin` in a new app.

## JWT

`security.py`:
- `create_access_token(...)` / `decode_access_token(...)`; `SECRET_KEY` + `ALGORITHM` from
  `core/config.py`.
- Passwords via bcrypt/passlib: `verify_password`, `get_password_hash`.
- **Token types** distinguish surfaces so a customer token can't hit staff endpoints:
  `staff` (default), `customer` (`get_current_customer`), `pos_device`
  (`get_current_pos_or_staff_user`). Staff endpoints reject customer tokens.

The token payload (issued in `api/auth.py`) is:
```json
{ "sub": "<user_id>", "email": "...", "role": "tenant_admin", "tenant_id": "<tenant_id>", "exp": ... }
```
`get_current_user` loads the `User`; **the tenant is whatever that user belongs to** — the
client never chooses its tenant for authenticated calls.

## The dependency ladder (this is the core of the split)

FastAPI dependencies, each returns the `User` or raises:

| Dependency | Allows | On failure |
|---|---|---|
| `get_current_user` / `get_current_active_user` | any valid staff token | 401 |
| `require_super_admin` | `role == "super_admin"` | **403** |
| `require_tenant_admin` | `["super_admin", "tenant_admin"]` | 403 |
| `require_owner` | email == `OWNER_EMAIL` env | **404** (hides the route; fails closed) |
| `require_housekeeper` | housekeeper (+ admins) | 403 |
| `require_restaurant_waiter` / `require_restaurant_kitchen` | waiter/cook (+ admins) | 403 |
| `require_role(role)` | factory for any single role | 403 |

**Key invariant:** `super_admin` is a superset — `require_tenant_admin` admits it, and every
tenant-scoped query treats `role == "super_admin"` as "skip the tenant filter". Reproduce
this invariant exactly, or super-admin tooling breaks.

Usage is just `Depends(...)`:
```python
@router.post("/tenants", dependencies=[Depends(require_super_admin)])
def create_tenant(...): ...

@router.get("/units")
def list_units(current_user: User = Depends(require_tenant_admin), db=Depends(get_db)):
    q = db.query(Unit)
    if current_user.role != "super_admin":
        q = q.filter(Unit.tenant_id == current_user.tenant_id)
    ...
```

## Login / registration / session

`reference-code/backend/src/api/auth.py` + `services/auth_service.py`:
- `POST /api/auth/login` — validates credentials; optional **2FA** returns
  `{ requiresTwoFactor, sessionId }` instead of a token; otherwise issues the JWT.
- `POST /api/auth/register` — `AuthService.register_user` creates **user + tenant together**
  (the tenant-provisioning path — the new tenant starts on the Free/trial plan).
- `POST /api/auth/verify-two-factor`, `change-password` (clears `must_change_password`),
  `forgot/reset-password`, `verify-email`, `GET /api/auth/me`.

## Frontend enforcement

- `context/AuthContext.tsx` — on login/bootstrap stores `access_token` and sets
  `localStorage.tenant_id = user.role === 'super_admin' ? 'super_admin' : user.tenant_id`.
- `components/auth/ProtectedRoute.tsx` — `requireRole` prop; super-admin passes every gate;
  the `admin` gate also admits `tenant_admin`/`waiter`/`cook`; role mismatch redirects each
  role to its home console.
- `lib/api/client.ts` — request interceptor attaches `Authorization: Bearer <token>` and the
  `x-tenant-id` tracing header; a response interceptor handles 401→logout.

## Porting checklist

- [ ] `User.role` string column + the exact role vocabulary you need.
- [ ] JWT with `role` + `tenant_id` claims; short-lived access token.
- [ ] Reproduce the dependency ladder, **preserving the super_admin-is-superset rule**.
- [ ] Frontend: role→console routing + a client interceptor for the token.
- [ ] Decide 404-vs-403 policy for your most sensitive routes (`require_owner` chose 404).
