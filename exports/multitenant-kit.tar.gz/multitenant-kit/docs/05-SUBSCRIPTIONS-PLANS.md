# 05 — Subscriptions, Plans, Add-ons, Feature Gating

Three layers, in order of precedence:

```
PlanCatalog (marketing tier + limits)   ← what a plan grants
        │
        ├── tenant.plan_catalog_id       ← which plan this tenant is on
        │
        └── tenant.plan_overrides (JSONB) ← per-tenant exceptions (override wins)
                        │
                        ▼
            plan_limits.evaluate(...)     ← is this action allowed right now?
                        │
        access_control.evaluate(...)      ← is the tenant even allowed to log in / act?
```

## The models

### `PlanCatalog` — the source of truth (`models/plan_catalog.py`)
Public marketing tiers, managed at `/super-admin`. Key fields:
- `limits` (JSONB) — the caps (units, properties, admin_users, orders/month, …).
- `trial_days`.
- **Stripe sync:** `stripe_product_id`, `stripe_monthly_price_id`, `stripe_yearly_price_id`,
  `stripe_synced_at`.
- Companions `PlanCatalogFeature`, `PlanCatalogGlobalFeature` (feature bullet lists).

### `SubscriptionPlan` — legacy (`models/subscription_plan.py`)
Older Stripe-billed plans (`stripe_monthly_price_id`, `stripe_yearly_price_id`, `max_*`,
trial). Still referenced as a fallback in the subscribe flow. In a new app, **collapse this
into `PlanCatalog`** and drop `SubscriptionPlan`.

### `AddOnPackage` + `TenantAddOn` — (`models/addon_package.py`)
One-off / recurring add-ons on top of a plan.
- Types include `sms_pack`, `email_pack`, `business_email`, and `seo_booster` / `seo_care`
  (`SEO_ADDON_TYPES`).
- `TenantAddOn` (join) tracks `sms_remaining`, `email_remaining`, `expires_at`, `status`.
- Stripe fields `stripe_product_id`, `stripe_price_id`.
- Activation: `services/addon_service.py` — `grant` (sets `sms_remaining` from quantity),
  `renew_business_email`, credit consumption.

### Per-tenant subscription state (on `tenants`, see 01/07)
`plan_catalog_id`, `plan_overrides`, `subscription_plan` (legacy string),
`subscription_ends_at`, `free_plan_used_at`, `login_post_expiry_count`.

## Feature gating — `services/plan_limits.py`

This is the enforcement engine. `evaluate(db, tenant, metric) -> LimitVerdict`:
- `METRICS` map defines each metric and whether it's **soft** (warn) or **hard** (block):
  - soft: `units`, `properties`, `admin_users`, `tables`, `menu_products`
  - hard: `orders_per_month`, `growth_posts_per_month`, `sms_per_month`
- Resolves the cap as `plan_catalog.limits[metric]` **overridden by**
  `tenant.plan_overrides[metric]` (`_resolve_cap` — override always wins).
- Period counters come from `tenant_usage_counters` / `tenant.sms_monthly_used`;
  `increment_period(...)` bumps them.
- Exposed via `api/tenant_limits.py` → `GET /api/tenant/limits` (not copied; thin wrapper).

Call it before the gated action:
```python
verdict = plan_limits.evaluate(db, tenant, "units")
if verdict.blocked:      # hard metric over cap
    raise HTTPException(402, verdict.message)   # or surface the upsell
```
Frontend surfaces this with `PlanLimitsCard.tsx` + `PlanLimitUpsellModal.tsx`
(not copied — present in source).

## The billing access gate — `services/access_control.py`

Separate from limits: this decides whether a tenant may **use the app at all** when their
subscription has lapsed. `evaluate(db, tenant)` returns:

| Verdict | When | Frontend effect (`AccessGate.tsx`) |
|---|---|---|
| `allowed` | subscription valid, or gate disabled | app renders normally |
| `payment_required` | `subscription_ends_at` passed but postpones remain | redirect to SubscriptionPage |
| `blocked` | `status == "suspended"`, or postpones exhausted | full-screen lock |

- Feature-flagged by `system_configs.billing_settings.enforce_access_gate` (**default off** —
  ship it off, turn on when you're ready to enforce).
- `increment_postpone` (the "remind me later" counter, capped at `max_postpones`),
  `reset_post_expiry_counter` (on successful payment).
- Exposed at `GET /api/subscriptions/access-status`, `POST /api/subscriptions/postpone`,
  `/extension-request`.
- Frontend `components/common/AccessGate.tsx` polls it and **exempts** `super_admin`,
  `waiter`, `cook`.

## Cost budgets (used by AI — see 06) — `services/cost_limits.py`

A *second, orthogonal* budget system, per-metric cents. Used mainly to cap AI spend:
- `enforce_limit(db, tenant, metric="ai", cost_cents=...)` — hard-blocks with **HTTP 402**
  when the per-tenant budget is exceeded; **super-admins bypass**.
- Default `ai` budget 1000¢ (10 RON) in `DEFAULT_LIMITS`; per-tenant overrides in
  `tenant_cost_limits`; platform defaults in `system_configs.cost_limit_defaults`.
- Pricing table (`services/cost_pricing.py`) converts token usage → cents.

## Frontend map

**Tenant-admin:**
- `pages/admin/SubscriptionPage.tsx` — plan + add-ons; calls `lib/api/subscriptions.ts`
  (`getPlans/getCurrent/getAddOns/getMyAddOns/getAccessStatus/subscribe/buyAddOn/
  postponePayment/requestExtension/cancel`).
- `components/common/AccessGate.tsx` — the interstitial lock.

**Super-admin:**
- `pages/super-admin/PlanCatalogPage.tsx` — manage `PlanCatalog`.
- `pages/super-admin/SubscriptionPlansPage.tsx` — legacy plans + `sync-stripe`.
- `pages/super-admin/AddOnPackagesPage.tsx` — addon catalog + per-tenant assignment.
- `pages/super-admin/TenantsPage.tsx` — assign plan / product_type / restaurant_tier.

## Porting checklist

- [ ] One plans table (`PlanCatalog`) with a `limits` JSONB + Stripe price ids. Skip the
      legacy `SubscriptionPlan` split.
- [ ] `tenant.plan_catalog_id` + `plan_overrides` (JSONB) + `subscription_ends_at`.
- [ ] `plan_limits.evaluate` engine with a soft/hard metric map + usage counters table.
- [ ] `access_control.evaluate` gate, **feature-flagged and off by default**.
- [ ] (If you gate AI) the `cost_limits` cents budget + `cost_pricing` table.
- [ ] Add-ons only if you sell SMS/email/SEO packs — otherwise drop `AddOnPackage`.
