# 04 — Payments: Stripe + provider-agnostic orchestrator

There are **two payment domains, kept strictly separate**. Don't merge them:

| Domain | Who pays | Money goes to | Providers | Keys |
|---|---|---|---|---|
| **Guest checkout** | a tenant's customer (booking / restaurant order) | the **tenant** | Stripe **/ Netopia / BT iPay** | per-tenant, in `site_configs.*_config` JSON |
| **Platform subscription** | the **tenant** (as your customer) | **you** (platform) | Stripe only | global env `STRIPE_SECRET_KEY` |

Keeping them apart is the single most important design decision here — a tenant's Stripe
account must never receive your subscription money and vice-versa.

---

## Part 1 — Guest checkout: the provider-agnostic orchestrator

This is what lets each tenant pick their own PSP. Lives in
`reference-code/backend/src/services/payment_providers/` + `payment_orchestrator.py`.

### The abstraction

`payment_providers/base.py`:
```python
class PaymentProvider(ABC):
    def create_checkout_session(...) -> CheckoutSession: ...
    def verify_webhook(...) -> dict: ...
    def get_session_status(...) -> SessionStatus: ...
    def refund(...) -> ...: ...
```
Dataclasses `CheckoutSession`, `SessionStatus`; exception `PaymentProviderError`.
**Amounts are in minor units** (bani/cents), currency ISO.

Concrete providers (same interface):
- `stripe_provider.py` → `StripeProvider` — lazy `import stripe`;
  `stripe.checkout.Session.create(mode="payment", …)`, `stripe.Webhook.construct_event`,
  `stripe.Refund.create`. Keys validated by prefix (`pk_`/`sk_`/`whsec_`).
- `netopia.py`, `btipay.py` — **not copied** (Romania-specific, large). The `stripe_provider`
  is the template to implement any new PSP.

### The registry (per-tenant "is a provider configured?")

`payment_providers/registry.py`:
- `PROVIDER_KEYS = ("stripe", "netopia", "btipay")`.
- `_stripe_ready` / `_netopia_ready` / `_btipay_ready` read the tenant's
  `SiteConfig.{stripe,netopia,btipay}_config` JSON to decide "configured".
- `get_configured_provider_keys(tenant_id, db)` — **single source of truth** for whether to
  show "Card online".
- `get_provider(tenant_id, key, db)` — instantiates the right provider from that tenant's
  JSON config.

### The orchestrator (uniform entrypoint)

`payment_orchestrator.py` — provider selection order:
**explicit key → `SiteConfig.preferred_payment_provider` → Stripe → first configured.**
- `create_payment_session(...)` — the one call bookings / restaurant orders / payment links
  all use.
- `build_order_ref` / `parse_order_ref` — prefixes `bk_` (booking), `ro_`/`rt_` (restaurant
  order), `fb_` (facility) let a **single webhook** route a completed payment back to the
  right handler.

### Guest webhooks

- **Redirect PSPs (Netopia + BT iPay):** `api/payment_webhooks.py` →
  `POST /api/webhooks/payment/{provider}/{tenant_id}`. Verifies via
  `provider.verify_webhook`, parses `order_ref`, dispatches to
  `_complete_booking` / `_complete_restaurant_order` / `_complete_facility_booking`.
- **Stripe (guest bookings):** `api/booking_stripe_webhook.py` →
  `POST /api/webhooks/booking-stripe/{tenant_id}`. Uses the **tenant's own**
  `stripe_config.webhookSecret` via `services/tenant_stripe.py.get_tenant_stripe_config`.

### `online_payment_enabled` — the one computed flag

Computed in exactly one place (in the source, `api/tenant.py`):
```python
payment_providers = get_configured_provider_keys(tenant.id, db)
online_payment_enabled = bool(payment_providers) and site_config.accept_card_online
```
So "card online" requires **both** the owner's toggle **and** ≥1 configured provider.
Toggles `accept_card_online` / `accept_bank_transfer` live on `site_configs` (see 07) and are
edited in `frontend/.../settings/BillingPaymentPage.tsx` (`handleToggleMethod`, enforces
≥1 method active; `handleSavePreferred` sets `preferred_payment_provider`).

---

## Part 2 — Platform subscriptions (Stripe, global)

This is how **you** charge tenants. `reference-code/backend/src/api/webhooks.py` uses the
**global** `STRIPE_WEBHOOK_SECRET` and handles:

| Stripe event | Handler | Effect |
|---|---|---|
| `checkout.session.completed` | `_handle_checkout_session_completed` | Stamps `tenant.subscription_plan` / `plan_catalog_id` / `subscription_ends_at` |
| `invoice.payment_succeeded` | `_handle_invoice_payment_succeeded` | Renewal → pushes `subscription_ends_at` forward |
| addon `checkout.session.completed` | `_handle_addon_checkout_completed` | Activates a `TenantAddOn` |
| addon `invoice.payment_succeeded` | `_handle_addon_invoice_payment_succeeded` | Renews an addon |

It also emits a **platform invoice** for the subscription payment
(`_emit_platform_oblio_invoice`) — that's Oblio-specific; strip it if you don't invoice via
Oblio (see 08).

### Subscribe flow

`reference-code/backend/src/api/subscriptions.py` (`/api/subscriptions`):
- `GET ""` — current subscription.
- `POST ""` — creates a Stripe Checkout in **`mode="subscription"`** using the
  `stripe_*_price_id` from the plan catalog (or legacy `SubscriptionPlan`). Guards the
  one-time-Free rule.
- `/cancel`, `PATCH`, `/plans`, `/addons`, `/addons/checkout` (payment vs subscription mode),
  `/addons/mine`, `/access-status`, `/postpone`, `/extension-request`.

### Plan ↔ Stripe sync

`services/plan_catalog_stripe_sync.py` — `sync_plan` / `sync_all` create/modify
`stripe.Product` + `stripe.Price` from your `PlanCatalog` rows and write back
`stripe_product_id` / `stripe_monthly_price_id` / `stripe_yearly_price_id`. Triggered from
super-admin (`SubscriptionPlansPage.tsx` → `/api/super-admin/subscription-plans/sync-stripe`).

### Stripe Connect (optional)

`api/stripe_oauth.py` + `services/stripe_connect.py` (not copied — thin) let a tenant connect
their **own** Stripe account via OAuth for guest checkout, instead of pasting keys. `/start`,
`/callback`, `/disconnect`, `/status`, `/test-connection`.

---

## End-to-end flows (memorize these two)

**Guest pays for a booking:**
```
caller → payment_orchestrator.create_payment_session
       → registry.get_provider(tenant, key)   # reads SiteConfig.*_config
       → provider.create_checkout_session      # Stripe/Netopia/BT iPay
       → customer pays →
         Stripe:   POST /api/webhooks/booking-stripe/{tenant_id}   (tenant webhook secret)
         redirect: POST /api/webhooks/payment/{provider}/{tenant_id}
       → parse order_ref → _complete_booking → booking marked paid
```

**Tenant subscribes to your platform:**
```
SubscriptionPage → POST /api/subscriptions (mode=subscription, price_id from PlanCatalog)
                 → Stripe Checkout → tenant pays →
                   POST /api/webhooks/stripe (GLOBAL secret)
                 → _handle_checkout_session_completed
                 → tenant.plan_catalog_id + subscription_ends_at stamped
                 → limits (05) now reflect the new plan
```

## Config / env

`core/config.py`: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` (**platform** keys).
Tenant Stripe keys live in `site_configs.stripe_config` JSON, never in env.
Audit trail: `models/payment_provider_log.py` + `services/payment_audit_logger.py`
(not copied; small).
