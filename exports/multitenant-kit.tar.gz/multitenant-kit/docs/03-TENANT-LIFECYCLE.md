# 03 — Super-Admin Fleet Control (tenant lifecycle)

The whole super-admin surface is mounted under **`/api/super-admin/*`** and every endpoint
depends on `require_super_admin`. Primary router:
**`reference-code/backend/src/api/super_admin.py`**.

## The tenant state machine

```
                 create
                   │
                   ▼
   ┌────────── trial ──────────┐
   │            │              │
   │        activate       (never pays)
   │            │              │
   ▼            ▼              ▼
suspended ◄─► active      subscription_ends_at passes
   │            │              │
   │            └──────────────┘
   │                   │
   │            soft-delete (DELETE)     → deleted_at set, is_active=False
   │                   │
   │              ┌────┴─────┐
   │           restore     purge
   │          (30-day       (permanent,
   │           window)       raw cascade DELETE)
   ▼
(status = "suspended", blocked at login by access gate)
```

## Endpoints (all `Depends(require_super_admin)`)

| Method + path | What it does |
|---|---|
| `GET /tenants` | List fleet. Hides soft-deleted unless `?include_deleted=true`. Enriches each row with owner email + plan-catalog name. |
| `GET /tenants/{id}` | Single tenant detail. |
| `POST /tenants` | Create. Validates slug/status/product_type/restaurant_tier; stamps the one-time-Free window. |
| `PATCH /tenants/{id}` | Update: suspend via `status`, assign plan (`plan_catalog_id`), `plan_overrides`, `product_type`, `restaurant_tier`. Enforces one-time-Free. |
| `DELETE /tenants/{id}` | **Soft-delete** — sets `deleted_at` + `is_active=False`. **Refuses (409) if a `custom_domain` is still attached.** Idempotent. |
| `POST /tenants/{id}/restore` | Clears `deleted_at`, re-activates. |
| `DELETE /tenants/{id}/purge` | **Permanent** raw-SQL `DELETE` relying on Postgres FK cascade. Only allowed if already soft-deleted. |
| `PUT /tenants/{id}/sms` | Per-tenant SMS provisioning. |
| `GET/PATCH /domain-requests` | Custom-domain request queue. |
| `GET /customers`, `GET /tenant-admins`, `GET/POST/PUT/DELETE /users` | Fleet-wide user management. |
| `subscription-plans` CRUD + `sync-stripe` | Legacy plan management (see 05). |
| `sms-config`, `anaf-config`, `mailgun-config`, `smtp-config`, `platform-email-config`, `stats`, `system/health`, `ai-config` | Platform-wide config. |

## Why soft-delete → restore → purge (copy this pattern)

- **Soft-delete** (`deleted_at` timestamp) means an accidental deletion is recoverable and
  the row still satisfies FKs while you decide. Public + admin queries must filter
  `deleted_at IS NULL`.
- **The custom-domain guard** on delete is important: a live custom domain pointing at a
  deleted tenant would 404 the customer's website. Force the operator to detach the domain
  first (the 409).
- **Purge** is the only path that actually frees the slug/domain and drops data. It runs a
  raw `DELETE FROM tenants WHERE id=...` and leans on `ON DELETE CASCADE` on every child FK —
  which is *why* every owned table must declare the cascade (see 01/07).
- A cron (`purge-deleted-tenants.sh` in the source, not in this kit) purges tenants whose
  `deleted_at` is older than 30 days. Reproduce as a scheduled job.

## No impersonation

There is **no "log in as tenant" impersonation feature** (grepped `impersonat*` → 0 hits).
Super-admin instead:
1. reads any tenant's data through the `role == "super_admin"` bypass on normal endpoints, and
2. manages tenant staff via `/super-admin/tenants/:id/staff`.

If you want impersonation in the new app, the clean way is a super-admin-only endpoint that
mints a short-lived token with the **target** `tenant_id` and an `impersonated_by` claim
(audit it) — but that's an addition, not part of this export.

## Frontend

`reference-code/frontend/src/pages/super-admin/TenantsPage.tsx` is the fleet console:
list + create/edit modal + suspend + soft-delete/restore/purge + plan/product_type/
restaurant_tier assignment. Routing to the whole console is `router.tsx` under
`/super-admin` guarded by `SuperAdminLayout.tsx`.

## Access gate (the runtime consequence of `status`/`subscription_ends_at`)

Separate from RBAC, `services/access_control.py` `evaluate(db, tenant)` returns
`allowed | payment_required | blocked` based on `subscription_ends_at`,
`login_post_expiry_count` vs `max_postpones`, and `status == "suspended"`. It's
feature-flagged by `system_configs.billing_settings.enforce_access_gate` (default **off**).
Fully documented in **05**.
