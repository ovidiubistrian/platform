# 07 — Consolidated Data Model

The tables the kit needs, distilled to what matters. Source models are under
`reference-code/backend/src/models/`. Types are shown as generic SQL; the source uses
Postgres (`JSONB`, `ARRAY`). All IDs are app-generated strings (CUID/UUID), not serial ints.

> **Multilanguage note:** `site_configs` carries `*_translations` JSON columns
> (`site_name_translations`, `site_description_translations`, `legal_pages_content`). Those
> belong to the translations system you are **not** touching — leave them in your target
> app's existing schema and ignore them here.

---

## `tenants` — the spine (`models/tenant.py`)

The columns that matter for this kit (the source has ~50; onboarding/SMS/email
provisioning columns are omitted as app-specific):

```sql
CREATE TABLE tenants (
  id                       TEXT PRIMARY KEY,
  name                     TEXT NOT NULL,
  slug                     TEXT NOT NULL UNIQUE,          -- marketplace path + public resolution
  status                   TEXT NOT NULL DEFAULT 'trial', -- trial | active | suspended
  is_active                BOOLEAN NOT NULL DEFAULT true,

  -- routing / public site
  custom_domain            TEXT UNIQUE,
  subdomain                TEXT UNIQUE,
  is_custom_domain_active  BOOLEAN NOT NULL DEFAULT false,
  is_subdomain_active      BOOLEAN NOT NULL DEFAULT true,
  dns_configured           BOOLEAN NOT NULL DEFAULT false,

  -- subscription state
  subscription_plan        TEXT NOT NULL DEFAULT 'free',  -- LEGACY string; keep only for back-compat
  plan_catalog_id          TEXT REFERENCES plan_catalog(id) ON DELETE SET NULL,  -- SOURCE OF TRUTH
  plan_overrides           JSONB NOT NULL DEFAULT '{}',   -- per-tenant caps; keys here beat the plan
  subscription_ends_at     TIMESTAMP,
  free_plan_used_at        TIMESTAMP,                     -- set once; blocks re-downgrade to Free
  login_post_expiry_count  INTEGER NOT NULL DEFAULT 0,    -- "pay or postpone" counter (access gate)
  suspended_reason         TEXT,

  -- legacy hard caps (superseded by plan_catalog.limits; keep if you want a floor)
  max_properties           INTEGER NOT NULL DEFAULT 1,
  max_units                INTEGER NOT NULL DEFAULT 5,
  max_bookings             INTEGER NOT NULL DEFAULT 100,

  -- product shape (drives UI/feature set, NOT billing)
  product_type             VARCHAR(20) NOT NULL DEFAULT 'accommodation', -- accommodation|restaurant|both
  restaurant_tier          VARCHAR(20) NOT NULL DEFAULT 'full',          -- full|menu_site

  -- demo tenants
  is_demo                  BOOLEAN NOT NULL DEFAULT false,
  demo_expires_at          TIMESTAMP,

  created_at               TIMESTAMP NOT NULL DEFAULT now(),
  updated_at               TIMESTAMP NOT NULL DEFAULT now(),
  deleted_at               TIMESTAMP     -- SOFT DELETE: NULL=live; set=trashed (30d purge window)
);
CREATE INDEX ix_tenants_deleted_at ON tenants(deleted_at);
```

Every tenant-owned table repeats this FK (**cascade is mandatory** — purge relies on it):
```sql
tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE
```

## `users` (`models/user.py`)

```sql
CREATE TABLE users (
  id                 TEXT PRIMARY KEY,
  name               TEXT,
  email              TEXT NOT NULL UNIQUE,
  password           TEXT NOT NULL,                       -- bcrypt hash
  role               TEXT NOT NULL DEFAULT 'tenant_admin',-- super_admin|tenant_admin|manager|...
  tenant_id          TEXT REFERENCES tenants(id) ON DELETE CASCADE,  -- NULL for super_admin
  is_active          BOOLEAN NOT NULL DEFAULT true,
  email_verified     BOOLEAN NOT NULL DEFAULT false,
  two_factor_enabled BOOLEAN NOT NULL DEFAULT false,
  must_change_password BOOLEAN NOT NULL DEFAULT false,
  -- + email_verification_token/expires, reset_password_token/expires, last_login_at
  created_at         TIMESTAMP NOT NULL DEFAULT now(),
  updated_at         TIMESTAMP NOT NULL DEFAULT now()
);
```
> Note: a **super_admin's `tenant_id` is NULL** — they don't belong to a tenant.

## `plan_catalog` — the plans (`models/plan_catalog.py`)

```sql
CREATE TABLE plan_catalog (
  id                       TEXT PRIMARY KEY,
  slug                     TEXT NOT NULL UNIQUE,
  name                     TEXT NOT NULL,
  short_description        TEXT,
  long_description         TEXT,
  monthly_price            NUMERIC(10,2) NOT NULL DEFAULT 0,
  annual_price             NUMERIC(10,2) NOT NULL DEFAULT 0,
  annual_discount_percent  INTEGER NOT NULL DEFAULT 0,
  currency                 TEXT NOT NULL DEFAULT 'RON',
  is_active                BOOLEAN NOT NULL DEFAULT true,
  is_public                BOOLEAN NOT NULL DEFAULT true,
  is_recommended           BOOLEAN NOT NULL DEFAULT false,
  sort_order               INTEGER NOT NULL DEFAULT 0,
  limits                   JSONB NOT NULL DEFAULT '{}',   -- {units, properties, orders_per_month, ...}
  trial_days               INTEGER NOT NULL DEFAULT 0,
  -- Stripe sync (written by sync-stripe):
  stripe_product_id        TEXT,
  stripe_monthly_price_id  TEXT,
  stripe_yearly_price_id   TEXT,
  stripe_synced_at         TIMESTAMP,
  created_at               TIMESTAMP NOT NULL DEFAULT now(),
  updated_at               TIMESTAMP NOT NULL DEFAULT now()
);
-- + plan_catalog_features (bullet points), plan_catalog_global_features (shared bullets)
```
(Marketing/presentation columns — `badge_text`, `accent_color`, `show_in_carousel`, … — omitted.)

## `addon_packages` + `tenant_addons` (`models/addon_package.py`)

```sql
CREATE TABLE addon_packages (
  id                TEXT PRIMARY KEY,
  type              TEXT NOT NULL,       -- sms_pack|email_pack|business_email|seo_booster|seo_care
  name              TEXT NOT NULL,
  price             REAL NOT NULL DEFAULT 0,
  currency          TEXT NOT NULL DEFAULT 'RON',
  billing_cycle     TEXT NOT NULL DEFAULT 'one_time',  -- one_time|monthly
  quantity          INTEGER,             -- credits granted (NULL = unlimited)
  is_active         BOOLEAN NOT NULL DEFAULT false,     -- super-admin visibility toggle
  stripe_product_id TEXT,
  stripe_price_id   TEXT,
  sort_order        INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE tenant_addons (
  id               TEXT PRIMARY KEY,
  tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  addon_package_id TEXT NOT NULL REFERENCES addon_packages(id) ON DELETE RESTRICT,
  status           TEXT NOT NULL DEFAULT 'pending',      -- pending|active|cancelled|expired
  sms_remaining    INTEGER,
  email_remaining  INTEGER,
  activated_at     TIMESTAMP,
  expires_at       TIMESTAMP
);
```

## `site_configs` — the per-tenant payment/billing knobs (`models/site_config.py`)

Only the columns this kit cares about (the table is large — theme/hero/contact/SEO columns omitted):

```sql
-- one row per tenant (tenant_id UNIQUE)
billing_system              TEXT DEFAULT 'proforma',  -- proforma|oblio|smartbill|fgo (routing, see below)
-- guest-payment provider configs (JSON blobs of keys):
stripe_config               TEXT,   -- {publishableKey, secretKey, webhookSecret}
netopia_config              TEXT,
btipay_config               TEXT,
preferred_payment_provider  TEXT,   -- stripe|netopia|btipay (NULL => Stripe, then first configured)
-- payment-method acceptance toggles:
accept_card_online          BOOLEAN NOT NULL DEFAULT true,
accept_bank_transfer        BOOLEAN NOT NULL DEFAULT true,
-- legacy invoicing blobs (superseded by billing_integrations table):
oblio_config / smartbill_config / fgo_config  TEXT
```

## `billing_integrations` (+ idempotency) (`models/billing_integration.py`)

Per-tenant invoicing credentials, one row per (tenant, provider). Encrypted secret columns
per provider (oblio/smartbill/fgo), shared `selected_company_cif` + `default_invoice_series`,
`enabled`/status/audit. Plus `billing_invoice_idempotency` mapping an internal key → the
provider's series/number so a retry never double-issues an invoice. See **04/08** — this is
the "which invoicing provider does this tenant use" routing layer, not a full invoicing system.

## Supporting platform tables (not full models here, but referenced)

| Table | Holds | Used by |
|---|---|---|
| `tenant_usage_counters` | period counters (orders/month, sms/month, …) | `plan_limits.evaluate` |
| `tenant_cost_limits` | per-tenant cents budgets (incl. metric `ai`) | `cost_limits.enforce_limit` |
| `growth_ai_generation_usage` | AI usage ledger (model, tokens, cost) | `ai_usage_logger` |
| `system_configs` (key/value JSON rows) | `billing_settings` (access-gate flag), `cost_pricing`, `cost_limit_defaults`, platform email/SMS config | access gate, cost pricing |
| `subscription_plans` | **legacy** Stripe plans (fold into `plan_catalog`) | subscribe fallback |

## Minimal greenfield schema (if you're starting fresh)

You can ship the whole kit with just these tables:
`tenants`, `users`, `plan_catalog`, `tenant_usage_counters`, `system_configs`, and — only if
you sell them — `addon_packages`/`tenant_addons`, `tenant_cost_limits` (AI budgets),
`billing_integrations` (invoicing). `subscription_plans` and the per-tenant `site_configs`
payment JSON can be simplified into a single `tenant_payment_config` table if you only ever
support Stripe.
