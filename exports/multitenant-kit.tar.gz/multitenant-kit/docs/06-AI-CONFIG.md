# 06 — AI / ChatGPT (OpenAI) configuration

The design goal: **one place to configure the OpenAI key**, every feature resolves it
centrally, and **per-tenant spend is capped** by a cents budget with a usage ledger.

## 1. Central key resolution — `core/ai_config.py`

```
get_openai_api_key()  →  saved super-admin config  →  OPENAI_API_KEY env  (fallback)
```
- Config is persisted as a **JSON file**, not the DB: `backend/data/ai_config.json`
  (overridable via `AI_CONFIG_FILE` env). `read_ai_config()` / `write_ai_config()`.
- Default config shape:
  ```json
  {
    "openaiApiKey": "",
    "enabled": true,
    "features": { "textImprovement": true, "autoTranslation": true, "contentGeneration": true },
    "limits":   { "requestsPerDay": 0, "requestsPerTenant": 0 }
  }
  ```
- ⚠️ **In a new app, move this into your secrets store / DB** rather than a file on disk —
  the file approach is a 360booking wart (see 08). The resolver contract
  (`get_openai_api_key()` = saved config first, env fallback) is what to keep.

## 2. Shared client — `services/ai_client.py`

Deliberately **avoids the `openai` SDK** — raw `httpx` calls, so it's trivial to port.
- `chat_completion(...)` → `POST api.openai.com/v1/chat/completions`
- `embed_texts(...)` → `POST /v1/embeddings`
- `DEFAULT_CHAT_MODEL = "gpt-4o-mini"`, `DEFAULT_EMBED_MODEL = "text-embedding-3-small"`.
- Raises `AIClientError` if no key.

> Model recommendation for a fresh build: the newest models are the **Claude 5 family,
> Opus 4.8, Haiku 4.5**. If you stay on OpenAI, `gpt-4o-mini` is the cheap default and
> `gpt-4o` for higher-quality generation — but the client is provider-agnostic enough that
> you can point it at any chat-completions-compatible endpoint.

## 3. Per-tenant AI settings = a **cost budget**, not prompts

There is **no per-tenant prompt/model override table**. The only per-tenant knob is spend:
- `services/cost_limits.py` — metric `"ai"` in cents; `enforce_limit(..., metric="ai")`
  hard-blocks with **HTTP 402** when exceeded; **super-admins bypass**. Default 1000¢ (10 RON);
  per-tenant overrides in `tenant_cost_limits`; platform default in
  `system_configs.cost_limit_defaults`.
- `services/cost_pricing.py` — `DEFAULT_PRICING["openai_models"]` (gpt-4o-mini / gpt-4o /
  gpt-3.5-turbo / gpt-4-turbo rates), stored in `system_configs.cost_pricing`
  (super-admin editable); `compute_openai_cost_cents(model, prompt_tokens, completion_tokens)`.
- `services/ai_usage_logger.py` — `log_ai_usage(...)` writes a `growth_ai_generation_usage`
  row (model, tokens, cost) after each call.

**The standard call sandwich (reproduce this):**
```python
enforce_limit(db, tenant, metric="ai", estimated_cost_cents=est)   # 402 if over budget
resp   = chat_completion(messages, model="gpt-4o-mini")            # raw httpx
cents  = compute_openai_cost_cents("gpt-4o-mini", resp.prompt_tokens, resp.completion_tokens)
log_ai_usage(db, tenant, model="gpt-4o-mini", cost_cents=cents, ...)
```

## 4. Feature gating

- AI features are **not** gated by a per-plan boolean in general — access is by
  role/tenant-ownership (403 cross-tenant guards) plus the shared `ai` cents budget.
- The **one** feature with tier semantics is Restaurant Growth AI (`api/growth_center.py`
  `PLAN_LIMITS`: basic/pro/premium/assisted with text+image quotas). Currently **hard-coded
  to `basic`** pending a `tenants.growth_plan` column — a known TODO in the source.
- Marketing capability cards ("SEO Booster", "Blog AI", "Îmbunătățire cu AI") are surfaced,
  not enforced, via `super_admin_visibility_features`.

## 5. Where OpenAI is actually called (feature inventory)

You will **not** need most of these — they're 360booking's product features. Listed so you
know what to keep vs drop:

| Feature | Module | Keep in a generic kit? |
|---|---|---|
| Generic text improve / generate / location copy | `api/ai.py` (inline httpx, gpt-3.5/4o-mini) | maybe — it's the "AI writing assistant" |
| SEO content generation | `services/seo_content/` (gpt-4o-mini, gpt-4o for FAQ) | product-specific — drop unless you do SEO |
| Blog article pipeline | `services/blog/` (gpt-4o) | product-specific — drop |
| Demo builder text | `services/demo_builder/text_gen.py` | product-specific — drop |
| Restaurant Growth AI | `services/growth_ai_text.py`, `growth_ai_image.py` | product-specific — drop |
| Support chatbot + RAG | `services/support_ai.py`, `services/rag.py` | keep if you want in-app support AI |

> These feature modules are **not copied** into `reference-code/` (they're app-specific and
> large). What's copied is the **reusable core**: `ai_config.py`, `ai_client.py`,
> `ai_usage_logger.py`, `cost_limits.py`, `cost_pricing.py`.

## 6. Frontend

**Super-admin — the OpenAI key config UI** is
`pages/super-admin/ConfigurationsPage.tsx`, tab `{ id: 'ai', name: 'AI & ChatGPT' }`:
`openaiApiKey` input + `enabled` toggle + test-connection button.
- API wrapper `lib/api/configurations.ts`: `getAiConfig` → `GET /api/super-admin/ai-config`,
  `updateAiConfig` → `PUT`, `testAiConnection` → `POST /api/super-admin/ai-config/test`.
- Backend handlers: `api/super_admin.py` (ai-config get/put/test).

> ⚠️ `ConfigurationsPage.tsx` also contains a **"Traducere automată cu ChatGPT"**
> (auto-translation) toggle. That belongs to the multilanguage system you said not to touch —
> **delete that toggle from the port**; keep only the key + enabled + test.

Cost/usage dashboards: `pages/super-admin/CostDashboardPage.tsx` (not copied),
tenant-side `pages/admin/restaurant/growth/AISettingsPage.tsx`.

## Porting checklist

- [ ] `get_openai_api_key()` resolver (saved config → env), but store the key in your
      secrets/DB, not a JSON file.
- [ ] `ai_client` thin httpx wrapper (or your own SDK call).
- [ ] `cost_limits` cents budget (metric `"ai"`, 402 on over-budget, super-admin bypass) +
      `cost_pricing` rate table + `ai_usage_logger` ledger.
- [ ] Super-admin key-config screen (key + enabled + test-connection). **Drop the
      auto-translate toggle.**
- [ ] Drop all the product-specific feature modules (SEO/blog/demo/growth) unless you want them.
