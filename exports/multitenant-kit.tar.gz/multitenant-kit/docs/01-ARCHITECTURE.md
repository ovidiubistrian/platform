# 01 — Multi-Tenant Architecture

## The model: shared schema, `tenant_id` on every owned row

This is a **shared-database, shared-schema** multi-tenancy (the cheapest and most common
SaaS model). There is one Postgres database; every tenant-owned table carries a
`tenant_id` FK to `tenants.id` with `ON DELETE CASCADE`. There is **no schema-per-tenant
and no row-level-security** — isolation is enforced in application code.

- Tenant model: `reference-code/backend/src/models/tenant.py` → `class Tenant(Base)`,
  `__tablename__ = "tenants"`.
- Every owned model (users, properties, bookings, invoices, …) has
  `tenant_id = Column(ForeignKey("tenants.id", ondelete="CASCADE"))`. See
  `models/user.py` for the pattern.

### Key `tenants` columns (routing, lifecycle, subscription)

| Group | Columns | Purpose |
|---|---|---|
| Identity / routing | `id` (str PK), `slug` (unique), `custom_domain` (unique), `subdomain` (unique), `is_custom_domain_active`, `is_subdomain_active`, `dns_configured` | Resolve which tenant a public request belongs to |
| Lifecycle | `status` (`trial`/`active`/`suspended`), `is_active`, `deleted_at` (soft-delete stamp), `suspended_reason`, `is_demo`/`demo_expires_at` | Fleet state machine (see 03) |
| Subscription | `subscription_plan` (legacy string), `plan_catalog_id` (FK, **source of truth**), `plan_overrides` (JSONB), `subscription_ends_at`, `free_plan_used_at`, `max_properties`/`max_units`/`max_bookings` | Billing state (see 05) |
| Access gate | `login_post_expiry_count` | "Pay or postpone" counter (see 05) |
| Product shape | `product_type` (`accommodation`/`restaurant`/`both`), `restaurant_tier` (`full`/`menu_site`) | Which feature-set/UI the tenant sees |

The full annotated column list is in **07-DATA-MODEL**.

---

## Request-time tenant resolution — two paths

There is **deliberately no global "current tenant" middleware that restricts data**.
Isolation is split by who is calling:

### A. Authenticated (admin/staff) requests → scoped by the *user's* `tenant_id`

The JWT carries `sub`, `email`, `role`, `tenant_id`
(issued in `backend/src/api/auth.py`). `get_current_user`
(`backend/src/core/security.py`) rehydrates the `User` row. Every tenant-scoped query then
manually filters:

```python
q = db.query(Unit).filter(Unit.tenant_id == current_user.tenant_id)
```

Super-admins are the escape hatch — the same endpoints allow cross-tenant access via an
explicit check:

```python
if current_user.role != "super_admin":
    q = q.filter(Model.tenant_id == current_user.tenant_id)
```

> **Design note / risk:** because isolation is *manual per query*, every new tenant-scoped
> endpoint must remember to filter. See **08-ADAPTATION-GUIDE** for how to harden this with
> a base query helper or SQLAlchemy event so you don't rely on discipline.

### B. Public (unauthenticated) requests → scoped by slug/domain

Public site/booking endpoints resolve the tenant from a `tenant_slug` query arg or the
`Host` header:
- `GET /api/tenant/by-domain` matches on `slug`, `custom_domain` (incl. `www.`→apex), or
  `subdomain`, and 404s inactive/soft-deleted tenants. (In 360booking this lives in
  `api/tenant.py`; not copied here because it's coupled to the public site — but the
  resolution logic is small and documented in 08.)

### C. Tracing-only resolver (NOT authorization)

`backend/src/core/tenant_resolver.py` + `backend/src/middleware/tracing.py` compute an
"effective tenant" string purely for **structured logging** (priority:
`request.state` → `X-Tenant-Id` header → path `/api/super-admin`→`"super_admin"` → JWT →
query `tenant_slug`/`domain` → host subdomain). The frontend sends `x-tenant-id` from
`localStorage` (`lib/api/client.ts`), which is `"super_admin"` for super-admins.

⚠️ **This header does not grant or restrict access.** Authorization is always
role-dependency + `tenant_id` filtering (path A). Treat the header as telemetry only, and
never trust a client-supplied `x-tenant-id` for data scoping.

---

## The frontend mirror

The two consoles are separated three times over (defense in depth):

1. **Route guard** — `frontend/src/components/auth/ProtectedRoute.tsx` `requireRole`
   (`/admin` → `"admin"`, `/super-admin` → `"super_admin"`). See `router.tsx`.
2. **Layout guard** — `SuperAdminLayout.tsx` redirects any non-super-admin;
   `AdminLayout.tsx` admits `tenant_admin`/`admin`/`super_admin` and hard-scopes
   restaurant staff (`waiter`→POS, `cook`→KDS).
3. **Billing gate** — `AccessGate.tsx` polls `/api/subscriptions/access-status` and locks
   tenant-admins whose subscription lapsed (exempts super_admin/waiter/cook). See 05.

`AuthContext.tsx` is where login stores the token and derives `localStorage.tenant_id`
(`"super_admin"` or the real id).

---

## One-paragraph mental model

> A single DB. One `tenants` row per customer. Users belong to a tenant and carry a role in
> their JWT. Tenant-scoped endpoints filter by the caller's `tenant_id`; super-admin bypasses
> that filter and additionally owns a `/api/super-admin/*` surface to manage the whole fleet.
> Public visitors are mapped to a tenant by domain/slug. Everything else — payments, plans,
> AI — hangs off the `tenants` row.
