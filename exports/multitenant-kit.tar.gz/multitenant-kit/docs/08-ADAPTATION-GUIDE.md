# 08 — Adaptation Guide (how to rewire this into another app)

The `reference-code/` files are copied **verbatim** from 360booking, so they still import
360booking internals (`from src.models.booking`, `from src.api.translations`, …). This doc
tells you exactly what glue each layer needs, what's safe to drop, and which files are
"drop-in" vs "reference-only".

## Runtime dependencies

**Backend (FastAPI):** `sqlalchemy`, `fastapi`, `pydantic`, `python-jose[cryptography]`
(JWT), `passlib`/`bcrypt` (passwords), `httpx` (AI client + BT iPay), `stripe` (payments).
**Frontend (React):** `react`, `react-router-dom`, `axios`, your component/UI stack.

## The 4 internal glue modules you must provide

Every exported backend file assumes these exist. Provide equivalents first:

| 360booking module | What it is | Your equivalent |
|---|---|---|
| `src.db.base.Base` | SQLAlchemy declarative base | your `Base` |
| `src.db.session.get_db` | FastAPI DB-session dependency | your `get_db` |
| `src.core.config` | settings (`STRIPE_SECRET_KEY`, `SECRET_KEY`, `ALGORITHM`, `OPENAI_API_KEY`, base URLs) | your settings object |
| `src.core.security` | JWT + password + the dependency ladder | **copy as-is** (02) — it's the least coupled |

## Coupling map — per layer

### ✅ Drop-in (copy, fix only the 4 glue imports above)
- `core/security.py`, `core/tenant_resolver.py`, `middleware/tracing.py`
- `core/ai_config.py`, `services/ai_client.py`, `services/cost_pricing.py`
- `services/payment_providers/base.py`, `stripe_provider.py`
- `models/tenant.py`, `models/user.py`, `models/plan_catalog.py`,
  `models/subscription_plan.py`, `models/addon_package.py`, `models/billing_integration.py`
  — (trim columns you don't need; the models drag in **no** cross-model imports except FKs)

### 🔶 Light rewiring (a few app-specific imports to stub or delete)
- `services/payment_providers/registry.py` — reads `SiteConfig.*_config`; point it at your
  own per-tenant payment-config storage.
- `services/payment_orchestrator.py` — imports the concrete providers; keep only the ones you
  ship (Stripe). Delete Netopia/BT iPay branches.
- `services/plan_limits.py`, `services/cost_limits.py`, `services/access_control.py` —
  read `system_configs` / `tenant_usage_counters` / `tenant_cost_limits`; wire to your tables.
- `services/ai_usage_logger.py` — writes `growth_ai_generation_usage`; point at your ledger.
- `services/plan_catalog_stripe_sync.py`, `services/addon_service.py`,
  `services/tenant_stripe.py` — mostly self-contained; check their `src.` imports.
- `api/auth.py`, `api/subscriptions.py` — routers; they import `notification_service`,
  `sms_service`, `invoice_service` for side effects (welcome email, etc.). Stub those to
  no-ops to start.

### 🔴 Reference-only (read, don't drop in — heavily coupled)
- **`api/super_admin.py`** — the biggest file; imports blog, SMS, ANAF, Mailgun, SMTP config
  models, translations, SEO onboarding, etc. Use it as the **spec** for your super-admin
  endpoints (tenant CRUD + soft-delete/restore/purge in 03) and re-implement the tenant
  lifecycle handlers only. Don't try to import it wholesale.
- **`api/webhooks.py`** — platform-subscription Stripe webhook. Copy the 4 handler bodies
  (03/04) but drop `_emit_platform_oblio_invoice` unless you invoice via Oblio.
- **`api/booking_stripe_webhook.py`, `api/payment_webhooks.py`** — guest-checkout webhooks;
  they call `_complete_booking`/`_complete_restaurant_order` (360booking domain). Keep the
  verify+route skeleton, replace the completion handlers with your domain's.
- **`api/billing.py`** — Oblio/SmartBill invoicing router; only take the
  `PUT /active-provider` routing bit if you don't need Romanian e-invoicing.

## What to strip (explicitly out of scope)

1. **Multilanguage / translations.** `from src.api.translations import ...` appears in
   several files (esp. `super_admin.py`, `api/ai.py`) and in the frontend
   `ConfigurationsPage.tsx` ("Traducere automată cu ChatGPT" toggle). **Delete those calls
   and that toggle** — your target app already has multilanguage and you said not to touch it.
2. **Romanian invoicing (Oblio/FGO/SmartBill)** — `providers/billing/*`, `billing.py`,
   `_emit_platform_oblio_invoice`, `core/billing_secrets`. Keep only if you invoice in Romania.
3. **Romanian PSPs (Netopia/BT iPay)** — keep Stripe only unless you need them.
4. **Product features** — booking/restaurant/facility completion handlers, SEO/blog/demo AI
   modules. These are 360booking's product, not the multi-tenant core.
5. The **`ai_config.json` file store** — replace with your secrets store/DB (see 06).

## Recommended port order

1. `models/tenant.py` + `models/user.py` + `core/security.py` → you have tenants + auth.
2. `core/tenant_resolver.py` + `middleware/tracing.py` → request context.
3. Frontend: `AuthContext.tsx` + `ProtectedRoute.tsx` + `client.ts` + the two layouts →
   the console split renders.
4. Super-admin tenant lifecycle (re-implement from `super_admin.py` spec) + `TenantsPage.tsx`.
5. `plan_catalog` + `subscriptions.py` + Stripe webhook → subscriptions live.
6. `plan_limits` + `access_control` (**gate off by default**) → enforcement.
7. `ai_config` + `ai_client` + `cost_limits` + super-admin key screen → AI.

## Hardening notes (fix these while porting — they're known weak spots in the source)

- **Manual tenant filtering** (01) is error-prone. Add a `tenant_scoped_query(model, user)`
  helper or a SQLAlchemy `before_compile` event that auto-injects `tenant_id ==` unless the
  caller is super-admin. Don't rely on every endpoint remembering.
- **`x-tenant-id` header is client-supplied** — never use it for authorization, only logging.
- **Restaurant Growth AI plan is hard-coded to `basic`** in the source (a TODO). If you port
  it, wire it to a real `plan_catalog.limits` key.
- **Two plan tables** (`plan_catalog` + legacy `subscription_plan`) — collapse into one.
