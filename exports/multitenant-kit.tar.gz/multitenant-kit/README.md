# Multi-Tenant Kit — Super-Admin / Tenant-Admin, Payments (Stripe), Subscriptions, AI

Export of the reusable **multi-tenant SaaS core** from 360booking, meant to be imported /
adapted into another application. It captures the architecture, the auth & role split
(super-admin vs tenant-admin), the tenant fleet-control surface, the payment/subscription
stack (Stripe + a provider-agnostic orchestrator), the per-tenant billing-routing config,
and the AI (OpenAI/ChatGPT) configuration & cost-gating.

> **Source stack:** FastAPI + SQLAlchemy (backend), React + TypeScript + React Router (frontend).
> The blueprint docs are stack-agnostic; the `reference-code/` files are the real
> implementation you translate or reuse.

> **Deliberately excluded:** the multi-language / translations system. It is already
> implemented in your target app and must not be touched. Where an exported file happens to
> reference translations (e.g. an auto-translate button inside `ConfigurationsPage.tsx`),
> that part is called out in the docs and can be dropped.

---

## What's in here

```
multitenant-kit/
├─ README.md                ← you are here
├─ docs/
│  ├─ 01-ARCHITECTURE.md      Multi-tenant model + request-time isolation
│  ├─ 02-AUTH-ROLES.md        JWT auth, role system, super-admin vs tenant-admin deps
│  ├─ 03-TENANT-LIFECYCLE.md  Super-admin fleet control: create/suspend/soft-delete/restore/purge
│  ├─ 04-PAYMENTS-STRIPE.md   Provider orchestrator + Stripe (guest checkout & platform subs)
│  ├─ 05-SUBSCRIPTIONS-PLANS.md  Plan catalog, add-ons, feature-gating, billing access gate
│  ├─ 06-AI-CONFIG.md         OpenAI config, per-tenant cost limits, usage logging
│  ├─ 07-DATA-MODEL.md        Consolidated DB schema for every table the kit needs
│  └─ 08-ADAPTATION-GUIDE.md  How to rewire this into a new app; coupling & what to strip
└─ reference-code/
   ├─ backend/   (31 files — mirrors backend/src/… paths)
   └─ frontend/  (21 files — mirrors frontend/src/… paths)
```

## How to read it

1. Start with **01-ARCHITECTURE** and **02-AUTH-ROLES** — they define the spine
   (tenant model, how the current tenant is resolved, and how the super-admin vs
   tenant-admin split is enforced on both backend and frontend).
2. Then pick the vertical you need: **04/05** for payments & subscriptions, **06** for AI.
3. **07-DATA-MODEL** is the single source of truth for the DB tables — start here if you're
   greenfield.
4. **08-ADAPTATION-GUIDE** lists exactly which internal dependencies (`src.core.database`,
   the email/SMS senders, Meta CAPI hooks, Oblio invoicing, etc.) each exported file drags
   in, and what you can safely stub or delete.

## The 6 pillars this kit gives you

| Pillar | Where |
|---|---|
| One `tenants` table + per-request tenant scoping | 01, 07 |
| Role-based auth (`super_admin`, `tenant_admin`, staff roles) with JWT | 02 |
| Super-admin fleet control (soft-delete → restore → purge lifecycle) | 03 |
| Stripe subscriptions **and** provider-agnostic guest checkout (Stripe/Netopia/BT iPay) | 04 |
| Plan catalog + add-ons + limit enforcement + billing access gate | 05 |
| OpenAI config resolved centrally + per-tenant cost budget + usage ledger | 06 |

Every claim in the docs points at a concrete file+symbol under `reference-code/`.
