# MANIFEST — reference-code files

Verbatim copies from 360booking. Paths mirror `backend/src/…` and `frontend/src/…`.
See docs/08-ADAPTATION-GUIDE.md for drop-in vs reference-only status of each.

## Backend (32 files)
```
src/api/auth.py
src/api/billing.py
src/api/booking_stripe_webhook.py
src/api/payment_webhooks.py
src/api/subscriptions.py
src/api/super_admin.py
src/api/webhooks.py
src/core/ai_config.py
src/core/security.py
src/core/tenant_resolver.py
src/middleware/tracing.py
src/models/addon_package.py
src/models/billing_integration.py
src/models/plan_catalog.py
src/models/site_config.py
src/models/subscription_plan.py
src/models/tenant.py
src/models/user.py
src/services/access_control.py
src/services/addon_service.py
src/services/ai_client.py
src/services/ai_usage_logger.py
src/services/auth_service.py
src/services/cost_limits.py
src/services/cost_pricing.py
src/services/payment_orchestrator.py
src/services/payment_providers/base.py
src/services/payment_providers/registry.py
src/services/payment_providers/stripe_provider.py
src/services/plan_catalog_stripe_sync.py
src/services/plan_limits.py
src/services/tenant_stripe.py
```

## Frontend (21 files)
```
src/components/auth/ProtectedRoute.tsx
src/components/common/AccessGate.tsx
src/components/layouts/AdminLayout.tsx
src/components/layouts/SuperAdminLayout.tsx
src/context/AuthContext.tsx
src/lib/api/billing.ts
src/lib/api/client.ts
src/lib/api/configurations.ts
src/lib/api/plan_catalog.ts
src/lib/api/subscriptions.ts
src/pages/admin/SubscriptionPage.tsx
src/pages/admin/settings/BillingIntegrationPage.tsx
src/pages/admin/settings/BillingPaymentPage.tsx
src/pages/admin/settings/StripePaymentPage.tsx
src/pages/super-admin/AddOnPackagesPage.tsx
src/pages/super-admin/ConfigurationsPage.tsx
src/pages/super-admin/PlanCatalogPage.tsx
src/pages/super-admin/StripePage.tsx
src/pages/super-admin/SubscriptionPlansPage.tsx
src/pages/super-admin/TenantsPage.tsx
src/router.tsx
```
