/**
 * Stripe — pagină dedicată pentru plăți online via Stripe Connect.
 * Extrasă din BillingPaymentPage pentru a apărea ca integrare separată în
 * /admin/settings/integrations → categoria Plăți.
 */
import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { CreditCard, CheckCircle, Zap, XCircle, Loader2, ArrowLeft } from 'lucide-react'
import apiClient from '../../../lib/api/client'

interface StripeConfig {
  publishableKey?: string
  secretKey?: string
  webhookSecret?: string
}

interface StripeConnectStatus {
  connected: boolean
  stripe_user_id?: string
  account?: {
    id?: string
    business_name?: string
    email?: string
    country?: string
    charges_enabled?: boolean
    payouts_enabled?: boolean
    details_submitted?: boolean
  }
  livemode?: boolean
  connected_at?: string
  has_webhook_secret?: boolean
}

interface StripeTestResult {
  ok: boolean
  via?: string
  account?: StripeConnectStatus['account']
  error?: string
}

const MASK = '••••••••••'

export default function StripePaymentPage() {
  const [loading, setLoading] = useState(true)
  const [savingStripe, setSavingStripe] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [stripeStatus, setStripeStatus] = useState<StripeConnectStatus | null>(null)
  const [connecting, setConnecting] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<StripeTestResult | null>(null)
  const [showManualStripe, setShowManualStripe] = useState(false)
  const [stripeConfig, setStripeConfig] = useState<StripeConfig>({
    publishableKey: '',
    secretKey: '',
    webhookSecret: '',
  })
  const [tenantId, setTenantId] = useState<string>('')
  const [webhookUrlCopied, setWebhookUrlCopied] = useState(false)

  useEffect(() => {
    fetchConfig()
    fetchStripeStatus()
    const params = new URLSearchParams(window.location.search)
    if (params.get('stripe')) {
      setTimeout(fetchStripeStatus, 500)
      const clean = window.location.pathname + (params.get('tab') ? `?tab=${params.get('tab')}` : '')
      window.history.replaceState({}, '', clean)
    }
    const onMsg = (e: MessageEvent) => {
      if (e.data && e.data.stripe) fetchStripeStatus()
    }
    window.addEventListener('message', onMsg)
    return () => window.removeEventListener('message', onMsg)
  }, [])

  const fetchConfig = async () => {
    setLoading(true)
    try {
      const res = await apiClient.get('/api/site-config')
      const data = res.data as Record<string, unknown>
      setTenantId((data.tenant_id as string) || (data.tenantId as string) || '')
      const rawStripe = data.stripe_config
      let parsed: StripeConfig = {}
      if (rawStripe && typeof rawStripe === 'string') {
        try { parsed = JSON.parse(rawStripe) as StripeConfig } catch { parsed = {} }
      } else if (rawStripe && typeof rawStripe === 'object') {
        parsed = rawStripe as StripeConfig
      }
      setStripeConfig({
        publishableKey: parsed.publishableKey ?? '',
        secretKey: parsed.secretKey ? MASK : '',
        webhookSecret: parsed.webhookSecret ? MASK : '',
      })
    } catch (error) {
      console.error('Error fetching config:', error)
      setMessage({ type: 'error', text: 'Eroare la încărcarea setărilor.' })
    } finally {
      setLoading(false)
    }
  }

  const fetchStripeStatus = async () => {
    try {
      const res = await apiClient.get<StripeConnectStatus>('/api/integrations/stripe/oauth/status')
      setStripeStatus(res.data)
    } catch {
      setStripeStatus(null)
    }
  }

  const handleStripeConnect = async () => {
    setConnecting(true)
    setMessage(null)
    try {
      const res = await apiClient.get<{ url: string }>('/api/integrations/stripe/oauth/start')
      const w = window.open(res.data.url, 'stripe-oauth', 'width=600,height=800')
      if (!w) window.location.href = res.data.url
    } catch (e: any) {
      setMessage({ type: 'error', text: e?.response?.data?.detail || 'Eroare la pornirea conectării Stripe.' })
    } finally {
      setConnecting(false)
    }
  }

  const handleStripeDisconnect = async () => {
    if (!window.confirm('Sigur vrei să deconectezi contul Stripe? Plățile online se vor opri până reconfigurezi.')) return
    try {
      await apiClient.post('/api/integrations/stripe/oauth/disconnect')
      setStripeStatus({ connected: false })
      setTestResult(null)
      setStripeConfig({ publishableKey: '', secretKey: '', webhookSecret: '' })
      setMessage({ type: 'success', text: 'Stripe deconectat.' })
    } catch (e: any) {
      setMessage({ type: 'error', text: e?.response?.data?.detail || 'Eroare la deconectare.' })
    }
  }

  const handleStripeTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      const res = await apiClient.post<StripeTestResult>('/api/integrations/stripe/oauth/test-connection')
      setTestResult(res.data)
    } catch (e: any) {
      setTestResult({ ok: false, error: e?.response?.data?.detail || 'Eroare la test.' })
    } finally {
      setTesting(false)
    }
  }

  const handleSaveStripe = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingStripe(true)
    setMessage(null)
    try {
      const toSend: Record<string, string> = {}
      if (stripeConfig.publishableKey) toSend.publishableKey = stripeConfig.publishableKey
      if (stripeConfig.secretKey && stripeConfig.secretKey !== MASK) toSend.secretKey = stripeConfig.secretKey
      if (stripeConfig.webhookSecret && stripeConfig.webhookSecret !== MASK) toSend.webhookSecret = stripeConfig.webhookSecret
      await apiClient.patch('/api/site-config', { stripe_config: JSON.stringify(toSend) })
      setMessage({ type: 'success', text: 'Setările Stripe au fost salvate.' })
      setTimeout(() => setMessage(null), 5000)
      fetchConfig()
    } catch (error) {
      console.error('Error saving Stripe:', error)
      setMessage({ type: 'error', text: 'Eroare la salvarea setărilor Stripe.' })
    } finally {
      setSavingStripe(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <Link
        to="/admin/settings/integrations"
        className="inline-flex items-center text-sm text-gray-600 hover:text-gray-900"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Înapoi la Integrări
      </Link>

      {message && (
        <div className={`rounded-lg p-4 ${message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
          {message.text}
        </div>
      )}

      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-[#635BFF]" />
            <h2 className="text-lg font-semibold text-gray-900">Stripe — Plăți Online</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Card payments pentru rezervări (Visa, Mastercard, Apple Pay, Google Pay). Banii intră direct în contul tău Stripe, 360booking nu îi atinge.
          </p>
        </div>

        <div className="p-6">
          {stripeStatus?.connected ? (
            <div className="rounded-lg border border-green-200 bg-green-50 p-4 mb-4 max-w-xl">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-green-700 mt-0.5 shrink-0" />
                <div className="text-sm">
                  <div className="font-medium text-green-900">Conectat la Stripe</div>
                  <div className="text-green-800 mt-1">
                    {stripeStatus.account?.business_name || stripeStatus.account?.email || stripeStatus.stripe_user_id}
                    {stripeStatus.account?.country && <> · {stripeStatus.account.country.toUpperCase()}</>}
                    {stripeStatus.livemode === false && (
                      <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 text-[11px] font-medium">TEST MODE</span>
                    )}
                  </div>
                  {stripeStatus.account && (
                    <div className="mt-2 space-y-0.5 text-xs text-green-900">
                      <div>Plăți active: {stripeStatus.account.charges_enabled ? '✓' : <span className="text-red-700">✗ (completează KYC în Stripe)</span>}</div>
                      <div>Retragere în IBAN: {stripeStatus.account.payouts_enabled ? '✓' : <span className="text-red-700">✗</span>}</div>
                      <div>Webhook înregistrat automat: {stripeStatus.has_webhook_secret ? '✓' : <span className="text-red-700">✗ (apasă Test Connection)</span>}</div>
                    </div>
                  )}
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={handleStripeTest}
                  disabled={testing}
                  className="inline-flex items-center gap-1.5 rounded-md bg-white border border-green-300 px-3 py-1.5 text-xs font-medium text-green-800 hover:bg-green-100 disabled:opacity-50"
                >
                  {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Zap className="h-3.5 w-3.5" />}
                  Testează conexiunea
                </button>
                <button
                  type="button"
                  onClick={handleStripeDisconnect}
                  className="inline-flex items-center gap-1.5 rounded-md bg-white border border-red-300 px-3 py-1.5 text-xs font-medium text-red-800 hover:bg-red-50"
                >
                  <XCircle className="h-3.5 w-3.5" /> Deconectează
                </button>
              </div>
              {testResult && (
                <div className={`mt-3 rounded border px-3 py-2 text-xs ${testResult.ok ? 'bg-white border-green-300 text-green-900' : 'bg-red-50 border-red-300 text-red-900'}`}>
                  {testResult.ok ? (
                    <>
                      <span className="font-medium">Conexiune OK</span> · via {testResult.via}
                      {testResult.account?.charges_enabled === false && <> · <strong>Atenție: charges_enabled=false</strong>, completează KYC în Stripe Dashboard.</>}
                    </>
                  ) : (
                    <><span className="font-medium">Eroare:</span> {testResult.error}</>
                  )}
                </div>
              )}
            </div>
          ) : (
            <div className="rounded-lg border border-indigo-200 bg-indigo-50 p-4 mb-4 max-w-xl">
              <p className="text-sm text-indigo-900 mb-3">
                Conectează-te cu contul tău Stripe într-un singur click. Stripe te ghidează prin KYC (CUI, IBAN, documente), iar 360booking configurează automat webhook-ul și cheile.
              </p>
              <button
                type="button"
                onClick={handleStripeConnect}
                disabled={connecting}
                className="inline-flex items-center gap-2 rounded-lg bg-[#635bff] px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#4f47e0] disabled:opacity-50"
              >
                {connecting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
                {connecting ? 'Se deschide Stripe…' : 'Conectează cu Stripe'}
              </button>
              <div className="mt-3 text-xs text-indigo-700">
                Nu iei comision — banii intră direct în contul tău Stripe. 360booking nu atinge banii.
              </div>
              <button
                type="button"
                onClick={() => setShowManualStripe((s) => !s)}
                className="mt-3 text-xs text-indigo-800 underline hover:text-indigo-900"
              >
                {showManualStripe ? 'Ascunde configurarea manuală' : 'Configurare manuală avansată (chei API)'}
              </button>
            </div>
          )}

          <form
            onSubmit={handleSaveStripe}
            className={`space-y-4 max-w-xl ${stripeStatus?.connected || !showManualStripe ? 'hidden' : ''}`}
            autoComplete="off"
          >
            <input type="text" name="fake-username" autoComplete="username" tabIndex={-1} style={{ display: 'none' }} />
            <input type="password" name="fake-password" autoComplete="current-password" tabIndex={-1} style={{ display: 'none' }} />

            {tenantId && (
              <div className="rounded-lg border border-indigo-200 bg-indigo-50 p-4">
                <label className="block text-sm font-medium text-indigo-900 mb-1">URL-ul webhook-ului tău</label>
                <p className="text-xs text-indigo-800 mb-2">
                  Copiază URL-ul de mai jos și adaugă-l în Stripe Dashboard → Developers → Webhooks → Add endpoint.
                  Stripe îți va genera un <code>whsec_…</code> pe care îl pui în câmpul „Webhook Secret" de mai jos.
                </p>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}/api/webhooks/booking-stripe/${tenantId}`}
                    className="flex-1 rounded-md border border-indigo-300 bg-white px-3 py-2 text-xs font-mono text-gray-900"
                    onFocus={(e) => e.currentTarget.select()}
                  />
                  <button
                    type="button"
                    onClick={async () => {
                      const url = `${window.location.origin}/api/webhooks/booking-stripe/${tenantId}`
                      try {
                        await navigator.clipboard.writeText(url)
                        setWebhookUrlCopied(true)
                        setTimeout(() => setWebhookUrlCopied(false), 2000)
                      } catch {
                        // ignore
                      }
                    }}
                    className="rounded-md bg-indigo-600 px-3 py-2 text-xs font-medium text-white hover:bg-indigo-700"
                  >
                    {webhookUrlCopied ? 'Copiat ✓' : 'Copiază'}
                  </button>
                </div>
                <p className="mt-2 text-xs text-indigo-700">
                  Eveniment de ascultat în Stripe: <code>checkout.session.completed</code>
                </p>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Publishable Key</label>
              <input
                type="text"
                name="stripe-publishable-key-v2"
                value={stripeConfig.publishableKey}
                onChange={(e) => setStripeConfig((s) => ({ ...s, publishableKey: e.target.value }))}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="pk_..."
                autoComplete="off"
                spellCheck={false}
                data-lpignore="true"
                data-1p-ignore="true"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Secret Key</label>
              <input
                type="password"
                name="stripe-secret-key-v2"
                value={stripeConfig.secretKey}
                onChange={(e) => setStripeConfig((s) => ({ ...s, secretKey: e.target.value }))}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="Lăsați gol pentru a păstra valoarea existentă"
                autoComplete="new-password"
                spellCheck={false}
                data-lpignore="true"
                data-1p-ignore="true"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Webhook Secret</label>
              <input
                type="password"
                name="stripe-webhook-secret-v2"
                value={stripeConfig.webhookSecret}
                onChange={(e) => setStripeConfig((s) => ({ ...s, webhookSecret: e.target.value }))}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                placeholder="whsec_..."
                autoComplete="new-password"
                spellCheck={false}
                data-lpignore="true"
                data-1p-ignore="true"
              />
            </div>
            <button
              type="submit"
              disabled={savingStripe}
              className="inline-flex items-center justify-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              {savingStripe ? 'Se salvează...' : 'Salvează Stripe'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
