/**
 * Facturare&Plata - Sistem de facturare + linkuri către providerii de plată online.
 * Stripe / Netopia / BT iPay au pagini dedicate sub /admin/settings/integrations
 * (categoria Plăți). Aici păstrăm doar sistemul de facturare + provider implicit
 * + linkul către imprimanta fiscală.
 */
import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FileText, CreditCard, CheckCircle, ChevronRight } from 'lucide-react'
import apiClient from '../../../lib/api/client'
import { billingApi, type OblioStatusResponse, type SmartBillStatusResponse } from '../../../lib/api/billing'

const BILLING_OPTIONS = [
  { value: 'proforma', label: 'Facturi proforma interne' },
  { value: 'oblio', label: 'Oblio' },
  { value: 'smartbill', label: 'SmartBill' },
  { value: 'fgo', label: 'FGO' },
] as const

interface StripeConnectStatus {
  connected: boolean
  livemode?: boolean
}

interface PaymentProviderState {
  stripe: boolean
  netopia: boolean
  btipay: boolean
}

export default function BillingPaymentPage() {
  const [loading, setLoading] = useState(true)
  const [savingBilling, setSavingBilling] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [billingSystem, setBillingSystem] = useState<string>('proforma')
  const [preferredProvider, setPreferredProvider] = useState<string>('')
  const [savingPreferred, setSavingPreferred] = useState(false)
  const [acceptCardOnline, setAcceptCardOnline] = useState(true)
  const [acceptBankTransfer, setAcceptBankTransfer] = useState(true)
  const [savingMethods, setSavingMethods] = useState(false)
  const [oblioStatus, setOblioStatus] = useState<OblioStatusResponse | null>(null)
  const [smartbillStatus, setSmartbillStatus] = useState<SmartBillStatusResponse | null>(null)
  const [providerStatus, setProviderStatus] = useState<PaymentProviderState>({
    stripe: false,
    netopia: false,
    btipay: false,
  })
  const [bridgeVersionInfo, setBridgeVersionInfo] = useState<{
    installed: string | null
    latest: string | null
    updateAvailable: boolean
    connected: boolean
  } | null>(null)

  useEffect(() => {
    fetchConfig()
    fetchBridgeVersion()
    fetchProviderStatuses()
  }, [])

  const fetchBridgeVersion = async () => {
    try {
      const r = await apiClient.get<{
        version?: string | null
        latest_version?: string | null
        update_available?: boolean
        connected?: boolean
      }>('/api/fiscal-bridge/status')
      setBridgeVersionInfo({
        installed: r.data?.version || null,
        latest: r.data?.latest_version || null,
        updateAvailable: !!r.data?.update_available,
        connected: !!r.data?.connected,
      })
    } catch {
      setBridgeVersionInfo({ installed: null, latest: null, updateAvailable: false, connected: false })
    }
  }

  const fetchProviderStatuses = async () => {
    try {
      const [stripeRes, cfgRes] = await Promise.allSettled([
        apiClient.get<StripeConnectStatus>('/api/integrations/stripe/oauth/status'),
        apiClient.get('/api/site-config'),
      ])
      const next: PaymentProviderState = { stripe: false, netopia: false, btipay: false }
      if (stripeRes.status === 'fulfilled') {
        next.stripe = !!stripeRes.value.data?.connected
      }
      if (cfgRes.status === 'fulfilled') {
        const d = cfgRes.value.data as Record<string, unknown>
        const parse = (raw: unknown): Record<string, unknown> => {
          if (!raw) return {}
          if (typeof raw === 'string') {
            try { return JSON.parse(raw) as Record<string, unknown> } catch { return {} }
          }
          return typeof raw === 'object' ? (raw as Record<string, unknown>) : {}
        }
        const netopia = parse(d.netopia_config)
        next.netopia = !!(netopia.signature || netopia.api_key || netopia.public_key)
        const btipay = parse(d.btipay_config)
        next.btipay = !!(btipay.user_name || btipay.password || btipay.merchant_id)
      }
      setProviderStatus(next)
    } catch {
      // keep defaults
    }
  }

  useEffect(() => {
    if (billingSystem === 'oblio') {
      billingApi.getOblioStatus().then(setOblioStatus).catch(() => setOblioStatus(null))
    } else {
      setOblioStatus(null)
    }
    if (billingSystem === 'smartbill') {
      billingApi.getSmartBillStatus().then(setSmartbillStatus).catch(() => setSmartbillStatus(null))
    } else {
      setSmartbillStatus(null)
    }
  }, [billingSystem])

  const fetchConfig = async () => {
    setLoading(true)
    try {
      const [configRes, effectiveRes] = await Promise.all([
        apiClient.get('/api/site-config'),
        apiClient.get('/api/billing/effective-provider').catch(() => ({ data: { provider: 'proforma' } })),
      ])
      const data = configRes.data as Record<string, unknown>
      const stored = (data.billing_system as string) || ''
      const effective = (effectiveRes.data as { provider?: string })?.provider || 'proforma'
      setBillingSystem(stored && stored !== 'proforma' ? stored : effective)
      setPreferredProvider((data.preferred_payment_provider as string) || '')
      // Default to true when the field is absent (older configs / not yet set).
      setAcceptCardOnline(data.accept_card_online !== false)
      setAcceptBankTransfer(data.accept_bank_transfer !== false)
    } catch (error) {
      console.error('Error fetching config:', error)
      setMessage({ type: 'error', text: 'Eroare la încărcarea setărilor.' })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveBilling = async (e: React.FormEvent) => {
    e.preventDefault()
    setSavingBilling(true)
    setMessage(null)
    try {
      await apiClient.patch('/api/site-config', { billing_system: billingSystem })
      setMessage({ type: 'success', text: 'Sistemul de facturare a fost salvat.' })
      setTimeout(() => setMessage(null), 5000)
    } catch (error) {
      console.error('Error saving billing:', error)
      setMessage({ type: 'error', text: 'Eroare la salvarea sistemului de facturare.' })
    } finally {
      setSavingBilling(false)
    }
  }

  const handleToggleMethod = async (
    method: 'card' | 'transfer',
    next: boolean,
  ) => {
    const nextCard = method === 'card' ? next : acceptCardOnline
    const nextTransfer = method === 'transfer' ? next : acceptBankTransfer
    // At least one method must stay enabled — otherwise guests can't pay.
    if (!nextCard && !nextTransfer) {
      setMessage({
        type: 'error',
        text: 'Trebuie să rămână activă cel puțin o metodă de plată.',
      })
      setTimeout(() => setMessage(null), 4000)
      return
    }
    // Optimistic update.
    if (method === 'card') setAcceptCardOnline(next)
    else setAcceptBankTransfer(next)
    setSavingMethods(true)
    try {
      await apiClient.patch('/api/site-config', {
        accept_card_online: nextCard,
        accept_bank_transfer: nextTransfer,
      })
      setMessage({ type: 'success', text: 'Metodele de plată au fost salvate.' })
      setTimeout(() => setMessage(null), 3000)
    } catch (error) {
      console.error('Error saving payment methods:', error)
      // Revert on failure.
      if (method === 'card') setAcceptCardOnline(!next)
      else setAcceptBankTransfer(!next)
      setMessage({ type: 'error', text: 'Eroare la salvarea metodelor de plată.' })
    } finally {
      setSavingMethods(false)
    }
  }

  const handleSavePreferred = async (value: string) => {
    setPreferredProvider(value)
    setSavingPreferred(true)
    try {
      await apiClient.patch('/api/site-config', { preferred_payment_provider: value || null })
      setMessage({ type: 'success', text: 'Provider implicit salvat.' })
      setTimeout(() => setMessage(null), 3000)
    } catch (error) {
      console.error('Error saving preferred provider:', error)
      setMessage({ type: 'error', text: 'Eroare la salvarea providerului implicit.' })
    } finally {
      setSavingPreferred(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
      </div>
    )
  }

  const PROVIDER_CARDS: {
    id: keyof PaymentProviderState
    name: string
    description: string
    href: string
    iconBg: string
  }[] = [
    {
      id: 'stripe',
      name: 'Stripe',
      description: 'Card + Apple/Google Pay — bani direct în contul tău Stripe',
      href: '/admin/settings?tab=payments-stripe',
      iconBg: 'bg-[#635BFF]',
    },
    {
      id: 'netopia',
      name: 'Netopia / Mobilpay',
      description: 'Procesator local — redirect-style checkout',
      href: '/admin/settings?tab=payments-netopia',
      iconBg: 'bg-rose-600',
    },
    {
      id: 'btipay',
      name: 'BT iPay',
      description: 'Banca Transilvania — REST API cu Basic auth',
      href: '/admin/settings?tab=payments-btipay',
      iconBg: 'bg-yellow-600',
    },
  ]

  return (
    <div className="space-y-8">
      {message && (
        <div
          className={`rounded-lg p-4 ${
            message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}
        >
          {message.text}
        </div>
      )}

      {/* Sistem de Facturare */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Sistem de Facturare</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Alege furnizorul folosit pentru emiterea automată a facturilor și configurează credențialele necesare.
          </p>
        </div>
        <div className="p-6">
          <form onSubmit={handleSaveBilling} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Furnizor facturare</label>
              <select
                value={billingSystem}
                onChange={(e) => setBillingSystem(e.target.value)}
                className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {BILLING_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            {billingSystem === 'oblio' && (
              <div className="rounded-lg border-2 border-purple-200 bg-purple-50/50 p-5">
                <div className="flex items-center gap-2 text-purple-800 font-semibold mb-2">
                  <FileText className="h-5 w-5" />
                  Oblio
                </div>
                {oblioStatus?.status === 'connected' ? (
                  <>
                    <div className="flex items-center gap-2 text-green-700 text-sm mb-2">
                      <CheckCircle className="h-4 w-4 shrink-0" />
                      <span>Oblio este conectat și folosit la facturare.</span>
                    </div>
                    <ul className="text-sm text-gray-700 space-y-1 mb-3">
                      {oblioStatus.oblio_client_id && (
                        <li><span className="font-medium">Email:</span> {oblioStatus.oblio_client_id}</li>
                      )}
                      {oblioStatus.selected_company_cif && (
                        <li><span className="font-medium">Companie (CIF):</span> {oblioStatus.selected_company_cif}</li>
                      )}
                      {oblioStatus.default_invoice_series && (
                        <li><span className="font-medium">Serie factură:</span> {oblioStatus.default_invoice_series}</li>
                      )}
                      {oblioStatus.invoice_product_name && (
                        <li><span className="font-medium">Serviciu factură:</span> {oblioStatus.invoice_product_name}</li>
                      )}
                    </ul>
                    <Link
                      to="/admin/settings?tab=billing-integration"
                      className="inline-flex items-center rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700"
                    >
                      Modifică setări Oblio
                    </Link>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-gray-700 mb-3">
                      Configurează credențialele Oblio (Email, API Secret, companie și serie) în pagina dedicată.
                    </p>
                    <Link
                      to="/admin/settings?tab=billing-integration"
                      className="inline-flex items-center rounded-lg bg-purple-600 px-4 py-2 text-sm font-medium text-white hover:bg-purple-700"
                    >
                      Integrare facturare – Conectare Oblio
                    </Link>
                  </>
                )}
              </div>
            )}

            {billingSystem === 'smartbill' && (
              <div className="rounded-lg border-2 border-blue-200 bg-blue-50/50 p-5">
                <div className="flex items-center gap-2 text-blue-800 font-semibold mb-2">
                  <FileText className="h-5 w-5" />
                  SmartBill
                </div>
                {smartbillStatus?.status === 'connected' ? (
                  <>
                    <div className="flex items-center gap-2 text-green-700 text-sm mb-2">
                      <CheckCircle className="h-4 w-4 shrink-0" />
                      <span>SmartBill este conectat și folosit la facturare.</span>
                    </div>
                    <ul className="text-sm text-gray-700 space-y-1 mb-3">
                      {smartbillStatus.smartbill_email && (
                        <li><span className="font-medium">Email:</span> {smartbillStatus.smartbill_email}</li>
                      )}
                      {smartbillStatus.selected_company_cif && (
                        <li><span className="font-medium">Companie (CIF):</span> {smartbillStatus.selected_company_cif}</li>
                      )}
                      {smartbillStatus.default_invoice_series && (
                        <li><span className="font-medium">Serie factură:</span> {smartbillStatus.default_invoice_series}</li>
                      )}
                    </ul>
                    <Link
                      to="/admin/settings?tab=billing-integration"
                      className="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                      Modifică setări SmartBill
                    </Link>
                  </>
                ) : (
                  <>
                    <p className="text-sm text-gray-700 mb-3">
                      Configurează credențialele SmartBill (Email, Token API, CIF companie și serie) în pagina dedicată.
                    </p>
                    <Link
                      to="/admin/settings?tab=billing-integration"
                      className="inline-flex items-center rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
                    >
                      Integrare facturare – Conectare SmartBill
                    </Link>
                  </>
                )}
              </div>
            )}

            {billingSystem === 'proforma' && (
              <div className="rounded-lg border-2 border-green-200 bg-green-50/50 p-5">
                <div className="flex items-center gap-2 text-green-800 font-semibold mb-2">
                  <FileText className="h-5 w-5" />
                  Facturi Proforma Interne
                </div>
                <p className="text-sm text-gray-700 mb-4">
                  Sistemul va genera automat facturi proforma folosind datele companiei din contul dumneavoastră.
                </p>
                <p className="text-xs font-medium uppercase tracking-wider text-gray-500 mb-2">Datele folosite în factură:</p>
                <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                  <li>Numele companiei din setările de contact</li>
                  <li>Adresa din setările de contact</li>
                  <li>CUI-ul din setările de contact</li>
                  <li>Detalii rezervare (client, perioadă, preț)</li>
                </ul>
              </div>
            )}

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={savingBilling}
                className="inline-flex items-center justify-center rounded-full bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-purple-700 disabled:opacity-50"
              >
                {savingBilling ? 'Se salvează...' : 'Salvează Sistemul de Facturare'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Metode de Plată Online — summary cards linking to dedicated pages */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Metode de Plată Online</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Fiecare provider are pagina lui dedicată — alege și conectează cel puțin unul ca să primești plăți online de la clienți.
          </p>
        </div>
        <div className="p-6 grid gap-3 sm:grid-cols-3">
          {PROVIDER_CARDS.map((p) => {
            const connected = providerStatus[p.id]
            return (
              <Link
                key={p.id}
                to={p.href}
                className="group relative rounded-xl border border-gray-200 p-4 hover:border-indigo-400 hover:shadow-md transition"
              >
                <div className="flex items-start gap-3">
                  <div className={`shrink-0 h-10 w-10 rounded-lg flex items-center justify-center text-white ${p.iconBg}`}>
                    <CreditCard className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-gray-900">{p.name}</span>
                      {connected ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2 py-0.5 text-[11px] font-medium text-green-700 border border-green-200">
                          <CheckCircle className="h-3 w-3" /> Conectat
                        </span>
                      ) : (
                        <span className="inline-flex items-center rounded-full bg-gray-50 px-2 py-0.5 text-[11px] font-medium text-gray-600 border border-gray-200">
                          Disponibil
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-600 mt-1 leading-snug">{p.description}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-indigo-500 self-center" />
                </div>
              </Link>
            )
          })}
        </div>
      </div>

      {/* Acceptare metode de plată la rezervare */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Metode acceptate la rezervare</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Alege ce metode de plată poate folosi clientul la rezervarea online. Trebuie să rămână activă cel puțin una.
          </p>
        </div>
        <div className="p-6 space-y-3">
          {/* Card online */}
          <label className="flex items-center justify-between gap-4 rounded-xl border border-gray-200 p-4">
            <div className="min-w-0">
              <div className="font-semibold text-gray-900">Plată online cu cardul</div>
              <p className="text-xs text-gray-600 mt-1 leading-snug">
                Clientul plătește pe loc cu cardul (Stripe / Netopia / BT iPay).
                {!(providerStatus.stripe || providerStatus.netopia || providerStatus.btipay) && (
                  <span className="block text-amber-600 mt-1">
                    Necesită cel puțin un provider configurat mai sus ca să apară la clienți.
                  </span>
                )}
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={acceptCardOnline}
              disabled={savingMethods}
              onClick={() => handleToggleMethod('card', !acceptCardOnline)}
              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition disabled:opacity-50 ${
                acceptCardOnline ? 'bg-indigo-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition ${
                  acceptCardOnline ? 'translate-x-5' : 'translate-x-1'
                }`}
              />
            </button>
          </label>

          {/* Transfer bancar */}
          <label className="flex items-center justify-between gap-4 rounded-xl border border-gray-200 p-4">
            <div className="min-w-0">
              <div className="font-semibold text-gray-900">Transfer bancar</div>
              <p className="text-xs text-gray-600 mt-1 leading-snug">
                Clientul primește datele de cont și plătește prin transfer / OP.
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={acceptBankTransfer}
              disabled={savingMethods}
              onClick={() => handleToggleMethod('transfer', !acceptBankTransfer)}
              className={`relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition disabled:opacity-50 ${
                acceptBankTransfer ? 'bg-indigo-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-5 w-5 transform rounded-full bg-white shadow transition ${
                  acceptBankTransfer ? 'translate-x-5' : 'translate-x-1'
                }`}
              />
            </button>
          </label>
        </div>
      </div>

      {/* Provider implicit picker */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Provider implicit plată online</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Când ai configurat mai mulți provideri, folosește-l pe cel ales aici pentru comenzi noi.
          </p>
        </div>
        <div className="p-6">
          <div className="flex items-center gap-3">
            <select
              value={preferredProvider}
              onChange={(e) => handleSavePreferred(e.target.value)}
              disabled={savingPreferred}
              className="rounded-lg border border-gray-300 px-3 py-2 text-sm text-gray-900 focus:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Automat (Stripe dacă e configurat, altfel primul disponibil)</option>
              <option value="stripe">Stripe</option>
              <option value="netopia">Netopia</option>
              <option value="btipay">BT iPay</option>
            </select>
            {savingPreferred && <span className="text-xs text-gray-500">Se salvează…</span>}
          </div>
        </div>
      </div>

      {/* Imprimantă fiscală — quick-link */}
      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Imprimantă fiscală</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Conectează o casă de marcat fiscală (Datecs DP-25 și alte modele). Aplicația rulează pe PC-ul de la recepție / bar
            și tipărește bonul fiscal automat la finalizarea unei comenzi.
          </p>
        </div>
        <div className="p-6">
          {bridgeVersionInfo && (bridgeVersionInfo.installed || bridgeVersionInfo.latest) && (
            <div className="mb-4 max-w-xl rounded-md border border-gray-200 bg-gray-50 px-3 py-2 text-xs text-gray-700 space-y-1">
              {bridgeVersionInfo.installed ? (
                <div>
                  Versiune instalată pe PC-ul tău:{' '}
                  <strong className="font-mono">v{bridgeVersionInfo.installed}</strong>
                  {bridgeVersionInfo.connected ? (
                    <span className="ml-2 text-green-700">• conectat</span>
                  ) : (
                    <span className="ml-2 text-gray-500">• deconectat</span>
                  )}
                </div>
              ) : (
                <div className="text-gray-500">Nu ai încă nicio instalare activă.</div>
              )}
              {bridgeVersionInfo.latest && (
                <div>
                  Ultima versiune disponibilă:{' '}
                  <strong className="font-mono">v{bridgeVersionInfo.latest}</strong>
                  {bridgeVersionInfo.installed && !bridgeVersionInfo.updateAvailable && (
                    <span className="ml-2 text-green-700">✓ ești la zi</span>
                  )}
                  {bridgeVersionInfo.updateAvailable && (
                    <span className="ml-2 text-amber-700">⚠ actualizare disponibilă</span>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="flex flex-wrap gap-2 max-w-xl">
            <a
              href="/api/fiscal-bridge/download"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 text-sm font-medium"
            >
              <CreditCard className="h-4 w-4" />
              {bridgeVersionInfo?.latest
                ? `Descarcă v${bridgeVersionInfo.latest}`
                : 'Descarcă aplicația fiscală'}
            </a>
            <Link
              to="/admin/restaurant/fiscal"
              className="inline-flex items-center gap-2 rounded-lg bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 px-4 py-2 text-sm font-medium"
            >
              Panou complet de configurare →
            </Link>
          </div>
          <p className="text-xs text-gray-500 mt-3 max-w-xl">
            Outbound WebSocket către 360booking — fără IP public, fără port forwarding, fără VPN.
            Compatibil Windows 10 / 11. macOS și Linux în backlog.
          </p>
        </div>
      </div>
    </div>
  )
}
