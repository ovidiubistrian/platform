/**
 * Integrare facturare – Oblio, SmartBill și FGO.
 * Card Oblio: Email, API Secret, Test, Companie (CIF), Serie factură, Save, Status, Disconnect.
 * Card SmartBill: Email, Token API, CIF companie, Test, Serie implicită, Save, Status, Disconnect.
 * Card FGO: CodUnic, PrivateKey, PlatformaUrl, Environment, defaults, Save/Test/Disconnect.
 */
import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FileText } from 'lucide-react'
import {
  billingApi,
  type OblioStatusResponse,
  type OblioCompany,
  type OblioSeriesItem,
  type OblioProductItem,
  type SmartBillStatusResponse,
  type SmartBillSeriesItem,
  type TenantIssuedInvoice,
  type TenantFGOSettings,
} from '../../../lib/api/billing'

const DOCS_LINK = '/admin/settings?tab=billing-integration'

export default function BillingIntegrationPage() {
  const [loading, setLoading] = useState(true)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  // Oblio
  const [status, setStatus] = useState<OblioStatusResponse | null>(null)
  const [email, setEmail] = useState('')
  const [clientSecret, setClientSecret] = useState('')
  const [updateSecret, setUpdateSecret] = useState(false)
  const [companies, setCompanies] = useState<OblioCompany[]>([])
  const [series, setSeries] = useState<OblioSeriesItem[]>([])
  const [selectedCompanyCif, setSelectedCompanyCif] = useState('')
  const [selectedSeries, setSelectedSeries] = useState('')
  const [oblioProducts, setOblioProducts] = useState<OblioProductItem[]>([])
  const [loadingProducts, setLoadingProducts] = useState(false)
  const [selectedInvoiceProductName, setSelectedInvoiceProductName] = useState('')
  const [selectedVatPercentage, setSelectedVatPercentage] = useState('')
  const [testing, setTesting] = useState(false)
  const [saving, setSaving] = useState(false)
  const [disconnecting, setDisconnecting] = useState(false)

  // SmartBill
  const [sbStatus, setSbStatus] = useState<SmartBillStatusResponse | null>(null)
  const [sbEmail, setSbEmail] = useState('')
  const [sbToken, setSbToken] = useState('')
  const [sbCompanyCif, setSbCompanyCif] = useState('')
  const [sbSeries, setSbSeries] = useState('')
  const [sbSeriesList, setSbSeriesList] = useState<SmartBillSeriesItem[]>([])
  const [sbEnabled, setSbEnabled] = useState(true)
  const [sbDefaultCurrency, setSbDefaultCurrency] = useState('RON')
  const [sbDefaultLanguage, setSbDefaultLanguage] = useState('RO')
  const [sbDefaultIsTaxPayer, setSbDefaultIsTaxPayer] = useState(false)
  const [sbDefaultPaymentMethod, setSbDefaultPaymentMethod] = useState('')
  const [sbDefaultNotes, setSbDefaultNotes] = useState('')
  const [sbInvoices, setSbInvoices] = useState<TenantIssuedInvoice[]>([])
  const [sbInvoicesLoading, setSbInvoicesLoading] = useState(false)
  const [sbTesting, setSbTesting] = useState(false)
  const [sbSaving, setSbSaving] = useState(false)
  const [sbDisconnecting, setSbDisconnecting] = useState(false)

  // FGO
  const [fgoStatus, setFgoStatus] = useState<TenantFGOSettings | null>(null)
  const [fgoCodUnic, setFgoCodUnic] = useState('')
  const [fgoPrivateKey, setFgoPrivateKey] = useState('')
  const [fgoPlatformUrl, setFgoPlatformUrl] = useState('')
  const [fgoEnvironment, setFgoEnvironment] = useState<'test' | 'production'>('test')
  const [fgoSeries, setFgoSeries] = useState('')
  const [fgoEnabled, setFgoEnabled] = useState(true)
  const [fgoCurrency, setFgoCurrency] = useState('RON')
  const [fgoInvoiceType, setFgoInvoiceType] = useState('invoice')
  const [fgoDueDays, setFgoDueDays] = useState(7)
  const [fgoVerifyDuplicate, setFgoVerifyDuplicate] = useState(false)
  const [fgoPaymentType, setFgoPaymentType] = useState('')
  const [fgoNotes, setFgoNotes] = useState('')
  const [fgoInvoices, setFgoInvoices] = useState<TenantIssuedInvoice[]>([])
  const [fgoInvoicesLoading, setFgoInvoicesLoading] = useState(false)
  const [fgoTesting, setFgoTesting] = useState(false)
  const [fgoSaving, setFgoSaving] = useState(false)
  const [fgoDisconnecting, setFgoDisconnecting] = useState(false)

  // Doar un provider afișat: Oblio sau SmartBill
  const [selectedProvider, setSelectedProvider] = useState<'oblio' | 'smartbill' | 'fgo'>('oblio')

  useEffect(() => {
    setLoading(true)
    if (selectedProvider === 'oblio') {
      loadStatus().finally(() => setLoading(false))
    } else if (selectedProvider === 'smartbill') {
      loadSmartBillStatus().finally(() => setLoading(false))
    } else {
      loadFGOStatus().finally(() => setLoading(false))
    }
  }, [selectedProvider])

  const loadStatus = async () => {
    try {
      const s = await billingApi.getOblioStatus()
      setStatus(s)
      setEmail(s.oblio_client_id ?? '')
      setSelectedCompanyCif(s.selected_company_cif ?? '')
      setSelectedSeries(s.default_invoice_series ?? '')
      setSelectedInvoiceProductName(s.invoice_product_name ?? '')
      setSelectedVatPercentage(s.default_vat_percentage ?? '')
      setClientSecret('')
      setUpdateSecret(false)
    } catch (e) {
      setStatus({ provider: 'oblio', status: 'disconnected' })
      setMessage({ type: 'error', text: 'Eroare la încărcarea statusului Oblio.' })
    }
  }

  const loadSmartBillStatus = async () => {
    try {
      const settings = await billingApi.getTenantSmartBillSettings()
      const s: SmartBillStatusResponse = {
        provider: 'smartbill',
        status: settings.status,
        smartbill_email: settings.email ?? null,
        selected_company_cif: settings.companyCif ?? null,
        default_invoice_series: settings.defaultSeries ?? null,
        default_currency: settings.defaultCurrency ?? null,
        default_language: settings.defaultLanguage ?? null,
        default_is_tax_payer: settings.defaultIsTaxPayer ?? null,
        default_payment_method: settings.defaultPaymentMethod ?? null,
        default_notes: settings.defaultNotes ?? null,
        last_connection_check_at: settings.lastConnectionCheckAt ?? null,
        last_connection_status: settings.lastConnectionStatus ?? null,
        last_sync_at: settings.lastSyncAt ?? null,
        last_error: settings.lastError ?? null,
        enabled: settings.enabled,
      }
      setSbStatus(s)
      setSbEmail(settings.email ?? '')
      setSbCompanyCif(settings.companyCif ?? '')
      setSbSeries(settings.defaultSeries ?? '')
      setSbEnabled(Boolean(settings.enabled))
      setSbDefaultCurrency(settings.defaultCurrency || 'RON')
      setSbDefaultLanguage(settings.defaultLanguage || 'RO')
      setSbDefaultIsTaxPayer(Boolean(settings.defaultIsTaxPayer))
      setSbDefaultPaymentMethod(settings.defaultPaymentMethod || '')
      setSbDefaultNotes(settings.defaultNotes || '')
      setSbToken('')
    } catch {
      setSbStatus({ provider: 'smartbill', status: 'disconnected' })
    }
  }

  const loadFGOStatus = async () => {
    try {
      const s = await billingApi.getTenantFGOSettings()
      setFgoStatus(s)
      setFgoCodUnic(s.codUnic ?? '')
      setFgoPrivateKey('')
      setFgoPlatformUrl(s.platformaUrl ?? '')
      setFgoEnvironment((s.environment || 'test') as 'test' | 'production')
      setFgoSeries(s.defaultSeries ?? '')
      setFgoEnabled(Boolean(s.enabled))
      setFgoCurrency(s.defaultCurrency || 'RON')
      setFgoInvoiceType(s.defaultInvoiceType || 'invoice')
      setFgoDueDays(Number(s.defaultDueDays || 7))
      setFgoVerifyDuplicate(Boolean(s.verifyDuplicate))
      setFgoPaymentType(s.defaultPaymentType || '')
      setFgoNotes(s.defaultNotes || '')
    } catch {
      setFgoStatus({ provider: 'fgo', status: 'disconnected', enabled: false, environment: 'test' })
    }
  }

  // Încarcă seriile când avem o companie selectată și integrare (conectat sau credențiale salvate după test)
  useEffect(() => {
    const cif = selectedCompanyCif || status?.selected_company_cif
    if (!cif) {
      setSeries([])
      return
    }
    const hasIntegration = status?.status === 'connected' || status?.oblio_client_id
    if (hasIntegration) {
      billingApi.getOblioSeries(cif).then((r) => setSeries(r.series || [])).catch(() => setSeries([]))
    } else {
      setSeries([])
    }
  }, [status?.status, status?.oblio_client_id, status?.selected_company_cif, selectedCompanyCif])

  // Încarcă produsele/serviciile Oblio când avem companie selectată (pentru dropdown Serviciu factură)
  useEffect(() => {
    const cif = selectedCompanyCif || status?.selected_company_cif
    if (!cif) {
      setOblioProducts([])
      return
    }
    const hasIntegration = status?.status === 'connected' || status?.oblio_client_id
    if (!hasIntegration) {
      setOblioProducts([])
      return
    }
    setLoadingProducts(true)
    billingApi
      .getOblioProducts(cif)
      .then((r) => setOblioProducts(r.products || []))
      .catch(() => setOblioProducts([]))
      .finally(() => setLoadingProducts(false))
  }, [status?.status, status?.oblio_client_id, status?.selected_company_cif, selectedCompanyCif])

  useEffect(() => {
    if (sbStatus?.status === 'connected' && sbCompanyCif) {
      billingApi.getSmartBillSeries(sbCompanyCif).then((r) => setSbSeriesList(r.series || [])).catch(() => setSbSeriesList([]))
    } else {
      setSbSeriesList([])
    }
  }, [sbStatus?.status, sbCompanyCif])

  useEffect(() => {
    if (selectedProvider !== 'smartbill') return
    setSbInvoicesLoading(true)
    billingApi
      .getTenantBillingInvoices({ provider: 'smartbill' })
      .then((r) => setSbInvoices(r.items || []))
      .catch(() => setSbInvoices([]))
      .finally(() => setSbInvoicesLoading(false))
  }, [selectedProvider, sbStatus?.status])

  useEffect(() => {
    if (selectedProvider !== 'fgo') return
    setFgoInvoicesLoading(true)
    billingApi
      .getTenantBillingInvoices({ provider: 'fgo' })
      .then((r) => setFgoInvoices(r.items || []))
      .catch(() => setFgoInvoices([]))
      .finally(() => setFgoInvoicesLoading(false))
  }, [selectedProvider, fgoStatus?.status])

  const handleTest = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    const useForm = email && (clientSecret || (status?.status === 'connected' && updateSecret && clientSecret) || (status?.status === 'connected' && !updateSecret))
    if (!email) {
      setMessage({ type: 'error', text: 'Introdu adresa de email (client_id).' })
      return
    }
    if (!status?.oblio_client_id && !clientSecret) {
      setMessage({ type: 'error', text: 'Introdu API Secret-ul pentru a testa.' })
      return
    }
    if (status?.status === 'connected' && !updateSecret && !clientSecret) {
      setTesting(true)
      try {
        await billingApi.testOblio({})
        setMessage({ type: 'success', text: 'Conexiune reușită.' })
        await loadStatus()
      } catch (err: unknown) {
        const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Test eșuat.'
        setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Test eșuat.' })
      } finally {
        setTesting(false)
      }
      return
    }
    if (!clientSecret) {
      setMessage({ type: 'error', text: 'Introdu API Secret-ul.' })
      return
    }
    setTesting(true)
    try {
      const res = await billingApi.testOblio({ clientId: email, clientSecret })
      setMessage({ type: 'success', text: 'Conexiune reușită.' })
      const list = res.companies ?? []
      setCompanies(list)
      let firstCif: string | null = null
      if (list.length && !selectedCompanyCif) {
        firstCif = list[0]?.cif ?? list[0]?.id ?? null
        if (firstCif) setSelectedCompanyCif(String(firstCif))
      }
      await loadStatus()
      if (firstCif) {
        const seriesRes = await billingApi.getOblioSeries(String(firstCif))
        setSeries(seriesRes.series || [])
      }
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'API Secret invalid sau cont inexistent.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Test eșuat.' })
    } finally {
      setTesting(false)
    }
  }

  const loadCompanies = async () => {
    if (!email || !clientSecret && status?.status !== 'connected') return
    try {
      if (status?.status === 'connected' && !clientSecret) {
        const res = await billingApi.getOblioCompanies()
        setCompanies(res.companies || [])
        return
      }
      await handleTest({ preventDefault: () => {} } as React.FormEvent)
    } catch {
      // message already set
    }
  }

  const handleSeriesForCif = async (cif: string) => {
    if (!cif) return
    try {
      const hasIntegration = status?.status === 'connected' || status?.oblio_client_id
      if (hasIntegration) {
        const res = await billingApi.getOblioSeries(cif)
        setSeries(res.series || [])
      } else if (email && clientSecret) {
        const res = await billingApi.getOblioSeriesWithCredentials(cif, email, clientSecret)
        setSeries(res.series || [])
      } else {
        setSeries([])
      }
    } catch {
      setSeries([])
    }
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!email) {
      setMessage({ type: 'error', text: 'Email (client_id) este obligatoriu.' })
      return
    }
    if (!clientSecret && (!status?.oblio_client_id || status.status !== 'connected')) {
      setMessage({ type: 'error', text: 'API Secret este obligatoriu pentru conectare.' })
      return
    }
    if (!selectedCompanyCif) {
      setMessage({ type: 'error', text: 'Selectează o companie (CIF).' })
      return
    }
    if (!selectedSeries) {
      setMessage({ type: 'error', text: 'Selectează seria de factură implicită.' })
      return
    }
    setSaving(true)
    try {
      const body: {
        clientId: string
        clientSecret?: string
        companyCif: string
        defaultInvoiceSeries?: string
        invoiceProductName?: string
        defaultVatPercentage?: string
      } = {
        clientId: email,
        companyCif: selectedCompanyCif,
        defaultInvoiceSeries: selectedSeries || undefined,
      }
      if (clientSecret) body.clientSecret = clientSecret
      if (selectedInvoiceProductName) body.invoiceProductName = selectedInvoiceProductName
      if (selectedVatPercentage) body.defaultVatPercentage = selectedVatPercentage
      await billingApi.connectOblio(body)
      setMessage({ type: 'success', text: 'Oblio conectat cu succes. A devenit automat providerul folosit la facturare.' })
      await loadStatus()
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la conectare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la conectare.' })
    } finally {
      setSaving(false)
    }
  }

  const handleDisconnect = async () => {
    if (!confirm('Deconectezi contul Oblio? API Secret-ul va fi șters.')) return
    setDisconnecting(true)
    setMessage(null)
    try {
      await billingApi.disconnectOblio()
      setMessage({ type: 'success', text: 'Oblio deconectat.' })
      await loadStatus()
      setEmail('')
      setClientSecret('')
      setCompanies([])
      setSeries([])
      setSelectedCompanyCif('')
      setSelectedSeries('')
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la deconectare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la deconectare.' })
    } finally {
      setDisconnecting(false)
    }
  }

  const handleSbTest = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!sbEmail) {
      setMessage({ type: 'error', text: 'Introdu email-ul contului SmartBill.' })
      return
    }
    if (!sbStatus?.smartbill_email && !sbToken) {
      setMessage({ type: 'error', text: 'Introdu Token API pentru a testa.' })
      return
    }
    if (sbStatus?.status === 'connected' && !sbToken) {
      setSbTesting(true)
      try {
        await billingApi.testTenantSmartBillConnection({})
        setMessage({ type: 'success', text: 'Conexiune reușită.' })
        await loadSmartBillStatus()
      } catch (err: unknown) {
        const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Test eșuat.'
        setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Test eșuat.' })
      } finally {
        setSbTesting(false)
      }
      return
    }
    if (!sbToken || !sbCompanyCif) {
      setMessage({ type: 'error', text: 'Token API și CIF companie sunt obligatorii pentru test.' })
      return
    }
    setSbTesting(true)
    try {
      await billingApi.testTenantSmartBillConnection({ email: sbEmail, token: sbToken, companyCif: sbCompanyCif })
      setMessage({ type: 'success', text: 'Conexiune reușită.' })
      const r = await billingApi.getSmartBillSeries(sbCompanyCif)
      setSbSeriesList(r.series || [])
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Token invalid, CIF greșit sau rate limit. Încearcă din nou.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Test eșuat.' })
    } finally {
      setSbTesting(false)
    }
  }

  const handleSbSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!sbEmail) {
      setMessage({ type: 'error', text: 'Email-ul este obligatoriu.' })
      return
    }
    if (!sbToken && (!sbStatus?.smartbill_email || sbStatus.status !== 'connected')) {
      setMessage({ type: 'error', text: 'Token API este obligatoriu pentru conectare.' })
      return
    }
    if (!sbCompanyCif) {
      setMessage({ type: 'error', text: 'CIF-ul companiei este obligatoriu.' })
      return
    }
    if (!sbSeries) {
      setMessage({ type: 'error', text: 'Selectează seria de factură implicită.' })
      return
    }
    setSbSaving(true)
    try {
      await billingApi.saveTenantSmartBillSettings({
        email: sbEmail,
        token: sbToken || undefined,
        companyCif: sbCompanyCif,
        defaultSeries: sbSeries || undefined,
        enabled: sbEnabled,
        defaultCurrency: sbDefaultCurrency || 'RON',
        defaultLanguage: sbDefaultLanguage || 'RO',
        defaultIsTaxPayer: sbDefaultIsTaxPayer,
        defaultPaymentMethod: sbDefaultPaymentMethod || undefined,
        defaultNotes: sbDefaultNotes || undefined,
      })
      if (sbStatus?.status !== 'connected') {
        await billingApi.connectSmartBill({
          email: sbEmail,
          token: sbToken || undefined,
          companyCif: sbCompanyCif,
          defaultSeries: sbSeries || undefined,
          enabled: sbEnabled,
          defaultCurrency: sbDefaultCurrency || 'RON',
          defaultLanguage: sbDefaultLanguage || 'RO',
          defaultIsTaxPayer: sbDefaultIsTaxPayer,
          defaultPaymentMethod: sbDefaultPaymentMethod || undefined,
          defaultNotes: sbDefaultNotes || undefined,
        })
      }
      setMessage({ type: 'success', text: 'Setările SmartBill au fost salvate cu succes.' })
      await loadSmartBillStatus()
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la conectare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la conectare.' })
    } finally {
      setSbSaving(false)
    }
  }

  const handleSbDisconnect = async () => {
    if (!confirm('Deconectezi SmartBill? Token-ul va fi șters.')) return
    setSbDisconnecting(true)
    setMessage(null)
    try {
      await billingApi.disconnectSmartBill()
      setMessage({ type: 'success', text: 'SmartBill deconectat.' })
      await loadSmartBillStatus()
      setSbEmail('')
      setSbToken('')
      setSbCompanyCif('')
      setSbSeries('')
      setSbSeriesList([])
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la deconectare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la deconectare.' })
    } finally {
      setSbDisconnecting(false)
    }
  }

  const handleFgoTest = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!fgoCodUnic) {
      setMessage({ type: 'error', text: 'CodUnic/CUI este obligatoriu.' })
      return
    }
    if (!fgoPrivateKey && fgoStatus?.status !== 'connected') {
      setMessage({ type: 'error', text: 'PrivateKey este obligatoriu pentru test inițial.' })
      return
    }
    setFgoTesting(true)
    try {
      await billingApi.testTenantFGOConnection({
        codUnic: fgoCodUnic,
        privateKey: fgoPrivateKey || undefined,
        platformaUrl: fgoPlatformUrl || undefined,
        environment: fgoEnvironment,
      })
      setMessage({ type: 'success', text: 'Conexiune FGO validă.' })
      await loadFGOStatus()
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Test eșuat.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Test eșuat.' })
    } finally {
      setFgoTesting(false)
    }
  }

  const handleFgoSave = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!fgoCodUnic) {
      setMessage({ type: 'error', text: 'CodUnic/CUI este obligatoriu.' })
      return
    }
    if (!fgoPrivateKey && fgoStatus?.status !== 'connected') {
      setMessage({ type: 'error', text: 'PrivateKey este obligatoriu pentru conectare.' })
      return
    }
    setFgoSaving(true)
    try {
      await billingApi.saveTenantFGOSettings({
        codUnic: fgoCodUnic,
        privateKey: fgoPrivateKey || undefined,
        platformaUrl: fgoPlatformUrl || undefined,
        environment: fgoEnvironment,
        defaultSeries: fgoSeries || undefined,
        enabled: fgoEnabled,
        defaultCurrency: fgoCurrency || 'RON',
        defaultInvoiceType: fgoInvoiceType || 'invoice',
        defaultDueDays: fgoDueDays || 7,
        verifyDuplicate: fgoVerifyDuplicate,
        defaultPaymentType: fgoPaymentType || undefined,
        defaultNotes: fgoNotes || undefined,
      })
      await billingApi.setActiveProvider('fgo')
      setMessage({ type: 'success', text: 'Setările FGO au fost salvate cu succes.' })
      await loadFGOStatus()
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la salvare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la salvare.' })
    } finally {
      setFgoSaving(false)
    }
  }

  const handleFgoDisconnect = async () => {
    if (!confirm('Deconectezi FGO? PrivateKey-ul va fi șters.')) return
    setFgoDisconnecting(true)
    setMessage(null)
    try {
      await billingApi.disconnectTenantFGO()
      setMessage({ type: 'success', text: 'FGO deconectat.' })
      await loadFGOStatus()
      setFgoPrivateKey('')
      setFgoEnabled(false)
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail || 'Eroare la deconectare.'
      setMessage({ type: 'error', text: typeof msg === 'string' ? msg : 'Eroare la deconectare.' })
    } finally {
      setFgoDisconnecting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
      </div>
    )
  }

  const statusBadge =
    status?.status === 'connected'
      ? { label: 'Conectat', class: 'bg-green-100 text-green-800' }
      : status?.status === 'error'
        ? { label: 'Eroare', class: 'bg-red-100 text-red-800' }
        : { label: 'Deconectat', class: 'bg-gray-100 text-gray-700' }

  return (
    <div className="space-y-6">
      {message && (
        <div
          className={`rounded-lg p-4 ${message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}
        >
          {message.text}
        </div>
      )}

      <div className="rounded-xl border border-gray-200 bg-white shadow-sm overflow-hidden">
        <div className="border-b border-gray-200 bg-gray-50/80 px-6 py-4">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Integrare facturare</h2>
          </div>
          <p className="mt-1 text-sm text-gray-600">
            Conectează un provider de facturare pentru emiterea automată a facturilor. Alege Oblio, SmartBill sau FGO și configurează credențialele.
          </p>
          {/* Selector provider: doar unul vizibil */}
          <div className="mt-4 flex gap-1 rounded-lg border border-gray-200 bg-white p-1 w-fit">
            <button
              type="button"
              onClick={() => setSelectedProvider('oblio')}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors ${
                selectedProvider === 'oblio'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              Oblio
            </button>
            <button
              type="button"
              onClick={() => setSelectedProvider('smartbill')}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors ${
                selectedProvider === 'smartbill'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              SmartBill
            </button>
            <button
              type="button"
              onClick={() => setSelectedProvider('fgo')}
              className={`rounded-md px-4 py-2 text-sm font-medium transition-colors ${
                selectedProvider === 'fgo'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              FGO
            </button>
          </div>
        </div>
        <div className="p-6 space-y-6">
          {/* Oblio card – afișat doar când e ales Oblio */}
          {selectedProvider === 'oblio' && (
          <div className="rounded-lg border border-gray-200 bg-white p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <h3 className="font-semibold text-gray-900">Oblio</h3>
              <div className="flex items-center gap-2">
                <span className={`rounded-full px-3 py-1 text-xs font-medium ${statusBadge.class}`}>
                  {statusBadge.label}
                  {status?.last_test_at && (
                    <span className="ml-2 text-gray-500">
                      (testat: {new Date(status.last_test_at).toLocaleString('ro-RO')})
                    </span>
                  )}
                </span>
              </div>
            </div>
            {status?.last_error && (
              <p className="mb-3 text-sm text-red-600">Ultima eroare: {status.last_error}</p>
            )}

            <form onSubmit={handleTest} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email (client_id)</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="email@exemplu.ro"
                  autoComplete="email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">API Secret (client_secret)</label>
                <p className="text-xs text-gray-500 mb-1">În Oblio: Setări → Date cont. Copiază token-ul (nu parola contului).</p>
                <input
                  type="password"
                  value={clientSecret}
                  onChange={(e) => setClientSecret(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder={status?.status === 'connected' ? 'Lăsați gol pentru a păstra secretul; bifați „Actualizează secret” pentru a-l schimba' : 'Token din Setări → Date cont'}
                  autoComplete="off"
                />
                {status?.status === 'connected' && (
                  <label className="mt-2 flex items-center gap-2 text-sm text-gray-600">
                    <input
                      type="checkbox"
                      checked={updateSecret}
                      onChange={(e) => setUpdateSecret(e.target.checked)}
                    />
                    Actualizează secret
                  </label>
                )}
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  disabled={testing}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
                >
                  {testing ? 'Se testează...' : 'Testează conexiunea'}
                </button>
                {companies.length === 0 && (email && clientSecret || status?.status === 'connected') && (
                  <button
                    type="button"
                    onClick={loadCompanies}
                    disabled={testing}
                    className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 disabled:opacity-50"
                  >
                    Încarcă companiile
                  </button>
                )}
              </div>
            </form>

            {companies.length > 0 && (
              <>
                <div className="mt-4">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Companie (CIF)</label>
                  <select
                    value={selectedCompanyCif}
                    onChange={(e) => {
                      const cif = e.target.value
                      setSelectedCompanyCif(cif)
                      handleSeriesForCif(cif)
                    }}
                    className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="">Selectează compania</option>
                    {companies.map((c) => {
                      const cifVal = String(c.cif ?? c.id ?? '')
                      const label = [c.name, c.cif].filter(Boolean).join(' — ') || cifVal || 'Companie'
                      return (
                        <option key={cifVal || `company-${c.id}`} value={cifVal}>
                          {label}
                        </option>
                      )
                    })}
                  </select>
                </div>
                {(series.length > 0 || selectedCompanyCif) && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Serie factură implicită</label>
                    <select
                      value={selectedSeries}
                      onChange={(e) => setSelectedSeries(e.target.value)}
                      className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                    >
                      <option value="">Selectează seria</option>
                      {series.map((s) => {
                        const name = s.name ?? s.seriesName ?? ''
                        return (
                          <option key={name} value={name}>
                            {name}
                          </option>
                        )
                      })}
                    </select>
                  </div>
                )}
                {/* Serviciu factură – listă din Oblio */}
                {(selectedCompanyCif || status?.selected_company_cif) && (status?.status === 'connected' || status?.oblio_client_id) && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Serviciu factură (din Oblio)</label>
                    {loadingProducts ? (
                      <p className="text-sm text-gray-500">Se încarcă serviciile...</p>
                    ) : (
                      <select
                        value={selectedInvoiceProductName}
                        onChange={(e) => {
                          const val = e.target.value
                          setSelectedInvoiceProductName(val)
                          const product = oblioProducts.find((p) => (p.name ?? '') === val)
                          if (product != null && product.vatPercentage != null) {
                            setSelectedVatPercentage(String(product.vatPercentage))
                          }
                        }}
                        className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                      >
                        <option value="">— Nume personalizat mai jos sau fără —</option>
                        {oblioProducts.map((p) => {
                          const name = p.name ?? p.code ?? ''
                          const vat = p.vatPercentage != null ? ` (TVA ${p.vatPercentage}%)` : ''
                          return (
                            <option key={p.id ?? name ?? p.code ?? Math.random()} value={name}>
                              {name}{vat}
                            </option>
                          )
                        })}
                      </select>
                    )}
                    <p className="mt-1 text-xs text-gray-500">
                      Opțional: alege un serviciu din Oblio sau lasă liber și folosește numele implicit la facturare.
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                      <label className="text-sm text-gray-600">TVA %:</label>
                      <select
                        value={selectedVatPercentage}
                        onChange={(e) => setSelectedVatPercentage(e.target.value)}
                        className="rounded border border-gray-300 px-2 py-1 text-sm"
                      >
                        <option value="">—</option>
                        <option value="0">0</option>
                        <option value="5">5</option>
                        <option value="11">11</option>
                        <option value="9">9</option>
                        <option value="19">19</option>
                      </select>
                    </div>
                  </div>
                )}
              </>
            )}

            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleSave}
                disabled={
                  saving ||
                  !email ||
                  !selectedCompanyCif ||
                  !selectedSeries ||
                  (status?.status !== 'connected' && !clientSecret && !status?.oblio_client_id)
                }
                className="rounded-full bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-purple-700 disabled:opacity-50"
              >
                {saving ? 'Se salvează...' : 'Salvează / Conectează'}
              </button>
              {status?.status === 'connected' && (
                <button
                  type="button"
                  onClick={handleDisconnect}
                  disabled={disconnecting}
                  className="rounded-lg border border-red-300 bg-white px-4 py-2.5 text-sm text-red-700 hover:bg-red-50 disabled:opacity-50"
                >
                  {disconnecting ? 'Se deconectează...' : 'Deconectează'}
                </button>
              )}
            </div>
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-800 mb-2">Istoric facturi SmartBill</h4>
              {sbInvoicesLoading ? (
                <p className="text-sm text-gray-500">Se încarcă istoricul...</p>
              ) : sbInvoices.length === 0 ? (
                <p className="text-sm text-gray-500">Nu există facturi SmartBill emise încă.</p>
              ) : (
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Număr</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Sursă</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Status</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Data</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sbInvoices.map((inv) => (
                        <tr key={inv.id} className="border-t border-gray-100">
                          <td className="px-3 py-2">
                            {inv.link ? (
                              <a className="text-indigo-600 hover:underline" href={inv.link} target="_blank" rel="noreferrer">
                                {inv.invoiceNumber}
                              </a>
                            ) : (
                              inv.invoiceNumber
                            )}
                          </td>
                          <td className="px-3 py-2">{inv.sourceType || '-'} {inv.sourceId ? `(${inv.sourceId.slice(0, 8)})` : ''}</td>
                          <td className="px-3 py-2">{inv.status || '-'}</td>
                          <td className="px-3 py-2">{inv.issuedAt ? new Date(inv.issuedAt).toLocaleString('ro-RO') : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
          )}

          {/* SmartBill card – afișat doar când e ales SmartBill */}
          {selectedProvider === 'smartbill' && (
          <div className="rounded-lg border border-gray-200 bg-white p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <h3 className="font-semibold text-gray-900">SmartBill</h3>
              <div className="flex items-center gap-2">
                <span
                  className={`rounded-full px-3 py-1 text-xs font-medium ${
                    sbStatus?.status === 'connected'
                      ? 'bg-green-100 text-green-800'
                      : sbStatus?.status === 'error'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {sbStatus?.status === 'connected' ? 'Conectat' : sbStatus?.status === 'error' ? 'Eroare' : 'Deconectat'}
                  {sbStatus?.last_test_at && (
                    <span className="ml-2 text-gray-500">(testat: {new Date(sbStatus.last_test_at).toLocaleString('ro-RO')})</span>
                  )}
                </span>
              </div>
            </div>
            {sbStatus?.last_error && <p className="mb-3 text-sm text-red-600">Ultima eroare: {sbStatus.last_error}</p>}
            <form onSubmit={handleSbTest} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={sbEmail}
                  onChange={(e) => setSbEmail(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="email@exemplu.ro"
                  autoComplete="email"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Token API</label>
                <input
                  type="password"
                  value={sbToken}
                  onChange={(e) => setSbToken(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder={sbStatus?.status === 'connected' ? 'Lăsați gol pentru a păstra token-ul' : 'Token din Contul meu → Integrări → API'}
                  autoComplete="off"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">CIF companie</label>
                <input
                  type="text"
                  value={sbCompanyCif}
                  onChange={(e) => setSbCompanyCif(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="RO12345678"
                />
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  disabled={sbTesting}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
                >
                  {sbTesting ? 'Se testează...' : 'Testează conexiunea'}
                </button>
              </div>
            </form>
            {sbSeriesList.length > 0 && (
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Serie factură implicită</label>
                <select
                  value={sbSeries}
                  onChange={(e) => setSbSeries(e.target.value)}
                  className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="">Selectează seria</option>
                  {sbSeriesList.map((s) => {
                    const name = s.name ?? s.seriesName ?? ''
                    return (
                      <option key={name} value={name}>
                        {name}
                      </option>
                    )
                  })}
                </select>
              </div>
            )}
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monedă implicită</label>
                <input
                  type="text"
                  value={sbDefaultCurrency}
                  onChange={(e) => setSbDefaultCurrency(e.target.value.toUpperCase())}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="RON"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Limbă implicită</label>
                <select
                  value={sbDefaultLanguage}
                  onChange={(e) => setSbDefaultLanguage(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="RO">RO</option>
                  <option value="EN">EN</option>
                  <option value="HU">HU</option>
                  <option value="DE">DE</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Metodă de plată implicită</label>
                <input
                  type="text"
                  value={sbDefaultPaymentMethod}
                  onChange={(e) => setSbDefaultPaymentMethod(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="Transfer bancar"
                />
              </div>
              <div className="flex items-center pt-8">
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={sbDefaultIsTaxPayer}
                    onChange={(e) => setSbDefaultIsTaxPayer(e.target.checked)}
                  />
                  Client contribuabil implicit
                </label>
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Note implicite factură</label>
              <textarea
                value={sbDefaultNotes}
                onChange={(e) => setSbDefaultNotes(e.target.value)}
                rows={2}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                placeholder="Mulțumim pentru rezervare."
              />
            </div>
            <div className="mt-3">
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={sbEnabled}
                  onChange={(e) => setSbEnabled(e.target.checked)}
                />
                Activează integrarea SmartBill
              </label>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleSbSave}
                disabled={sbSaving || !sbEmail || !sbCompanyCif || !sbSeries || (sbStatus?.status !== 'connected' && !sbToken)}
                className="rounded-full bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-purple-700 disabled:opacity-50"
              >
                {sbSaving ? 'Se salvează...' : 'Salvează / Conectează'}
              </button>
              {sbStatus?.status === 'connected' && (
                <button
                  type="button"
                  onClick={handleSbDisconnect}
                  disabled={sbDisconnecting}
                  className="rounded-lg border border-red-300 bg-white px-4 py-2.5 text-sm text-red-700 hover:bg-red-50 disabled:opacity-50"
                >
                  {sbDisconnecting ? 'Se deconectează...' : 'Deconectează'}
                </button>
              )}
            </div>
          </div>
          )}

          {selectedProvider === 'fgo' && (
          <div className="rounded-lg border border-gray-200 bg-white p-5">
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <h3 className="font-semibold text-gray-900">FGO</h3>
              <span
                className={`rounded-full px-3 py-1 text-xs font-medium ${
                  fgoStatus?.status === 'connected'
                    ? 'bg-green-100 text-green-800'
                    : fgoStatus?.status === 'error'
                      ? 'bg-red-100 text-red-800'
                      : 'bg-gray-100 text-gray-700'
                }`}
              >
                {fgoStatus?.status === 'connected' ? 'Conectat' : fgoStatus?.status === 'error' ? 'Eroare' : 'Deconectat'}
              </span>
            </div>
            {fgoStatus?.lastError && <p className="mb-3 text-sm text-red-600">Ultima eroare: {fgoStatus.lastError}</p>}
            <form onSubmit={handleFgoTest} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CodUnic / CUI</label>
                  <input
                    type="text"
                    value={fgoCodUnic}
                    onChange={(e) => setFgoCodUnic(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                    placeholder="RO12345678"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">PrivateKey</label>
                  <input
                    type="password"
                    value={fgoPrivateKey}
                    onChange={(e) => setFgoPrivateKey(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                    placeholder={fgoStatus?.status === 'connected' ? 'Lăsați gol pentru a păstra cheia' : 'PrivateKey FGO'}
                    autoComplete="off"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">PlatformaUrl</label>
                  <input
                    type="text"
                    value={fgoPlatformUrl}
                    onChange={(e) => setFgoPlatformUrl(e.target.value)}
                    className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                    placeholder="https://api-test.fgo.ro"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Environment</label>
                  <select
                    value={fgoEnvironment}
                    onChange={(e) => setFgoEnvironment((e.target.value as 'test' | 'production'))}
                    className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="test">TEST</option>
                    <option value="production">PRODUCTION</option>
                  </select>
                </div>
              </div>
              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  disabled={fgoTesting}
                  className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:opacity-50"
                >
                  {fgoTesting ? 'Se testează...' : 'Testează conexiunea'}
                </button>
              </div>
            </form>
            <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Serie implicită</label>
                <input
                  type="text"
                  value={fgoSeries}
                  onChange={(e) => setFgoSeries(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="FACT"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Monedă implicită</label>
                <input
                  type="text"
                  value={fgoCurrency}
                  onChange={(e) => setFgoCurrency(e.target.value.toUpperCase())}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="RON"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tip factură implicit</label>
                <input
                  type="text"
                  value={fgoInvoiceType}
                  onChange={(e) => setFgoInvoiceType(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="invoice"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Scadență (zile)</label>
                <input
                  type="number"
                  min={0}
                  value={fgoDueDays}
                  onChange={(e) => setFgoDueDays(Number(e.target.value || 0))}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tip plată implicit</label>
                <input
                  type="text"
                  value={fgoPaymentType}
                  onChange={(e) => setFgoPaymentType(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                  placeholder="transfer"
                />
              </div>
              <div className="flex items-center pt-8">
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={fgoVerifyDuplicate}
                    onChange={(e) => setFgoVerifyDuplicate(e.target.checked)}
                  />
                  Verifică duplicate înainte de emitere
                </label>
              </div>
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Note implicite</label>
              <textarea
                value={fgoNotes}
                onChange={(e) => setFgoNotes(e.target.value)}
                rows={2}
                className="w-full rounded-lg border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                placeholder="Mulțumim pentru rezervare."
              />
            </div>
            <div className="mt-3">
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={fgoEnabled}
                  onChange={(e) => setFgoEnabled(e.target.checked)}
                />
                Activează integrarea FGO
              </label>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                onClick={handleFgoSave}
                disabled={fgoSaving || !fgoCodUnic || (fgoStatus?.status !== 'connected' && !fgoPrivateKey)}
                className="rounded-full bg-purple-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-purple-700 disabled:opacity-50"
              >
                {fgoSaving ? 'Se salvează...' : 'Salvează / Conectează'}
              </button>
              {fgoStatus?.status === 'connected' && (
                <button
                  type="button"
                  onClick={handleFgoDisconnect}
                  disabled={fgoDisconnecting}
                  className="rounded-lg border border-red-300 bg-white px-4 py-2.5 text-sm text-red-700 hover:bg-red-50 disabled:opacity-50"
                >
                  {fgoDisconnecting ? 'Se deconectează...' : 'Deconectează'}
                </button>
              )}
            </div>
            <div className="mt-6">
              <h4 className="text-sm font-semibold text-gray-800 mb-2">Istoric facturi FGO</h4>
              {fgoInvoicesLoading ? (
                <p className="text-sm text-gray-500">Se încarcă istoricul...</p>
              ) : fgoInvoices.length === 0 ? (
                <p className="text-sm text-gray-500">Nu există facturi FGO emise încă.</p>
              ) : (
                <div className="overflow-x-auto border border-gray-200 rounded-lg">
                  <table className="min-w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Număr</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Sursă</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Status</th>
                        <th className="text-left px-3 py-2 font-medium text-gray-700">Data</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fgoInvoices.map((inv) => (
                        <tr key={inv.id} className="border-t border-gray-100">
                          <td className="px-3 py-2">
                            {inv.link ? (
                              <a className="text-indigo-600 hover:underline" href={inv.link} target="_blank" rel="noreferrer">
                                {inv.invoiceNumber}
                              </a>
                            ) : (
                              inv.invoiceNumber
                            )}
                          </td>
                          <td className="px-3 py-2">{inv.sourceType || '-'} {inv.sourceId ? `(${inv.sourceId.slice(0, 8)})` : ''}</td>
                          <td className="px-3 py-2">{inv.status || '-'}</td>
                          <td className="px-3 py-2">{inv.issuedAt ? new Date(inv.issuedAt).toLocaleString('ro-RO') : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
          )}

          <p className="text-sm text-gray-500 mt-6">
            <Link to={DOCS_LINK} className="text-indigo-600 hover:underline">
              Documentație și tutoriale – Oblio & SmartBill
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
