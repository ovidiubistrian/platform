/**
 * Subscription Page - Admin
 */
import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import {
  CreditCard,
  Check,
  X,
  Star,
  Zap,
  Crown,
  Gift,
  ArrowLeft,
  Package as PackageIcon,
  MessageSquare,
  Mail,
  AtSign,
} from 'lucide-react'
import {
  subscriptionsApi,
  type SubscriptionPlan,
  type CurrentSubscription,
  type AddOnPackage,
  type AddOnType,
  type TenantAddOnAssignment,
  type AccessStatus,
} from '../../lib/api/subscriptions'
import { trialApi } from '../../lib/api/trial'
import AdminLayout from '../../components/layouts/AdminLayout'
import PlanLimitsCard from '../../components/admin/PlanLimitsCard'

const ADDON_TYPE_LABEL: Record<AddOnType, string> = {
  sms_pack: 'SMS campanii',
  email_pack: 'Email campanii',
  business_email: 'Business Email',
}

const ADDON_TYPE_ICON: Record<AddOnType, React.ComponentType<{ className?: string }>> = {
  sms_pack: MessageSquare,
  email_pack: Mail,
  business_email: AtSign,
}

const ADDON_TYPE_ORDER: AddOnType[] = ['sms_pack', 'email_pack', 'business_email']

interface TrialStatus {
  tenant: {
    id: string
    name: string
    status: string
    subscriptionPlan: string
  }
  trial: {
    endDate?: string
    daysRemaining: number
    isExpired: boolean
    isExpiringSoon: boolean
    isActive: boolean
  }
}

export default function SubscriptionPage() {
  const navigate = useNavigate()
  const [searchParams, setSearchParams] = useSearchParams()
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [currentSubscription, setCurrentSubscription] = useState<CurrentSubscription | null>(null)
  const [trialStatus, setTrialStatus] = useState<TrialStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [processing, setProcessing] = useState(false)
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('monthly')
  const [addOns, setAddOns] = useState<AddOnPackage[]>([])
  const [myAddOns, setMyAddOns] = useState<TenantAddOnAssignment[]>([])
  const [buyingAddonId, setBuyingAddonId] = useState<string | null>(null)
  const [accessStatus, setAccessStatus] = useState<AccessStatus | null>(null)
  const [postponing, setPostponing] = useState(false)
  const [requestingExtension, setRequestingExtension] = useState(false)

  useEffect(() => {
    fetchData()
  }, [])

  // After Stripe Checkout redirect: show message and clear ?success=1 or ?cancel=1
  useEffect(() => {
    const success = searchParams.get('success')
    const cancel = searchParams.get('cancel')
    const addonSuccess = searchParams.get('addon_success')
    const addonCancel = searchParams.get('addon_cancel')
    if (success === '1') {
      setSearchParams({}, { replace: true })
      fetchData()
      alert('✅ Payment successful! Your subscription is active.')
    } else if (cancel === '1') {
      setSearchParams({}, { replace: true })
    } else if (addonSuccess === '1') {
      setSearchParams({}, { replace: true })
      fetchData()
      alert('✅ Pachet add-on activat cu succes!')
    } else if (addonCancel === '1') {
      setSearchParams({}, { replace: true })
    }
  }, [searchParams])

  const fetchData = async () => {
    setLoading(true)
    try {
      const [plansData, subscriptionData, trialData, addOnsData, myAddOnsData, accessData] = await Promise.all([
        subscriptionsApi.getPlans(),
        subscriptionsApi.getCurrent().catch(() => null),
        trialApi.getStatus().catch(() => null),
        subscriptionsApi.getAddOns(),
        subscriptionsApi.getMyAddOns(),
        subscriptionsApi.getAccessStatus(),
      ])
      setPlans(plansData)
      setCurrentSubscription(subscriptionData)
      setTrialStatus(trialData)
      setAddOns(addOnsData)
      setMyAddOns(myAddOnsData)
      setAccessStatus(accessData)
    } catch (error) {
      console.error('Error fetching subscription data:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubscribe = async (planId: string) => {
    setProcessing(true)
    try {
      const result = await subscriptionsApi.subscribe(planId, billingInterval)
      if (result?.url) {
        window.location.href = result.url
        return
      }
      alert('✅ Subscription successful!')
      fetchData()
    } catch (error) {
      console.error('Error subscribing:', error)
      alert('❌ Error subscribing to plan')
    } finally {
      setProcessing(false)
    }
  }

  const handlePostpone = async () => {
    setPostponing(true)
    try {
      const snap = await subscriptionsApi.postponePayment()
      setAccessStatus(snap)
      if (snap.access === 'blocked') {
        alert('Ai atins numărul maxim de amânări. Accesul la admin va fi blocat.')
      }
    } catch (err: any) {
      alert(err?.response?.data?.detail || '❌ Nu am putut amâna plata.')
    } finally {
      setPostponing(false)
    }
  }

  const handleRequestExtension = async () => {
    setRequestingExtension(true)
    try {
      await subscriptionsApi.requestExtension()
      const snap = await subscriptionsApi.getAccessStatus()
      setAccessStatus(snap)
      alert('✅ Cererea a fost trimisă. Vei primi răspuns de la administrator.')
    } catch (err: any) {
      alert(err?.response?.data?.detail || '❌ Nu am putut trimite cererea.')
    } finally {
      setRequestingExtension(false)
    }
  }

  const handleBuyAddOn = async (pkg: AddOnPackage) => {
    setBuyingAddonId(pkg.id)
    try {
      const result = await subscriptionsApi.buyAddOn(pkg.id)
      if (result?.url) {
        window.location.href = result.url
        return
      }
      alert('✅ Pachet activat cu succes.')
      fetchData()
    } catch (error: any) {
      console.error('Error buying addon:', error)
      alert(error?.response?.data?.detail || '❌ Eroare la achiziția pachetului')
    } finally {
      setBuyingAddonId(null)
    }
  }

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel your subscription?')) return

    try {
      await subscriptionsApi.cancel()
      alert('✅ Subscription cancelled')
      fetchData()
    } catch (error) {
      console.error('Error cancelling subscription:', error)
      alert('❌ Error cancelling subscription')
    }
  }

  const getPlanIcon = (name: string) => {
    if (name.toLowerCase().includes('basic')) return <Zap className="w-6 h-6" />
    if (name.toLowerCase().includes('pro')) return <Star className="w-6 h-6" />
    if (name.toLowerCase().includes('enterprise')) return <Crown className="w-6 h-6" />
    return <Gift className="w-6 h-6" />
  }

  return (
    <AdminLayout>
      <div className="p-6">
        {/* Header */}
        <div className="mb-6">
          <button
            onClick={() => navigate('/admin')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Subscription</h1>
              <p className="text-gray-600 mt-1">Manage your subscription plan</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setBillingInterval('monthly')}
                className={`px-4 py-2 rounded-lg ${
                  billingInterval === 'monthly'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingInterval('yearly')}
                className={`px-4 py-2 rounded-lg ${
                  billingInterval === 'yearly'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700'
                }`}
              >
                Yearly
              </button>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <PlanLimitsCard />
        </div>

        {/* Access gate banner — shown when subscription is expired and the
            access gate is enforced. Gives the tenant a clear path: pay,
            postpone up to N times, or request a one-month extension. */}
        {accessStatus && accessStatus.enforce && accessStatus.access !== 'allowed' && (
          <div className={`mb-6 rounded-lg border p-4 ${
            accessStatus.access === 'blocked'
              ? 'bg-red-50 border-red-200'
              : 'bg-amber-50 border-amber-200'
          }`}>
            <div className="flex items-start justify-between gap-4 flex-wrap">
              <div className="min-w-0">
                <h3 className={`font-semibold ${
                  accessStatus.access === 'blocked' ? 'text-red-900' : 'text-amber-900'
                }`}>
                  {accessStatus.access === 'blocked'
                    ? 'Acces blocat'
                    : 'Plată restantă'}
                </h3>
                <p className={`text-sm mt-1 ${
                  accessStatus.access === 'blocked' ? 'text-red-700' : 'text-amber-800'
                }`}>
                  {accessStatus.reason || 'Abonamentul tău a expirat.'}
                </p>
                <p className="text-xs text-gray-600 mt-2">
                  Plan: <b>{accessStatus.subscriptionPlan || '—'}</b>
                  {accessStatus.subscriptionEndsAt && (
                    <> · Expirat la <b>{new Date(accessStatus.subscriptionEndsAt).toLocaleDateString('ro-RO')}</b></>
                  )}
                  {' · '}Amânări folosite: <b>{accessStatus.loginPostExpiryCount}/{accessStatus.maxPostpones}</b>
                </p>
                {accessStatus.pendingExtensionId && (
                  <p className="text-xs text-indigo-700 mt-1">
                    Ai o cerere de amânare în așteptare. Revenim cu răspuns.
                  </p>
                )}
              </div>
              {accessStatus.access === 'payment_required' && (
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={handlePostpone}
                    disabled={postponing || accessStatus.loginPostExpiryCount >= accessStatus.maxPostpones}
                    className="px-4 py-2 rounded-lg text-sm font-medium bg-white border border-amber-300 text-amber-900 hover:bg-amber-100 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {postponing ? 'Se procesează…' : `Amână (${accessStatus.loginPostExpiryCount}/${accessStatus.maxPostpones})`}
                  </button>
                  <button
                    onClick={handleRequestExtension}
                    disabled={requestingExtension || !!accessStatus.pendingExtensionId}
                    className="px-4 py-2 rounded-lg text-sm font-medium bg-white border border-amber-300 text-amber-900 hover:bg-amber-100 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {requestingExtension
                      ? 'Se trimite…'
                      : accessStatus.pendingExtensionId
                        ? 'Cerere trimisă'
                        : 'Cere amânare 1 lună'}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Trial Status */}
        {trialStatus && trialStatus.trial.isActive && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-blue-900">Trial Active</h3>
                <p className="text-sm text-blue-700">
                  {trialStatus.trial.daysRemaining} days remaining
                </p>
              </div>
              {trialStatus.trial.endDate && (
                <div className="text-sm text-blue-600">
                  Ends: {new Date(trialStatus.trial.endDate).toLocaleDateString()}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Current Subscription */}
        {currentSubscription && (
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold text-gray-900">Current Plan</h2>
                <p className="text-gray-600">{currentSubscription.plan.name}</p>
                <p className="text-sm text-gray-500 mt-1">
                  Renews: {new Date(currentSubscription.currentPeriodEnd).toLocaleDateString()}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  currentSubscription.status === 'active'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {currentSubscription.status}
                </span>
                <button
                  onClick={handleCancel}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Plans Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Loading plans...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div
                key={plan.id}
                className={`bg-white rounded-lg shadow p-6 ${
                  currentSubscription?.plan.id === plan.id ? 'ring-2 ring-blue-500' : ''
                }`}
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    {getPlanIcon(plan.name)}
                    <h3 className="text-xl font-semibold text-gray-900 ml-2">{plan.name}</h3>
                  </div>
                  {currentSubscription?.plan.id === plan.id && (
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                      Current
                    </span>
                  )}
                </div>

                <div className="mb-4">
                  <div className="text-3xl font-bold text-gray-900">
                    {billingInterval === 'monthly'
                      ? `${plan.monthlyPrice} ${plan.currency}`
                      : `${plan.yearlyPrice} ${plan.currency}`}
                  </div>
                  <div className="text-sm text-gray-500">per {billingInterval === 'monthly' ? 'month' : 'year'}</div>
                </div>

                {plan.description && (
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                )}

                <div className="space-y-2 mb-6">
                  {plan.maxProperties > 0 && (
                    <div className="flex items-center text-sm">
                      <Check className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                      <span>
                        {plan.maxProperties} {plan.maxProperties === 1 ? 'proprietate' : 'proprietăți'}
                      </span>
                    </div>
                  )}
                  {plan.maxUnits > 0 && (
                    <div className="flex items-center text-sm">
                      <Check className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                      <span>
                        Până la {plan.maxUnits} {plan.maxUnits === 1 ? 'unitate' : 'unități'}
                      </span>
                    </div>
                  )}
                  <div className="flex items-center text-sm">
                    <Check className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                    <span>Rezervări directe nelimitate</span>
                  </div>
                  {(() => {
                    if (!plan.features) return null
                    let labels: string[] = []
                    try {
                      const parsed = typeof plan.features === 'string' ? JSON.parse(plan.features) : plan.features
                      labels = Array.isArray(parsed) ? parsed.map((x: any) => String(x)) : []
                    } catch {
                      labels = []
                    }
                    return labels.slice(0, 8).map((f, i) => (
                      <div key={i} className="flex items-start text-sm">
                        <Check className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{f.replace(/^✅\s*/, '')}</span>
                      </div>
                    ))
                  })()}
                </div>

                {(() => {
                  const isFreePlan = (plan.name || '').trim().toLowerCase() === 'free'
                  const freeUsed = Boolean(currentSubscription?.freePlanUsedAt)
                  const freeLocked = isFreePlan && freeUsed && currentSubscription?.plan.id !== plan.id
                  const isCurrent = currentSubscription?.plan.id === plan.id
                  return (
                    <>
                      <button
                        onClick={() => handleSubscribe(plan.id)}
                        disabled={processing || isCurrent || freeLocked}
                        className={`w-full px-4 py-2 rounded-lg font-medium ${
                          isCurrent || freeLocked
                            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            : 'bg-blue-600 text-white hover:bg-blue-700'
                        }`}
                      >
                        {isCurrent
                          ? 'Current Plan'
                          : freeLocked
                          ? 'Indisponibil'
                          : 'Subscribe'}
                      </button>
                      {freeLocked && (
                        <p className="mt-2 text-xs text-gray-500">
                          Planul Free a fost deja folosit o dată și nu mai poate fi reselectat.
                        </p>
                      )}
                    </>
                  )
                })()}
              </div>
            ))}
          </div>
        )}

        {/* Add-on Packages */}
        {!loading && (addOns.length > 0 || myAddOns.length > 0) && (
          <div className="mt-10">
            <div className="flex items-center gap-3 mb-2">
              <PackageIcon className="w-6 h-6 text-indigo-600" />
              <div>
                <h2 className="text-xl font-bold text-gray-900">Pachete Add-on</h2>
                <p className="text-sm text-gray-500">
                  SMS campanii, email campanii și Business Email lunar
                </p>
              </div>
            </div>

            {/* Active assignments */}
            {myAddOns.length > 0 && (
              <div className="bg-white rounded-lg shadow mb-6 overflow-hidden">
                <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 text-sm font-medium text-gray-700">
                  Pachetele tale active
                </div>
                <ul className="divide-y divide-gray-100">
                  {myAddOns.map((a) => {
                    const Icon = ADDON_TYPE_ICON[a.packageType] || PackageIcon
                    const remaining =
                      a.packageType === 'sms_pack'
                        ? a.smsRemaining
                        : a.packageType === 'email_pack'
                          ? a.emailRemaining
                          : null
                    return (
                      <li key={a.id} className="px-4 py-3 flex items-center gap-4">
                        <Icon className="w-5 h-5 text-gray-400" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-gray-900">{a.packageName}</span>
                            <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">
                              {ADDON_TYPE_LABEL[a.packageType]}
                            </span>
                            <span
                              className={`text-xs px-2 py-0.5 rounded ${
                                a.status === 'active'
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : a.status === 'pending'
                                    ? 'bg-yellow-100 text-yellow-700'
                                    : 'bg-gray-100 text-gray-600'
                              }`}
                            >
                              {a.status}
                            </span>
                          </div>
                          <div className="text-xs text-gray-500 mt-1">
                            {remaining != null && `Rămase: ${remaining} `}
                            {a.expiresAt &&
                              ` · expiră ${new Date(a.expiresAt).toLocaleDateString('ro-RO')}`}
                            {a.billingCycle === 'monthly' && ' · lunar'}
                          </div>
                        </div>
                        <div className="text-sm font-medium text-gray-900">
                          {a.price} {a.currency}
                        </div>
                      </li>
                    )
                  })}
                </ul>
              </div>
            )}

            {/* Catalog grouped by type */}
            {addOns.length > 0 && (
              <div className="space-y-6">
                {ADDON_TYPE_ORDER.map((type) => {
                  const group = addOns.filter((p) => p.type === type)
                  if (group.length === 0) return null
                  const Icon = ADDON_TYPE_ICON[type]
                  return (
                    <div key={type}>
                      <div className="flex items-center gap-2 mb-3">
                        <Icon className="w-5 h-5 text-gray-500" />
                        <h3 className="text-base font-semibold text-gray-900">
                          {ADDON_TYPE_LABEL[type]}
                        </h3>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {group.map((pkg) => (
                          <div
                            key={pkg.id}
                            className="bg-white rounded-lg shadow p-5 flex flex-col"
                          >
                            <div className="mb-2 font-medium text-gray-900">{pkg.name}</div>
                            <div className="text-2xl font-bold text-gray-900 mb-1">
                              {pkg.price} {pkg.currency}
                              <span className="text-sm font-normal text-gray-500 ml-1">
                                {pkg.billingCycle === 'monthly' ? '/ lună' : 'o dată'}
                              </span>
                            </div>
                            {pkg.quantity != null && (
                              <div className="text-sm text-gray-600 mb-2">
                                {pkg.quantity}{' '}
                                {pkg.type === 'sms_pack' ? 'SMS-uri' : 'email-uri'}
                              </div>
                            )}
                            {pkg.description && (
                              <p className="text-sm text-gray-500 mb-3">{pkg.description}</p>
                            )}
                            <button
                              onClick={() => handleBuyAddOn(pkg)}
                              disabled={buyingAddonId === pkg.id}
                              className="mt-auto w-full px-4 py-2 rounded-lg font-medium bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {buyingAddonId === pkg.id ? 'Se procesează...' : 'Cumpără'}
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </AdminLayout>
  )
}













