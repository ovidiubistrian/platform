/**
 * Super Admin Subscription Plans Page
 */
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CreditCard,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Zap,
  Star,
  Crown,
  ArrowLeft,
  X,
  Loader2,
  Home,
  Phone,
  Save,
  RefreshCw
} from 'lucide-react'
import { subscriptionsApi, type SubscriptionPlan } from '../../lib/api/subscriptions'
import apiClient from '../../lib/api/client'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'

export default function SuperAdminSubscriptionPlansPage() {
  const navigate = useNavigate()
  const [plans, setPlans] = useState<SubscriptionPlan[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchPlans()
  }, [])

  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    monthlyPrice: 0,
    yearlyPrice: 0,
    currency: 'RON',
    maxProperties: 1,
    maxUnits: 5,
    maxBookings: 100,
    isActive: true,
    includesOnsiteOnboard: false,
    includes24hSupport: false,
    trialMonths: 0,
    featuresText: ''
  })
  const [saving, setSaving] = useState(false)
  const [syncingStripe, setSyncingStripe] = useState(false)

  const handleSyncStripe = async () => {
    if (!confirm('Creez Produsele si Pretul (monthly + yearly) in Stripe pentru planurile care nu le au inca. Continui?')) {
      return
    }
    setSyncingStripe(true)
    try {
      const response = await apiClient.post<{
        synced: { name: string; created: Record<string, boolean> }[]
        unchanged: { name: string }[]
        skipped: { name: string; reason: string }[]
        errors: { name: string; error: string }[]
        total: number
      }>('/api/super-admin/subscription-plans/sync-stripe')
      const data = response.data
      const parts: string[] = []
      if (data.synced.length > 0) parts.push(`✅ Create in Stripe: ${data.synced.map(s => s.name).join(', ')}`)
      if (data.unchanged.length > 0) parts.push(`➖ Deja sincronizate: ${data.unchanged.map(s => s.name).join(', ')}`)
      if (data.skipped.length > 0) parts.push(`⏭ Sarite (pret 0): ${data.skipped.map(s => s.name).join(', ')}`)
      if (data.errors.length > 0) parts.push(`❌ Erori: ${data.errors.map(e => `${e.name} — ${e.error}`).join('; ')}`)
      alert(parts.join('\n') || 'Nimic de sincronizat.')
      await fetchPlans()
    } catch (error: any) {
      const detail = error?.response?.data?.detail || error?.message || 'Eroare la sync Stripe'
      alert(`Eroare: ${detail}`)
    } finally {
      setSyncingStripe(false)
    }
  }

  const fetchPlans = async () => {
    setLoading(true)
    try {
      const data = await subscriptionsApi.getAllPlansAdmin()
      setPlans(data)
    } catch (error) {
      console.error('Error fetching subscription plans:', error)
    } finally {
      setLoading(false)
    }
  }

  const parseFeatures = (features: string | null | undefined): string[] => {
    if (!features) return []
    try {
      return JSON.parse(features)
    } catch {
      return []
    }
  }

  const handleCreatePlan = async () => {
    if (!formData.name) {
      alert('Numele planului este obligatoriu')
      return
    }

    setSaving(true)
    try {
      const featuresArray = formData.featuresText
        ? formData.featuresText.split('\n').filter(f => f.trim() !== '')
        : []
      
      await subscriptionsApi.createPlan({
        ...formData,
        features: JSON.stringify(featuresArray)
      })
      await fetchPlans()
      setShowCreateModal(false)
      resetForm()
      alert('✅ Plan creat cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.response?.data?.detail || error.message || 'Nu am putut crea planul'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleUpdatePlan = async () => {
    if (!editingPlan) return
    if (!formData.name) {
      alert('Numele planului este obligatoriu')
      return
    }

    setSaving(true)
    try {
      const featuresArray = formData.featuresText
        ? formData.featuresText.split('\n').filter(f => f.trim() !== '')
        : []
      
      await subscriptionsApi.updatePlan(editingPlan.id, {
        ...formData,
        features: JSON.stringify(featuresArray)
      })
      await fetchPlans()
      setShowEditModal(false)
      setEditingPlan(null)
      resetForm()
      alert('✅ Plan actualizat cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.response?.data?.detail || error.message || 'Nu am putut actualiza planul'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleDeletePlan = async (id: string) => {
    if (!confirm('Sigur vrei să ștergi acest plan? Această acțiune nu poate fi anulată.')) return

    try {
      await subscriptionsApi.deletePlan(id)
      await fetchPlans()
      alert('✅ Plan șters cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.response?.data?.detail || error.message || 'Nu am putut șterge planul'}`)
    }
  }

  const openEditModal = (plan: SubscriptionPlan) => {
    setEditingPlan(plan)
    const features = parseFeatures(plan.features)
    setFormData({
      name: plan.name,
      description: plan.description || '',
      monthlyPrice: plan.monthlyPrice,
      yearlyPrice: plan.yearlyPrice,
      currency: plan.currency,
      maxProperties: plan.maxProperties,
      maxUnits: plan.maxUnits,
      maxBookings: plan.maxBookings,
      isActive: plan.isActive,
      includesOnsiteOnboard: plan.includesOnsiteOnboard || false,
      includes24hSupport: plan.includes24hSupport || false,
      trialMonths: plan.trialMonths || 0,
      featuresText: features.join('\n')
    })
    setShowEditModal(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      monthlyPrice: 0,
      yearlyPrice: 0,
      currency: 'RON',
      maxProperties: 1,
      maxUnits: 5,
      maxBookings: 100,
      isActive: true,
      includesOnsiteOnboard: false,
      includes24hSupport: false,
      trialMonths: 0,
      featuresText: ''
    })
  }

  const getPlanIcon = (name: string) => {
    const nameLower = name.toLowerCase()
    if (nameLower.includes('basic') || nameLower.includes('free')) {
      return <Zap className="w-6 h-6 text-gray-500" />
    } else if (nameLower.includes('premium') || nameLower.includes('pro')) {
      return <Star className="w-6 h-6 text-yellow-500" />
    } else if (nameLower.includes('enterprise')) {
      return <Crown className="w-6 h-6 text-purple-500" />
    }
    return <CreditCard className="w-6 h-6 text-blue-500" />
  }

  return (
    <SuperAdminLayout>
      <div className="p-6">
        <div className="mb-6">
          <button
            onClick={() => navigate('/super-admin')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Subscription Plans</h1>
              <p className="text-gray-600 mt-1">Manage subscription plans</p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleSyncStripe}
                disabled={syncingStripe}
                className="flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 disabled:opacity-50"
                title="Creează Produsele și Prețurile (monthly + yearly) în Stripe pentru planurile care nu le au încă"
              >
                {syncingStripe ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4 mr-2" />
                )}
                Sync cu Stripe
              </button>
              <button
                onClick={() => {
                  resetForm()
                  setShowCreateModal(true)
                }}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Adaugă Plan
              </button>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Loading plans...</p>
          </div>
        ) : plans.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No subscription plans</h3>
            <p className="text-gray-600 mb-4">Create subscription plans for tenants</p>
            <button
              onClick={() => {
                resetForm()
                setShowCreateModal(true)
              }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Creează primul plan
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <div key={plan.id} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    {getPlanIcon(plan.name)}
                    <h3 className="text-xl font-semibold text-gray-900 ml-2">{plan.name}</h3>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    plan.isActive
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {plan.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>

                <div className="mb-4">
                  <div className="text-2xl font-bold text-gray-900">
                    {plan.monthlyPrice} {plan.currency}/mo
                  </div>
                  <div className="text-sm text-gray-500">
                    {plan.yearlyPrice} {plan.currency}/yr
                  </div>
                </div>

                {plan.description && (
                  <p className="text-gray-600 mb-4 text-sm">{plan.description}</p>
                )}

                {plan.trialMonths && plan.trialMonths > 0 && (
                  <div className="mb-3 p-2 bg-green-50 rounded-lg text-sm text-green-700">
                    ⏱️ {plan.trialMonths} lună trial gratuit
                  </div>
                )}

                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Proprietăți:</span>
                    <span className="font-medium">{plan.maxProperties === 999 ? '∞' : plan.maxProperties}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Unități:</span>
                    <span className="font-medium">{plan.maxUnits === 999 ? '∞' : plan.maxUnits}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Rezervări:</span>
                    <span className="font-medium">{plan.maxBookings === 99999 ? '∞' : plan.maxBookings}/lună</span>
                  </div>
                </div>

                {plan.includesOnsiteOnboard && (
                  <div className="mb-3 p-2 bg-purple-50 rounded-lg flex items-center text-sm">
                    <Home className="w-4 h-4 text-purple-600 mr-2" />
                    <span className="text-purple-700 font-medium">Onboarding la fața locului</span>
                  </div>
                )}

                {plan.includes24hSupport && (
                  <div className="mb-3 p-2 bg-blue-50 rounded-lg flex items-center text-sm">
                    <Phone className="w-4 h-4 text-blue-600 mr-2" />
                    <span className="text-blue-700 font-medium">Suport 24/7</span>
                  </div>
                )}

                {plan.features && (
                  <div className="space-y-1 mb-4">
                    {parseFeatures(plan.features).slice(0, 3).map((feature, idx) => (
                      <div key={idx} className="flex items-start text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                      </div>
                    ))}
                    {parseFeatures(plan.features).length > 3 && (
                      <p className="text-sm text-gray-500">
                        +{parseFeatures(plan.features).length - 3} alte funcționalități
                      </p>
                    )}
                  </div>
                )}

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <span className={`px-2 py-1 rounded-full text-xs ${plan.isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}`}>
                    {plan.isActive ? '✓ Activ' : '✗ Inactiv'}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openEditModal(plan)}
                      className="text-blue-600 hover:text-blue-900"
                      title="Editează"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeletePlan(plan.id)}
                      className="text-red-600 hover:text-red-900"
                      title="Șterge"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Create Plan Modal */}
        {showCreateModal && (
          <PlanModal
            title="Plan nou de abonament"
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleCreatePlan}
            onCancel={() => {
              setShowCreateModal(false)
              resetForm()
            }}
            saving={saving}
            isEdit={false}
          />
        )}

        {/* Edit Plan Modal */}
        {showEditModal && editingPlan && (
          <PlanModal
            title={`Editează Plan: ${editingPlan.name}`}
            formData={formData}
            setFormData={setFormData}
            onSubmit={handleUpdatePlan}
            onCancel={() => {
              setShowEditModal(false)
              setEditingPlan(null)
              resetForm()
            }}
            saving={saving}
            isEdit={true}
          />
        )}
      </div>
    </SuperAdminLayout>
  )
}

// Plan Modal Component
function PlanModal({
  title,
  formData,
  setFormData,
  onSubmit,
  onCancel,
  saving,
  isEdit
}: {
  title: string
  formData: {
    name: string
    description: string
    monthlyPrice: number
    yearlyPrice: number
    currency: string
    maxProperties: number
    maxUnits: number
    maxBookings: number
    isActive: boolean
    includesOnsiteOnboard: boolean
    includes24hSupport: boolean
    trialMonths: number
    featuresText: string
  }
  setFormData: (data: any) => void
  onSubmit: () => void
  onCancel: () => void
  saving: boolean
  isEdit: boolean
}) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
            <button onClick={onCancel} className="text-gray-400 hover:text-gray-600">
              <X className="h-6 w-6" />
            </button>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Nume Plan *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Descriere</label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={2}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Funcționalități (una pe linie)
              </label>
              <textarea
                value={formData.featuresText}
                onChange={(e) => setFormData({ ...formData, featuresText: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={8}
                placeholder="✅ 1 lună trial gratuit&#10;✅ 1 proprietate&#10;✅ 3 unități max"
              />
              <p className="text-xs text-gray-500 mt-1">
                Fiecare funcționalitate pe o linie nouă. Include ✅ sau alte emojis pentru un aspect profesional.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preț Lunar (RON)</label>
                <input
                  type="number"
                  value={formData.monthlyPrice}
                  onChange={(e) => setFormData({ ...formData, monthlyPrice: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Preț Anual (RON)</label>
                <input
                  type="number"
                  value={formData.yearlyPrice}
                  onChange={(e) => setFormData({ ...formData, yearlyPrice: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Proprietăți</label>
                <input
                  type="number"
                  value={formData.maxProperties}
                  onChange={(e) => setFormData({ ...formData, maxProperties: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Unități</label>
                <input
                  type="number"
                  value={formData.maxUnits}
                  onChange={(e) => setFormData({ ...formData, maxUnits: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Rezervări</label>
                <input
                  type="number"
                  value={formData.maxBookings}
                  onChange={(e) => setFormData({ ...formData, maxBookings: parseInt(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Luni Trial</label>
              <input
                type="number"
                value={formData.trialMonths}
                onChange={(e) => setFormData({ ...formData, trialMonths: parseInt(e.target.value) || 0 })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.isActive}
                  onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Plan Activ</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.includesOnsiteOnboard}
                  onChange={(e) => setFormData({ ...formData, includesOnsiteOnboard: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Include Onboarding la Fața Locului</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.includes24hSupport}
                  onChange={(e) => setFormData({ ...formData, includes24hSupport: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm font-medium text-gray-700">Include Suport 24/7</span>
              </label>
            </div>

            <div className="flex justify-end space-x-3 pt-4">
              <button
                onClick={onCancel}
                className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Anulează
              </button>
              <button
                onClick={onSubmit}
                disabled={saving}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center disabled:opacity-50"
              >
                {saving ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Salvează...
                  </>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Salvează
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}













