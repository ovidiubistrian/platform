/**
 * Super Admin Add-On Packages Page
 *
 * CRUD for SMS / email / Business Email add-on packages. Each row has
 * an `isActive` switch that controls whether tenants can see the package
 * at all — flip it off while the super-admin is still preparing the
 * catalog, flip it on when the offer goes live.
 */
import { useEffect, useState } from 'react'
import {
  Package as PackageIcon,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  X,
  Save,
  Loader2,
  MessageSquare,
  Mail,
  AtSign,
  Users as UsersIcon,
} from 'lucide-react'
import apiClient from '../../lib/api/client'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'

type AddOnType = 'sms_pack' | 'email_pack' | 'business_email'
type BillingCycle = 'one_time' | 'monthly'

interface AddOnPackage {
  id: string
  type: AddOnType
  name: string
  description?: string | null
  price: number
  currency: string
  billingCycle: BillingCycle
  quantity: number | null
  isActive: boolean
  sortOrder: number
  stripeProductId?: string | null
  stripePriceId?: string | null
  createdAt?: string
  updatedAt?: string
}

interface TenantAssignment {
  id: string
  tenantId: string
  tenantName: string | null
  addonPackageId: string
  addonPackageName: string | null
  status: 'pending' | 'active' | 'cancelled' | 'expired'
  smsRemaining: number | null
  emailRemaining: number | null
  activatedAt: string | null
  expiresAt: string | null
  notes: string | null
  createdAt?: string
}

interface TenantOption {
  id: string
  name: string
  slug: string
}

const DEFAULT_FORM: Omit<AddOnPackage, 'id' | 'createdAt' | 'updatedAt'> = {
  type: 'sms_pack',
  name: '',
  description: '',
  price: 0,
  currency: 'RON',
  billingCycle: 'one_time',
  quantity: 100,
  isActive: false,
  sortOrder: 0,
  stripeProductId: '',
  stripePriceId: '',
}

const TYPE_LABEL: Record<AddOnType, string> = {
  sms_pack: 'Pachet SMS',
  email_pack: 'Pachet Email',
  business_email: 'Business Email (abonament)',
}

const TYPE_ICON: Record<AddOnType, React.ComponentType<{ className?: string }>> = {
  sms_pack: MessageSquare,
  email_pack: Mail,
  business_email: AtSign,
}

export default function SuperAdminAddOnPackagesPage() {
  const [packages, setPackages] = useState<AddOnPackage[]>([])
  const [assignments, setAssignments] = useState<TenantAssignment[]>([])
  const [tenants, setTenants] = useState<TenantOption[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(DEFAULT_FORM)

  const [assignForm, setAssignForm] = useState({ tenantId: '', addonPackageId: '', notes: '' })
  const [showAssign, setShowAssign] = useState(false)
  const [assigning, setAssigning] = useState(false)

  const loadAll = async () => {
    setLoading(true)
    setError(null)
    try {
      const [pkgRes, asgRes, tenantsRes] = await Promise.all([
        apiClient.get('/api/super-admin/addon-packages'),
        apiClient.get('/api/super-admin/tenant-addons'),
        apiClient.get('/api/super-admin/tenants'),
      ])
      setPackages(Array.isArray(pkgRes.data) ? pkgRes.data : [])
      setAssignments(Array.isArray(asgRes.data) ? asgRes.data : [])
      const rawTenants = Array.isArray(tenantsRes.data) ? tenantsRes.data : (tenantsRes.data?.tenants || [])
      setTenants(
        (rawTenants as any[]).map((t) => ({
          id: t.id,
          name: t.name || t.slug || t.id,
          slug: t.slug || '',
        })),
      )
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la încărcarea pachetelor')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAll()
  }, [])

  const openCreate = () => {
    setEditingId(null)
    setForm(DEFAULT_FORM)
    setShowForm(true)
  }

  const openEdit = (pkg: AddOnPackage) => {
    setEditingId(pkg.id)
    setForm({
      type: pkg.type,
      name: pkg.name,
      description: pkg.description || '',
      price: pkg.price,
      currency: pkg.currency,
      billingCycle: pkg.billingCycle,
      quantity: pkg.quantity,
      isActive: pkg.isActive,
      sortOrder: pkg.sortOrder || 0,
      stripeProductId: pkg.stripeProductId || '',
      stripePriceId: pkg.stripePriceId || '',
    })
    setShowForm(true)
  }

  const handleSave = async () => {
    setSaving(true)
    setError(null)
    try {
      const payload: any = { ...form }
      // Business Email has no quantity
      if (form.type === 'business_email') {
        payload.quantity = null
        payload.billingCycle = 'monthly'
      }
      if (editingId) {
        await apiClient.put(`/api/super-admin/addon-packages/${editingId}`, payload)
      } else {
        await apiClient.post('/api/super-admin/addon-packages', payload)
      }
      setShowForm(false)
      setEditingId(null)
      await loadAll()
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la salvare')
    } finally {
      setSaving(false)
    }
  }

  const handleToggleActive = async (pkg: AddOnPackage) => {
    try {
      await apiClient.post(`/api/super-admin/addon-packages/${pkg.id}/toggle`)
      await loadAll()
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la toggle')
    }
  }

  const handleDelete = async (pkg: AddOnPackage) => {
    if (!confirm(`Ștergi definitiv pachetul "${pkg.name}"?`)) return
    try {
      await apiClient.delete(`/api/super-admin/addon-packages/${pkg.id}`)
      await loadAll()
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la ștergere')
    }
  }

  const handleAssign = async () => {
    if (!assignForm.tenantId || !assignForm.addonPackageId) {
      setError('Alege tenant și pachet')
      return
    }
    setAssigning(true)
    setError(null)
    try {
      await apiClient.post('/api/super-admin/tenant-addons', assignForm)
      setAssignForm({ tenantId: '', addonPackageId: '', notes: '' })
      setShowAssign(false)
      await loadAll()
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la asignare')
    } finally {
      setAssigning(false)
    }
  }

  const handleRevokeAssignment = async (assignment: TenantAssignment) => {
    if (!confirm(`Revoc asignarea "${assignment.addonPackageName}" pentru ${assignment.tenantName}?`)) return
    try {
      await apiClient.delete(`/api/super-admin/tenant-addons/${assignment.id}`)
      await loadAll()
    } catch (e: any) {
      setError(e?.response?.data?.detail || e?.message || 'Eroare la revocare')
    }
  }

  return (
    <SuperAdminLayout>
      <div className="p-6 sm:p-8 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <PackageIcon className="h-7 w-7 text-indigo-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Pachete Add-on</h1>
              <p className="text-sm text-gray-500">SMS campanii, email campanii și Business Email lunar</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowAssign(true)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-800 rounded-lg text-sm font-medium"
            >
              <UsersIcon className="h-4 w-4" />
              Asignează la tenant
            </button>
            <button
              onClick={openCreate}
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm font-medium"
            >
              <Plus className="h-4 w-4" />
              Pachet nou
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-800 rounded-lg text-sm">{error}</div>
        )}

        {/* Packages list */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden mb-8">
          <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 text-sm font-medium text-gray-700">
            Catalog
          </div>
          {loading ? (
            <div className="flex items-center justify-center py-12 text-gray-500">
              <Loader2 className="h-5 w-5 animate-spin mr-2" />
              Se încarcă...
            </div>
          ) : packages.length === 0 ? (
            <div className="px-4 py-10 text-center text-sm text-gray-500">
              Încă nu ai creat niciun pachet. Apasă „Pachet nou".
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {packages.map((pkg) => {
                const Icon = TYPE_ICON[pkg.type]
                return (
                  <li key={pkg.id} className="px-4 py-4 flex items-center gap-4">
                    <Icon className="h-5 w-5 text-gray-400" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-gray-900">{pkg.name}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600">{TYPE_LABEL[pkg.type]}</span>
                        {pkg.isActive ? (
                          <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 flex items-center gap-1">
                            <CheckCircle className="h-3 w-3" /> Activ
                          </span>
                        ) : (
                          <span className="text-xs px-2 py-0.5 rounded bg-gray-100 text-gray-600 flex items-center gap-1">
                            <XCircle className="h-3 w-3" /> Inactiv
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-500">
                        {pkg.price} {pkg.currency}
                        {' · '}
                        {pkg.billingCycle === 'monthly' ? 'lunar' : 'o singură dată'}
                        {pkg.quantity != null && ` · ${pkg.quantity} ${pkg.type === 'sms_pack' ? 'SMS' : 'emails'}`}
                      </div>
                      {pkg.description && <div className="text-xs text-gray-400 mt-0.5">{pkg.description}</div>}
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleToggleActive(pkg)}
                        className={`text-xs px-3 py-1.5 rounded-lg font-medium ${
                          pkg.isActive
                            ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                            : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                        }`}
                      >
                        {pkg.isActive ? 'Dezactivează' : 'Activează'}
                      </button>
                      <button onClick={() => openEdit(pkg)} className="p-2 hover:bg-gray-100 rounded">
                        <Edit className="h-4 w-4 text-gray-500" />
                      </button>
                      <button onClick={() => handleDelete(pkg)} className="p-2 hover:bg-red-50 rounded">
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </button>
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </div>

        {/* Assignments list */}
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-200 bg-gray-50 text-sm font-medium text-gray-700">
            Asignări active per tenant
          </div>
          {loading ? null : assignments.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-gray-500">
              Niciun tenant nu are încă un add-on asignat.
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {assignments.map((a) => (
                <li key={a.id} className="px-4 py-3 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900">{a.tenantName || a.tenantId}</span>
                      <span className="text-xs text-gray-500">→</span>
                      <span className="text-sm text-gray-700">{a.addonPackageName || a.addonPackageId}</span>
                      <span
                        className={`text-xs px-2 py-0.5 rounded ${
                          a.status === 'active'
                            ? 'bg-emerald-100 text-emerald-700'
                            : a.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-700'
                              : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {a.status}
                      </span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {a.smsRemaining != null && `SMS rămase: ${a.smsRemaining}`}
                      {a.emailRemaining != null && ` · Emails rămase: ${a.emailRemaining}`}
                      {a.expiresAt && ` · expiră ${new Date(a.expiresAt).toLocaleDateString('ro-RO')}`}
                    </div>
                  </div>
                  <button onClick={() => handleRevokeAssignment(a)} className="p-2 hover:bg-red-50 rounded">
                    <Trash2 className="h-4 w-4 text-red-500" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Create / edit modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-lg">
            <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">{editingId ? 'Editează pachet' : 'Pachet nou'}</h3>
              <button onClick={() => setShowForm(false)} className="p-1 hover:bg-gray-100 rounded">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tip</label>
                <select
                  value={form.type}
                  onChange={(e) => setForm({ ...form, type: e.target.value as AddOnType })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="sms_pack">Pachet SMS (one-shot, pentru campanii)</option>
                  <option value="email_pack">Pachet Email (one-shot, pentru campanii)</option>
                  <option value="business_email">Business Email (abonament lunar)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nume</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="ex: 100 SMS – Campanii"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Descriere (opțional)</label>
                <textarea
                  value={form.description || ''}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Preț</label>
                  <input
                    type="number"
                    min={0}
                    step="0.01"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Monedă</label>
                  <input
                    type="text"
                    value={form.currency}
                    onChange={(e) => setForm({ ...form, currency: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              </div>
              {form.type !== 'business_email' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cantitate ({form.type === 'sms_pack' ? 'SMS-uri' : 'email-uri'})
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={form.quantity || 0}
                    onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  />
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ciclu de facturare</label>
                <select
                  value={form.billingCycle}
                  onChange={(e) => setForm({ ...form, billingCycle: e.target.value as BillingCycle })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  disabled={form.type === 'business_email'}
                >
                  <option value="one_time">O singură dată</option>
                  <option value="monthly">Lunar</option>
                </select>
              </div>
              <div className="border-t border-gray-200 pt-4 space-y-3">
                <p className="text-xs text-gray-500">
                  Stripe (opțional) — completează dacă ai creat produsul în Stripe și vrei ca plata să fie procesată de Stripe.
                  Dacă le lași goale, pachetul se atribuie direct tenantului la cumpărare (mod dev).
                </p>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Stripe Product ID</label>
                  <input
                    type="text"
                    value={form.stripeProductId || ''}
                    onChange={(e) => setForm({ ...form, stripeProductId: e.target.value.trim() })}
                    placeholder="prod_..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Stripe Price ID</label>
                  <input
                    type="text"
                    value={form.stripePriceId || ''}
                    onChange={(e) => setForm({ ...form, stripePriceId: e.target.value.trim() })}
                    placeholder="price_..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono"
                  />
                </div>
              </div>
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={form.isActive}
                  onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
                />
                Activ (vizibil pentru tenanți)
              </label>
            </div>
            <div className="px-5 py-4 border-t border-gray-200 flex justify-end gap-2">
              <button
                onClick={() => setShowForm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm"
              >
                Anulează
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm disabled:opacity-50"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Salvează
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Assign modal */}
      {showAssign && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-md">
            <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">Asignează pachet la tenant</h3>
              <button onClick={() => setShowAssign(false)} className="p-1 hover:bg-gray-100 rounded">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tenant</label>
                <select
                  value={assignForm.tenantId}
                  onChange={(e) => setAssignForm({ ...assignForm, tenantId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="">— Alege —</option>
                  {tenants.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.slug})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pachet</label>
                <select
                  value={assignForm.addonPackageId}
                  onChange={(e) => setAssignForm({ ...assignForm, addonPackageId: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                >
                  <option value="">— Alege —</option>
                  {packages.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({TYPE_LABEL[p.type]})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Note (opțional)</label>
                <input
                  type="text"
                  value={assignForm.notes}
                  onChange={(e) => setAssignForm({ ...assignForm, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                />
              </div>
            </div>
            <div className="px-5 py-4 border-t border-gray-200 flex justify-end gap-2">
              <button onClick={() => setShowAssign(false)} className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
                Anulează
              </button>
              <button
                onClick={handleAssign}
                disabled={assigning}
                className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-sm disabled:opacity-50"
              >
                {assigning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Asignează
              </button>
            </div>
          </div>
        </div>
      )}
    </SuperAdminLayout>
  )
}
