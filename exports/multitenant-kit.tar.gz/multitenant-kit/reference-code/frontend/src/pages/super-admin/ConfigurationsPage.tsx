/**
 * Super Admin Configurations Page
 * Matches: app/super-admin/configurations/page.tsx
 * 
 * This is a comprehensive configuration hub with multiple tabs:
 * - Social Integrations (Facebook, Google)
 * - AI & ChatGPT Configuration
 * - DNS Configuration
 * - Homepage Hero Carousel
 * 
 * Note: Some features have dedicated pages (Stripe, Mailgun, Languages, SMS)
 * and are linked from here or can be accessed directly.
 */
import { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import {
  Settings,
  ArrowLeft,
  Save,
  Globe,
  Facebook,
  Zap,
  Server,
  Home,
  Loader2,
  CheckCircle,
  TestTube,
  Eye,
  EyeOff,
  Mail,
  CreditCard,
  RefreshCw,
  Plus,
  Edit,
  Trash2,
  Sparkles,
  Search,
  Filter,
  Users,
  ListChecks
} from 'lucide-react'
import { configurationsApi, type DomainRequestItem, type HomepageUnitsDisplayConfig } from '../../lib/api/configurations'
import { superAdminApi, type TenantAdminRow, type Tenant } from '../../lib/api/super_admin'
import { SITE_TRANSLATION_KEYS } from '../../data/translationKeys'
import languagesApi, {
  type Language,
  type TranslationKey,
} from '../../lib/api/languages'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'

interface SocialConfig {
  facebook: {
    appId: string
    appSecret: string
    enabled: boolean
  }
  google: {
    clientId: string
    clientSecret: string
    enabled: boolean
  }
}

interface AiConfig {
  openaiApiKey: string
  enabled: boolean
  features: {
    textImprovement: boolean
    autoTranslation: boolean
    contentGeneration: boolean
  }
  limits: {
    requestsPerDay: number
    requestsPerTenant: number
  }
}

interface DnsConfig {
  ip: string
  apiNinjasKey: string
}

interface HeroCarouselConfig {
  selectedTenantIds: string[]
  unitsDisplay: HomepageUnitsDisplayConfig
  // When true, the marketing homepage renders a grid of tenant cards
  // (hero-image carousel + Vizitează button) instead of the per-unit
  // carousel. Uses the same selectedTenantIds list.
  featuredTenantsEnabled: boolean
}

export default function SuperAdminConfigurationsPage() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('languages')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Social config state
  const [socialConfig, setSocialConfig] = useState<SocialConfig>({
    facebook: { appId: '', appSecret: '', enabled: false },
    google: { clientId: '', clientSecret: '', enabled: false }
  })
  const [showFacebookSecret, setShowFacebookSecret] = useState(false)
  const [showGoogleSecret, setShowGoogleSecret] = useState(false)

  // AI config state
  const [aiConfig, setAiConfig] = useState<AiConfig>({
    openaiApiKey: '',
    enabled: true,
    features: {
      textImprovement: true,
      autoTranslation: true,
      contentGeneration: true
    },
    limits: {
      requestsPerDay: 1000,
      requestsPerTenant: 100
    }
  })
  const [aiSaving, setAiSaving] = useState(false)
  const [aiTesting, setAiTesting] = useState(false)
  const [aiTestResult, setAiTestResult] = useState<{ type: 'success' | 'error'; message: string } | null>(null)
  const [showAiKey, setShowAiKey] = useState(false)

  // DNS config state
  const [dnsConfig, setDnsConfig] = useState<DnsConfig>({
    ip: '81.181.166.45',
    apiNinjasKey: ''
  })
  const [showApiNinjasKey, setShowApiNinjasKey] = useState(false)

  // Hero carousel config state
  const [heroConfig, setHeroConfig] = useState<HeroCarouselConfig>({
    selectedTenantIds: [],
    unitsDisplay: {
      showDescription: true,
      showPrice: true,
      showBedrooms: true,
      showBathrooms: true,
      showCapacity: true,
    },
    featuredTenantsEnabled: false,
  })
  const [allTenants, setAllTenants] = useState<Array<{ id: string; name: string; slug: string }>>([])

  // Language management state
  const [languages, setLanguages] = useState<Language[]>([])
  const [languagesLoading, setLanguagesLoading] = useState(false)
  const [selectedLanguageCode, setSelectedLanguageCode] = useState('')
  const [translations, setTranslations] = useState<TranslationKey[]>([])
  const [filteredTranslations, setFilteredTranslations] = useState<TranslationKey[]>([])
  const [translationsLoading, setTranslationsLoading] = useState(false)
  const [savingTranslations, setSavingTranslations] = useState(false)
  const [autoTranslating, setAutoTranslating] = useState(false)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [updatingLanguageSettings, setUpdatingLanguageSettings] = useState(false)
  const [showLanguageForm, setShowLanguageForm] = useState(false)
  const [editingLanguage, setEditingLanguage] = useState<Language | null>(null)
  const [languageForm, setLanguageForm] = useState({
    code: '',
    name: '',
    flag: '',
    isActive: true,
    isDefault: false,
    isPlatformPublic: false,
    isPlatformAdmin: false,
    sortOrder: 0,
  })
  const [savingLanguage, setSavingLanguage] = useState(false)

  // Admini Tenant state
  const [tenantAdmins, setTenantAdmins] = useState<TenantAdminRow[]>([])
  const [adminFilter, setAdminFilter] = useState<'all' | 'active' | 'inactive'>('all')
  const [loadingAdmins, setLoadingAdmins] = useState(false)
  const [showAddAdminModal, setShowAddAdminModal] = useState(false)
  const [editingAdmin, setEditingAdmin] = useState<TenantAdminRow | null>(null)
  const [adminTenants, setAdminTenants] = useState<Tenant[]>([])
  const [adminForm, setAdminForm] = useState({ name: '', email: '', password: '', tenantId: '', isActive: true })
  const [savingAdmin, setSavingAdmin] = useState(false)

  // Cereri domenii (tenant-ii care au făcut submit la domeniu)
  const [domainRequests, setDomainRequests] = useState<DomainRequestItem[]>([])
  const [domainRequestsLoading, setDomainRequestsLoading] = useState(false)
  const [domainRequestStatusFilter, setDomainRequestStatusFilter] = useState<string>('')
  const [editingDomainRequestId, setEditingDomainRequestId] = useState<string | null>(null)
  const [domainRequestEdit, setDomainRequestEdit] = useState<{ status: string; notes: string }>({ status: '', notes: '' })

  const POPULAR_LANGUAGES = [
    { code: 'ro', name: 'Română', flag: '🇷🇴' },
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' },
    { code: 'pt', name: 'Português', flag: '🇵🇹' },
    { code: 'nl', name: 'Nederlands', flag: '🇳🇱' },
    { code: 'pl', name: 'Polski', flag: '🇵🇱' },
    { code: 'cs', name: 'Čeština', flag: '🇨🇿' },
    { code: 'sk', name: 'Slovenčina', flag: '🇸🇰' },
    { code: 'hu', name: 'Magyar', flag: '🇭🇺' },
  ]

  const TRANSLATION_CATEGORIES = [
    { id: 'all', name: 'Toate Categoriile' },
    { id: 'navigation', name: 'Navigare' },
    { id: 'homepage', name: 'Pagina Principală' },
    { id: 'about', name: 'Despre Noi' },
    { id: 'contact', name: 'Contact' },
    { id: 'booking', name: 'Rezervări' },
    { id: 'rooms', name: 'Camere' },
    { id: 'amenities', name: 'Facilități' },
    { id: 'common', name: 'Comune' },
  ]

  const selectedLanguage = languages.find((lang) => lang.code === selectedLanguageCode) ?? null

  useEffect(() => {
    loadData()
    if (activeTab === 'languages') {
      fetchLanguages()
    }
  }, [])

  useEffect(() => {
    if (activeTab === 'languages' && selectedLanguageCode) {
      fetchTranslations(selectedLanguageCode)
    }
  }, [selectedLanguageCode, activeTab])

  useEffect(() => {
    if (activeTab === 'domain-requests') {
      setDomainRequestsLoading(true)
      configurationsApi.getDomainRequests(domainRequestStatusFilter || undefined)
        .then(setDomainRequests)
        .catch(() => setDomainRequests([]))
        .finally(() => setDomainRequestsLoading(false))
    }
  }, [activeTab, domainRequestStatusFilter])

  useEffect(() => {
    if (activeTab === 'languages') {
      const filtered = translations.filter((item) => {
        const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory
        const key = (item.key || '').toLowerCase()
        const defaultText = (item.defaultText || '').toLowerCase()
        const translatedText = (item.translatedText || '').toLowerCase()
        const term = (searchTerm || '').toLowerCase()
        const matchesSearch = !term || key.includes(term) || defaultText.includes(term) || translatedText.includes(term)
        return matchesCategory && matchesSearch
      })
      setFilteredTranslations(filtered)
    }
  }, [translations, searchTerm, selectedCategory, activeTab])

  const fetchTenantAdmins = async () => {
    if (activeTab !== 'admins') return
    setLoadingAdmins(true)
    try {
      const res = await superAdminApi.getTenantAdmins(adminFilter)
      setTenantAdmins(res.tenantAdmins || [])
    } catch (e) {
      console.error('Failed to load tenant admins', e)
      setTenantAdmins([])
    } finally {
      setLoadingAdmins(false)
    }
  }

  useEffect(() => {
    if (activeTab === 'admins') {
      fetchTenantAdmins()
    }
  }, [activeTab, adminFilter])

  useEffect(() => {
    if (showAddAdminModal || editingAdmin) {
      superAdminApi.getTenants().then((res) => setAdminTenants(res.tenants || [])).catch(() => setAdminTenants([]))
    }
  }, [showAddAdminModal, editingAdmin])

  const loadData = async () => {
    setLoading(true)
    try {
      // Load social config
      const socialData = await configurationsApi.getSocialConfig()
      setSocialConfig(socialData)

      // Load AI config
      const aiData = await configurationsApi.getAiConfig()
      setAiConfig(aiData)

      // Load DNS config
      const dnsData = await configurationsApi.getDnsConfig()
      setDnsConfig(dnsData)

      // Load tenants for hero carousel
      const tenantsData = await configurationsApi.getTenants()
      setAllTenants(tenantsData)

      // Load hero carousel config
      const [heroData, unitsDisplayData, featuredEnabled] = await Promise.all([
        configurationsApi.getHeroCarouselConfig(),
        configurationsApi.getHomepageUnitsDisplayConfig(),
        configurationsApi.getFeaturedTenantsEnabled(),
      ])
      setHeroConfig({
        selectedTenantIds: heroData,
        unitsDisplay: unitsDisplayData,
        featuredTenantsEnabled: featuredEnabled,
      })
    } catch (error) {
      console.error('Error loading configurations:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSocialConfig = async () => {
    setSaving(true)
    try {
      await configurationsApi.updateSocialConfig(socialConfig)
      alert('✅ Configurare socială salvată cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.message || 'Nu am putut salva configurația'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleSaveAiConfig = async () => {
    setAiSaving(true)
    setAiTestResult(null)
    try {
      await configurationsApi.updateAiConfig(aiConfig)
      setAiTestResult({
        type: 'success',
        message: 'Configurația AI a fost salvată cu succes!'
      })
    } catch (error: any) {
      setAiTestResult({
        type: 'error',
        message: error.message || 'Nu am putut salva configurația AI.'
      })
    } finally {
      setAiSaving(false)
    }
  }

  const handleTestAiConnection = async () => {
    setAiTesting(true)
    setAiTestResult(null)
    try {
      const result = await configurationsApi.testAiConnection(aiConfig.openaiApiKey)
      setAiTestResult({
        type: 'success',
        message: result.message || 'Conexiunea la OpenAI a fost testată cu succes.'
      })
    } catch (error: any) {
      setAiTestResult({
        type: 'error',
        message: error.message || 'Conexiunea la OpenAI a eșuat.'
      })
    } finally {
      setAiTesting(false)
    }
  }

  const handleSaveDnsConfig = async () => {
    setSaving(true)
    try {
      await configurationsApi.updateDnsConfig(dnsConfig)
      alert('✅ Configurare DNS salvată cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.message || 'Nu am putut salva configurația DNS'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleSaveHeroCarouselConfig = async () => {
    setSaving(true)
    try {
      await Promise.all([
        configurationsApi.updateHeroCarouselConfig(heroConfig.selectedTenantIds),
        configurationsApi.updateHomepageUnitsDisplayConfig(heroConfig.unitsDisplay),
        configurationsApi.updateFeaturedTenantsEnabled(heroConfig.featuredTenantsEnabled),
      ])
      alert('✅ Configurare hero carousel salvată cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.message || 'Nu am putut salva configurația'}`)
    } finally {
      setSaving(false)
    }
  }

  const toggleTenantSelection = (tenantId: string) => {
    setHeroConfig(prev => ({
      ...prev,
      selectedTenantIds: prev.selectedTenantIds.includes(tenantId)
        ? prev.selectedTenantIds.filter(id => id !== tenantId)
        : [...prev.selectedTenantIds, tenantId],
    }))
  }

  // Language management functions
  const fetchLanguages = async (selectCode?: string) => {
    setLanguagesLoading(true)
    try {
      const fetchedLanguages = await languagesApi.getAll()
      setLanguages(fetchedLanguages)
      const preferredCode = selectCode ?? selectedLanguageCode
      if (preferredCode && fetchedLanguages.some((lang) => lang.code === preferredCode)) {
        setSelectedLanguageCode(preferredCode)
      } else if (fetchedLanguages.length > 0 && !selectedLanguageCode) {
        setSelectedLanguageCode(fetchedLanguages[0].code)
      }
    } catch (error) {
      console.error('Error fetching languages:', error)
    } finally {
      setLanguagesLoading(false)
    }
  }

  const fetchTranslations = async (languageCode: string, retryAfterSync = true) => {
    setTranslationsLoading(true)
    try {
      const items = await languagesApi.getTranslations(languageCode)
      const list = Array.isArray(items) ? items : []
      setTranslations(list)
      // Dacă nu sunt chei dar avem limbă, rulează sync apoi reîncarcă (backend poate să nu fi creat încă cheile)
      if (list.length === 0 && retryAfterSync) {
        try {
          await languagesApi.syncKeys(SITE_TRANSLATION_KEYS)
          const retry = await languagesApi.getTranslations(languageCode)
          setTranslations(Array.isArray(retry) ? retry : [])
        } catch (_) {
          // ignoră eroare la sync; listă rămâne goală
        }
      }
    } catch (error) {
      console.error('Error fetching translations:', error)
      setTranslations([])
    } finally {
      setTranslationsLoading(false)
    }
  }

  const handleLanguageToggle = async (
    field: 'isActive' | 'isDefault' | 'isPlatformPublic' | 'isPlatformAdmin',
    value: boolean
  ) => {
    if (!selectedLanguage) return
    setUpdatingLanguageSettings(true)
    try {
      const payload = {
        code: selectedLanguage.code,
        name: selectedLanguage.name,
        flag: selectedLanguage.flag || '',
        isActive: field === 'isActive' ? value : selectedLanguage.isActive,
        isDefault: field === 'isDefault' ? value : selectedLanguage.isDefault,
        isPlatformPublic: field === 'isPlatformPublic' ? value : selectedLanguage.isPlatformPublic,
        isPlatformAdmin: field === 'isPlatformAdmin' ? value : selectedLanguage.isPlatformAdmin,
        sortOrder: selectedLanguage.sortOrder,
      }
      await languagesApi.update(selectedLanguage.id, payload)
      await fetchLanguages(selectedLanguage.code)
    } catch (error: any) {
      console.error('Error updating language settings:', error)
      alert(error.message || 'Eroare la actualizarea limbii')
    } finally {
      setUpdatingLanguageSettings(false)
    }
  }

  const handleTranslationChange = (id: string, value: string) => {
    setTranslations((prev) =>
      prev.map((translation) =>
        translation.id === id
          ? { ...translation, translatedText: value }
          : translation
      )
    )
  }

  const autoTranslateAll = async () => {
    if (!selectedLanguage || selectedLanguageCode === 'ro') return
    if (!confirm(`Traduci automat toate cheile în ${selectedLanguage.name}?`)) return
    setAutoTranslating(true)
    try {
      const result = await languagesApi.autoTranslateAll({
        fromLanguage: 'ro',
        toLanguage: selectedLanguageCode,
        translations,
      })
      setTranslations(result.translations ?? [])
      alert(`✅ ${result.totalTranslated} traduceri generate cu succes!`)
    } catch (error: unknown) {
      console.error('Error auto-translating:', error)
      const err = error as { response?: { data?: { detail?: string } }; message?: string }
      const detail = err?.response?.data?.detail
      if (detail && typeof detail === 'string') {
        alert(detail)
      } else {
        alert(err?.message || 'Eroare la traducerea automată. Salvează cheia API în Configurări → AI & ChatGPT.')
      }
    } finally {
      setAutoTranslating(false)
    }
  }

  const saveTranslations = async () => {
    if (!selectedLanguageCode) return
    setSavingTranslations(true)
    try {
      const updates = translations
        .filter((translation) =>
          translation.translatedText &&
          translation.translatedText !== translation.defaultText
        )
        .map((translation) => ({
          id: translation.id,
          translatedText: translation.translatedText,
          language: selectedLanguageCode,
        }))
      // Throttle the PUTs in chunks of 4 instead of firing them all in
      // parallel. N parallel PUTs were blocking the backend event loop
      // under load (SQLAlchemy sync calls on a single async worker), so
      // we cap concurrency to match future uvicorn --workers 4.
      const CHUNK = 4
      for (let i = 0; i < updates.length; i += CHUNK) {
        const batch = updates.slice(i, i + CHUNK)
        await Promise.all(batch.map((update) => languagesApi.updateTranslation(update)))
      }
      if (updates.length > 0) {
        alert(`✅ ${updates.length} traduceri salvate cu succes!`)
      } else {
        alert('Nu există modificări de salvat.')
      }
    } catch (error: any) {
      console.error('Error saving translations:', error)
      alert(error.message || 'Eroare la salvarea traducerilor')
    } finally {
      setSavingTranslations(false)
    }
  }

  const handleSaveLanguage = async () => {
    setSavingLanguage(true)
    try {
      if (editingLanguage) {
        await languagesApi.update(editingLanguage.id, languageForm)
      } else {
        await languagesApi.create(languageForm)
      }
      await fetchLanguages()
      setShowLanguageForm(false)
      resetLanguageForm()
    } catch (error: any) {
      console.error('Error saving language:', error)
      alert(error.message || 'Eroare la salvarea limbii')
    } finally {
      setSavingLanguage(false)
    }
  }

  const handleDeleteLanguage = async (language: Language) => {
    if (!confirm(`Ești sigur că vrei să ștergi limba "${language.name}"?`)) return
    try {
      await languagesApi.delete(language.id)
      await fetchLanguages()
    } catch (error: any) {
      console.error('Error deleting language:', error)
      alert(error.message || 'Eroare la ștergerea limbii')
    }
  }

  const handleEditLanguage = (language: Language) => {
    setEditingLanguage(language)
    setLanguageForm({
      code: language.code,
      name: language.name,
      flag: language.flag || '',
      isActive: language.isActive,
      isDefault: language.isDefault,
      isPlatformPublic: language.isPlatformPublic,
      isPlatformAdmin: language.isPlatformAdmin,
      sortOrder: language.sortOrder,
    })
    setShowLanguageForm(true)
  }

  const resetLanguageForm = () => {
    setLanguageForm({
      code: '',
      name: '',
      flag: '',
      isActive: true,
      isDefault: false,
      isPlatformPublic: false,
      isPlatformAdmin: false,
      sortOrder: 0,
    })
    setEditingLanguage(null)
  }

  const tabs = [
    { id: 'languages', name: 'Limbi', icon: Globe },
    { id: 'social', name: 'Integrări Sociale', icon: Facebook },
    { id: 'admins', name: 'Admini Tenant', icon: Settings },
    { id: 'domain-requests', name: 'Cereri domenii', icon: ListChecks },
    { id: 'homepage', name: 'Homepage Hero Carousel', icon: Home },
    { id: 'sms-email', name: 'SMS & Email Config', icon: Settings },
    { id: 'dns', name: 'DNS Configuration', icon: Server },
    { id: 'ai', name: 'AI & ChatGPT', icon: Zap },
    { id: 'payments', name: 'Payment Configuration', icon: Settings }
  ]

  if (loading) {
    return (
      <SuperAdminLayout>
        <div className="flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          <p className="ml-3 text-lg text-gray-600">Se încarcă configurațiile...</p>
        </div>
      </SuperAdminLayout>
    )
  }

  return (
    <SuperAdminLayout>
      <div className="p-6">
        <div className="mb-6">
          <button
            onClick={() => navigate('/super-admin')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <div className="flex items-center">
            <Settings className="w-6 h-6 text-blue-600 mr-3" />
            <h1 className="text-2xl font-bold text-gray-900">Configurări Super Admin</h1>
          </div>
          <p className="text-gray-600 mt-2">
            Gestionează limbi, integrări, admini și configurații SMS
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              {tabs.map((tab) => {
                const Icon = tab.icon
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap ${
                      activeTab === tab.id
                        ? 'border-blue-500 text-blue-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{tab.name}</span>
                  </button>
                )
              })}
            </nav>
          </div>
        </div>

        {/* Languages Tab */}
        {activeTab === 'languages' && (
          <div className="space-y-6">
            {/* Header Section */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900">Configurare Limbi Platformă</h2>
                    <p className="text-gray-600 mt-1">
                      Activează și traduce textele platformei (homepage și admin dashboard) dintr-un singur loc.
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={async () => {
                        try {
                          const res = await languagesApi.syncKeys(SITE_TRANSLATION_KEYS)
                          if (selectedLanguageCode) await fetchTranslations(selectedLanguageCode, false)
                          alert(res?.message || 'Cheile au fost actualizate.')
                        } catch (e: unknown) {
                          const msg = e && typeof e === 'object' && 'response' in e && typeof (e as { response?: { data?: { detail?: string } } }).response?.data?.detail === 'string'
                            ? (e as { response: { data: { detail: string } } }).response.data.detail
                            : 'Nu s-au putut actualiza cheile.'
                          alert(msg)
                        }
                      }}
                      className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                    >
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Actualizează cheile
                    </button>
                    <button
                      onClick={() => {
                        resetLanguageForm()
                        setShowLanguageForm(true)
                      }}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Adaugă limbă
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Available Languages Grid */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <p className="text-sm text-gray-600">
                  Cheile sunt colectate manual. Apasă „Actualizează cheile" după ce adaugi texte noi în platformă.
                </p>
              </div>
              <div className="p-6">
                {languagesLoading ? (
                  <div className="flex justify-center py-12">
                    <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
                  </div>
                ) : languages.length === 0 ? (
                  <div className="text-center py-12">
                    <Globe className="mx-auto h-12 w-12 text-gray-400" />
                    <h3 className="mt-2 text-sm font-medium text-gray-900">Nu există limbi configurate</h3>
                    <p className="mt-1 text-sm text-gray-500">Începe prin a adăuga prima limbă disponibilă.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {languages.map((language) => {
                      const isSelected = selectedLanguageCode === language.code
                      return (
                        <div
                          key={language.id}
                          onClick={() => setSelectedLanguageCode(language.code)}
                          className={`p-4 rounded-lg transition-all cursor-pointer ${
                            isSelected
                              ? 'border border-indigo-500 ring-2 ring-indigo-200 bg-indigo-50/40'
                              : 'border border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <span className="text-2xl">{language.flag}</span>
                              <div>
                                <h3 className="font-medium text-gray-900">{language.name}</h3>
                                <p className="text-sm text-gray-500">{language.code.toUpperCase()}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {language.isDefault && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                  Implicit
                                </span>
                              )}
                              {language.isPlatformPublic && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                  Homepage
                                </span>
                              )}
                              {language.isPlatformAdmin && (
                                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                  Admin
                                </span>
                              )}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  handleEditLanguage(language)
                                }}
                                className="text-gray-400 hover:text-gray-600"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              {!language.isDefault && (
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    handleDeleteLanguage(language)
                                  }}
                                  className="text-gray-400 hover:text-red-600"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <span className={language.isActive ? 'text-green-600' : 'text-red-600'}>
                              {language.isActive ? 'Activă' : 'Inactivă'}
                            </span>
                            <div className="flex items-center space-x-1">
                              <Users className="h-4 w-4" />
                              <span>{language._count?.tenantLanguages || 0} pensiuni</span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Selected Language Translation Management */}
            {selectedLanguage && (
              <div className="space-y-6">
                <div className="bg-white shadow rounded-lg p-6 space-y-4">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-3xl">{selectedLanguage.flag}</span>
                      <div>
                        <h2 className="text-xl font-semibold text-gray-900">
                          {selectedLanguage.name} ({selectedLanguage.code.toUpperCase()})
                        </h2>
                        <p className="text-sm text-gray-500">
                          Activează și gestionează traducerile pentru această limbă.
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4">
                      <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={selectedLanguage.isActive}
                          onChange={(e) => handleLanguageToggle('isActive', e.target.checked)}
                          disabled={updatingLanguageSettings}
                          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>Activă</span>
                      </label>
                      <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={selectedLanguage.isPlatformPublic}
                          onChange={(e) => handleLanguageToggle('isPlatformPublic', e.target.checked)}
                          disabled={updatingLanguageSettings}
                          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>Disponibilă pe homepage</span>
                      </label>
                      <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={selectedLanguage.isPlatformAdmin}
                          onChange={(e) => handleLanguageToggle('isPlatformAdmin', e.target.checked)}
                          disabled={updatingLanguageSettings}
                          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>Disponibilă în admin</span>
                      </label>
                      <label className="inline-flex items-center space-x-2 text-sm text-gray-700">
                        <input
                          type="checkbox"
                          checked={selectedLanguage.isDefault}
                          onChange={(e) => handleLanguageToggle('isDefault', e.target.checked)}
                          disabled={updatingLanguageSettings}
                          className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>Implicită</span>
                      </label>
                      {updatingLanguageSettings && (
                        <div className="flex items-center text-sm text-indigo-600">
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Se actualizează setările...
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <button
                      onClick={autoTranslateAll}
                      disabled={autoTranslating || !selectedLanguageCode || selectedLanguageCode === 'ro' || translations.length === 0}
                      className="inline-flex items-center px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-md hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {autoTranslating ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Traducere automată...
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4 mr-2" />
                          Traducere automată cu ChatGPT
                        </>
                      )}
                    </button>
                    <button
                      onClick={saveTranslations}
                      disabled={savingTranslations || translations.length === 0}
                      className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:opacity-50"
                    >
                      {savingTranslations ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Se salvează...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Salvează traducerile
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Search and Filter */}
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex flex-wrap items-center gap-4">
                    <div className="flex items-center flex-1 min-w-[250px]">
                      <Search className="h-5 w-5 text-gray-500 mr-2" />
                      <input
                        type="text"
                        placeholder="Caută chei de traducere..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                    <div className="flex items-center min-w-[200px]">
                      <Filter className="h-5 w-5 text-gray-500 mr-2" />
                      <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      >
                        {TRANSLATION_CATEGORIES.map((category) => (
                          <option key={category.id} value={category.id}>
                            {category.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Translation Statistics */}
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-gray-900">{filteredTranslations.length}</div>
                      <div className="text-sm text-gray-600">Total chei</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {filteredTranslations.filter((t) => t.translatedText && t.translatedText !== t.defaultText).length}
                      </div>
                      <div className="text-sm text-gray-600">Traduse</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">
                        {filteredTranslations.filter((t) => !t.translatedText || t.translatedText === t.defaultText).length}
                      </div>
                      <div className="text-sm text-gray-600">Ne traduse</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">
                        {filteredTranslations.filter((t) => t.autoTranslated).length}
                      </div>
                      <div className="text-sm text-gray-600">Auto-traduse</div>
                    </div>
                  </div>
                </div>

                {/* Translations Table */}
                <div className="bg-white shadow rounded-lg overflow-hidden">
                  {translationsLoading ? (
                    <div className="flex justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
                    </div>
                  ) : (
                    <>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cheie</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Text român</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Traducere</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acțiuni</th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            {filteredTranslations.map((translation) => (
                              <tr key={translation.id}>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <div className="text-sm font-medium text-gray-900">{translation.key}</div>
                                  <div className="text-xs text-gray-500">{translation.category}</div>
                                </td>
                                <td className="px-6 py-4">
                                  <div className="text-sm text-gray-900">{translation.defaultText}</div>
                                </td>
                                <td className="px-6 py-4">
                                  <textarea
                                    value={translation.translatedText}
                                    onChange={(e) => handleTranslationChange(translation.id, e.target.value)}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                                    rows={2}
                                    placeholder="Adaugă traducerea..."
                                  />
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                  <button
                                    onClick={async () => {
                                      const currentTranslation = translations.find((item) => item.id === translation.id)
                                      if (!currentTranslation || selectedLanguageCode === 'ro') return
                                      try {
                                        const result = await languagesApi.autoTranslateSingle({
                                          text: currentTranslation.defaultText,
                                          fromLanguage: 'ro',
                                          toLanguage: selectedLanguageCode,
                                          translationId: currentTranslation.id,
                                        })
                                        setTranslations((prev) =>
                                          prev.map((item) =>
                                            item.id === currentTranslation.id
                                              ? { ...item, translatedText: result.translatedText, autoTranslated: true }
                                              : item
                                          )
                                        )
                                      } catch (error: any) {
                                        alert(error.message || 'Eroare la traducerea automată')
                                      }
                                    }}
                                    disabled={selectedLanguageCode === 'ro'}
                                    className="inline-flex items-center px-3 py-1 bg-purple-100 text-purple-700 rounded-md hover:bg-purple-200 disabled:opacity-50"
                                    title="Traducere automată"
                                  >
                                    <Sparkles className="h-3 w-3 mr-1" />
                                    Auto
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      {filteredTranslations.length === 0 && (
                        <div className="text-center py-12">
                          <p className="text-gray-500">Nu s-au găsit traduceri pentru filtrele selectate.</p>
                        </div>
                      )}
                    </>
                  )}
                </div>
              </div>
            )}

            {/* Language Form Modal */}
            {showLanguageForm && (
              <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
                <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                  <div className="mt-3">
                    <h3 className="text-lg font-medium text-gray-900 mb-4">
                      {editingLanguage ? 'Editează Limba' : 'Adaugă Limbă Nouă'}
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Cod Limba</label>
                        <input
                          type="text"
                          value={languageForm.code}
                          onChange={(e) => {
                            const code = e.target.value
                            setLanguageForm({ ...languageForm, code })
                            const found = POPULAR_LANGUAGES.find((l) => l.code.toLowerCase() === code.toLowerCase())
                            if (found) {
                              setLanguageForm({ ...languageForm, code: found.code, name: found.name, flag: found.flag })
                            }
                          }}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="ex: ro, en, de"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nume Limba</label>
                        <input
                          type="text"
                          value={languageForm.name}
                          onChange={(e) => {
                            const name = e.target.value
                            setLanguageForm({ ...languageForm, name })
                            const found = POPULAR_LANGUAGES.find((l) => l.name.toLowerCase() === name.toLowerCase())
                            if (found) {
                              setLanguageForm({ ...languageForm, code: found.code, name: found.name, flag: found.flag })
                            }
                          }}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="ex: Română, English"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Emoji Steag</label>
                        <input
                          type="text"
                          value={languageForm.flag}
                          onChange={(e) => setLanguageForm({ ...languageForm, flag: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                          placeholder="ex: 🇷🇴, 🇺🇸"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Ordine Sortare</label>
                        <input
                          type="number"
                          value={languageForm.sortOrder}
                          onChange={(e) => setLanguageForm({ ...languageForm, sortOrder: parseInt(e.target.value) || 0 })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={languageForm.isActive}
                            onChange={(e) => setLanguageForm({ ...languageForm, isActive: e.target.checked })}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-sm text-gray-900">Limba este activă</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={languageForm.isDefault}
                            onChange={(e) => setLanguageForm({ ...languageForm, isDefault: e.target.checked })}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-sm text-gray-900">Limba implicită</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={languageForm.isPlatformPublic}
                            onChange={(e) => setLanguageForm({ ...languageForm, isPlatformPublic: e.target.checked })}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-sm text-gray-900">Disponibil pe homepage</span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={languageForm.isPlatformAdmin}
                            onChange={(e) => setLanguageForm({ ...languageForm, isPlatformAdmin: e.target.checked })}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-sm text-gray-900">Disponibil în admin</span>
                        </label>
                      </div>
                    </div>
                    <div className="mt-6 flex justify-end space-x-3">
                      <button
                        onClick={() => {
                          setShowLanguageForm(false)
                          resetLanguageForm()
                        }}
                        className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50"
                      >
                        Anulează
                      </button>
                      <button
                        onClick={handleSaveLanguage}
                        disabled={savingLanguage}
                        className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 border border-transparent rounded-md shadow-sm hover:bg-indigo-700 disabled:opacity-50"
                      >
                        {savingLanguage ? 'Se salvează...' : 'Salvează'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Social Integrations Tab */}
        {activeTab === 'social' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Integrări Sociale</h2>
              <p className="text-gray-600">Configurează Facebook și Google pentru autentificare și chat</p>
            </div>
            <div className="p-6 space-y-8">
              {/* Facebook Configuration */}
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Facebook className="h-6 w-6 text-blue-600" />
                  <h3 className="text-lg font-medium text-gray-900">Facebook</h3>
                  <label className="flex items-center ml-auto">
                    <input
                      type="checkbox"
                      checked={socialConfig.facebook.enabled}
                      onChange={(e) => setSocialConfig({
                        ...socialConfig,
                        facebook: { ...socialConfig.facebook, enabled: e.target.checked }
                      })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-sm text-gray-700">Activat</span>
                  </label>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">App ID</label>
                    <input
                      type="text"
                      value={socialConfig.facebook.appId}
                      onChange={(e) => setSocialConfig({
                        ...socialConfig,
                        facebook: { ...socialConfig.facebook, appId: e.target.value }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Facebook App ID"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">App Secret</label>
                    <div className="relative">
                      <input
                        type={showFacebookSecret ? "text" : "password"}
                        value={socialConfig.facebook.appSecret}
                        onChange={(e) => setSocialConfig({
                          ...socialConfig,
                          facebook: { ...socialConfig.facebook, appSecret: e.target.value }
                        })}
                        className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Facebook App Secret"
                      />
                      <button
                        type="button"
                        onClick={() => setShowFacebookSecret(!showFacebookSecret)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showFacebookSecret ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Google Configuration */}
              <div className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <Globe className="h-6 w-6 text-red-600" />
                  <h3 className="text-lg font-medium text-gray-900">Google</h3>
                  <label className="flex items-center ml-auto">
                    <input
                      type="checkbox"
                      checked={socialConfig.google.enabled}
                      onChange={(e) => setSocialConfig({
                        ...socialConfig,
                        google: { ...socialConfig.google, enabled: e.target.checked }
                      })}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <span className="ml-2 text-sm text-gray-700">Activat</span>
                  </label>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Client ID</label>
                    <input
                      type="text"
                      value={socialConfig.google.clientId}
                      onChange={(e) => setSocialConfig({
                        ...socialConfig,
                        google: { ...socialConfig.google, clientId: e.target.value }
                      })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Google Client ID"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Client Secret</label>
                    <div className="relative">
                      <input
                        type={showGoogleSecret ? "text" : "password"}
                        value={socialConfig.google.clientSecret}
                        onChange={(e) => setSocialConfig({
                          ...socialConfig,
                          google: { ...socialConfig.google, clientSecret: e.target.value }
                        })}
                        className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Google Client Secret"
                      />
                      <button
                        type="button"
                        onClick={() => setShowGoogleSecret(!showGoogleSecret)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showGoogleSecret ? (
                          <EyeOff className="h-4 w-4 text-gray-400" />
                        ) : (
                          <Eye className="h-4 w-4 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleSaveSocialConfig}
                  disabled={saving}
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>{saving ? 'Se salvează...' : 'Salvează Integrări'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* AI & ChatGPT Tab */}
        {activeTab === 'ai' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Configurare AI & ChatGPT</h2>
              <p className="text-gray-600">Configurează ChatGPT pentru îmbunătățire text și traducere automată</p>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2 space-y-2">
                  <label className="block text-sm font-medium text-gray-700">OpenAI API Key</label>
                  <div className="relative">
                    <input
                      type={showAiKey ? "text" : "password"}
                      value={aiConfig.openaiApiKey}
                      onChange={(e) => setAiConfig(prev => ({ ...prev, openaiApiKey: e.target.value }))}
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="sk-..."
                    />
                    <button
                      type="button"
                      onClick={() => setShowAiKey(!showAiKey)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showAiKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500">
                    Cheia este stocată securizat. Lasă câmpul gol pentru a utiliza cheia definită în variabila de mediu.
                  </p>
                </div>
                <div className="space-y-2">
                  <label className="inline-flex items-center gap-2 text-sm font-medium text-gray-700">
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={aiConfig.enabled}
                      onChange={(e) => setAiConfig(prev => ({ ...prev, enabled: e.target.checked }))}
                    />
                    Activează ChatGPT pentru platformă
                  </label>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Requesturi pe Zi</label>
                  <input
                    type="number"
                    value={aiConfig.limits.requestsPerDay}
                    onChange={(e) => setAiConfig(prev => ({
                      ...prev,
                      limits: { ...prev.limits, requestsPerDay: Number(e.target.value) || 0 },
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="1000"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Requesturi per Tenant</label>
                  <input
                    type="number"
                    value={aiConfig.limits.requestsPerTenant}
                    onChange={(e) => setAiConfig(prev => ({
                      ...prev,
                      limits: { ...prev.limits, requestsPerTenant: Number(e.target.value) || 0 },
                    }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="100"
                  />
                </div>
              </div>

              <div>
                <h3 className="text-md font-medium text-gray-900 mb-4">Funcționalități AI</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={aiConfig.features.textImprovement}
                      onChange={(e) =>
                        setAiConfig(prev => ({
                          ...prev,
                          features: { ...prev.features, textImprovement: e.target.checked },
                        }))
                      }
                    />
                    <span className="text-sm text-gray-700">Îmbunătățire Text (Copy Assistant)</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={aiConfig.features.autoTranslation}
                      onChange={(e) =>
                        setAiConfig(prev => ({
                          ...prev,
                          features: { ...prev.features, autoTranslation: e.target.checked },
                        }))
                      }
                    />
                    <span className="text-sm text-gray-700">Traducere automată a conținutului</span>
                  </label>
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={aiConfig.features.contentGeneration}
                      onChange={(e) =>
                        setAiConfig(prev => ({
                          ...prev,
                          features: { ...prev.features, contentGeneration: e.target.checked },
                        }))
                      }
                    />
                    <span className="text-sm text-gray-700">Generare de conținut</span>
                  </label>
                </div>
              </div>

              {aiTestResult && (
                <div className={`rounded-md border px-4 py-3 text-sm ${
                  aiTestResult.type === 'success'
                    ? 'border-green-200 bg-green-50 text-green-700'
                    : 'border-red-200 bg-red-50 text-red-700'
                }`}>
                  {aiTestResult.message}
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3">
                <button
                  onClick={handleTestAiConnection}
                  disabled={aiTesting || !aiConfig.openaiApiKey}
                  className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {aiTesting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <TestTube className="h-4 w-4" />
                  )}
                  <span>Testează Conexiunea</span>
                </button>
                <button
                  onClick={handleSaveAiConfig}
                  disabled={aiSaving}
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center space-x-2 disabled:opacity-50"
                >
                  {aiSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  <span>Salvează Configurare</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Cereri domenii - lista de submit-uri de la tenanți */}
        {activeTab === 'domain-requests' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Cereri domenii</h2>
              <p className="text-gray-600">Tenant-ii care au salvat un domeniu personalizat apar aici. Poți seta statusul și note; asocierea domeniu → tenant se face manual (sau automatizat ulterior).</p>
            </div>
            <div className="p-6">
              <div className="mb-4 flex items-center gap-4">
                <label className="text-sm font-medium text-gray-700">Filtru status:</label>
                <select
                  value={domainRequestStatusFilter}
                  onChange={(e) => setDomainRequestStatusFilter(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Toate</option>
                  <option value="pending">Pending</option>
                  <option value="configured">Configured</option>
                  <option value="rejected">Rejected</option>
                </select>
                <button
                  type="button"
                  onClick={() => {
                    setDomainRequestsLoading(true)
                    configurationsApi.getDomainRequests(domainRequestStatusFilter || undefined)
                      .then(setDomainRequests)
                      .finally(() => setDomainRequestsLoading(false))
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50 flex items-center gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Reîmprospătează
                </button>
              </div>
              {domainRequestsLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
                </div>
              ) : domainRequests.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <ListChecks className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Nicio cerere domeniu. Tenant-ii vor apărea aici după ce salvează domeniul în Configurare Site → Configurare domeniu.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                      <tr>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Tenant</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Domeniu</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Activ</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Status</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Note</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Data</th>
                        <th className="px-4 py-2 text-left text-sm font-medium text-gray-700">Acțiuni</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {domainRequests.map((r) => (
                        <tr key={r.id}>
                          <td className="px-4 py-2 text-sm">
                            <span className="font-medium text-gray-900">{r.tenant_name ?? '—'}</span>
                            {r.tenant_slug && <span className="text-gray-500 ml-1">({r.tenant_slug})</span>}
                          </td>
                          <td className="px-4 py-2 text-sm font-mono text-gray-700">{r.domain || '—'}</td>
                          <td className="px-4 py-2">{r.is_active ? <CheckCircle className="h-5 w-5 text-green-600" /> : <span className="text-gray-400">—</span>}</td>
                          <td className="px-4 py-2">
                            {editingDomainRequestId === r.id ? (
                              <select
                                value={domainRequestEdit.status}
                                onChange={(e) => setDomainRequestEdit((prev) => ({ ...prev, status: e.target.value }))}
                                className="px-2 py-1 border rounded text-sm"
                              >
                                <option value="pending">pending</option>
                                <option value="configured">configured</option>
                                <option value="rejected">rejected</option>
                              </select>
                            ) : (
                              <span className={`text-sm px-2 py-0.5 rounded ${r.status === 'configured' ? 'bg-green-100 text-green-800' : r.status === 'rejected' ? 'bg-red-100 text-red-800' : 'bg-amber-100 text-amber-800'}`}>{r.status}</span>
                            )}
                          </td>
                          <td className="px-4 py-2 text-sm text-gray-600 max-w-[200px]">
                            {editingDomainRequestId === r.id ? (
                              <textarea
                                value={domainRequestEdit.notes}
                                onChange={(e) => setDomainRequestEdit((prev) => ({ ...prev, notes: e.target.value }))}
                                rows={2}
                                className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                                placeholder="Note..."
                              />
                            ) : (
                              <span className="block max-w-[200px] truncate" title={r.notes ?? ''}>{r.notes ?? '—'}</span>
                            )}
                          </td>
                          <td className="px-4 py-2 text-xs text-gray-500">{r.created_at ? new Date(r.created_at).toLocaleDateString('ro-RO') : '—'}</td>
                          <td className="px-4 py-2">
                            {editingDomainRequestId === r.id ? (
                              <span className="flex items-center gap-1">
                                <button
                                  type="button"
                                  onClick={async () => {
                                    try {
                                      await configurationsApi.updateDomainRequest(r.id, { status: domainRequestEdit.status, notes: domainRequestEdit.notes || null })
                                      setDomainRequests((prev) => prev.map((x) => (x.id === r.id ? { ...x, status: domainRequestEdit.status, notes: domainRequestEdit.notes ?? null } : x)))
                                      setEditingDomainRequestId(null)
                                    } catch (e) {
                                      alert('Eroare la actualizare')
                                    }
                                  }}
                                  className="text-indigo-600 hover:text-indigo-800 text-sm font-medium"
                                >
                                  Salvează
                                </button>
                                <button type="button" onClick={() => setEditingDomainRequestId(null)} className="text-gray-500 hover:text-gray-700 text-sm">Anulează</button>
                              </span>
                            ) : (
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingDomainRequestId(r.id)
                                  setDomainRequestEdit({ status: r.status, notes: r.notes ?? '' })
                                }}
                                className="text-indigo-600 hover:text-indigo-800 text-sm font-medium flex items-center gap-1"
                              >
                                <Edit className="h-4 w-4" />
                                Editează
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* DNS Configuration Tab */}
        {activeTab === 'dns' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Configurare DNS</h2>
              <p className="text-gray-600">Setări pentru server DNS și IP pentru înregistrări A</p>
            </div>
            <div className="p-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <p className="text-sm text-blue-800">
                  Acest IP va fi afișat utilizatorilor pentru configurarea înregistrărilor DNS A în panoul lor de configurare domeniu.
                </p>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Server IP Address
                  </label>
                  <input
                    type="text"
                    value={dnsConfig.ip}
                    onChange={(e) => setDnsConfig({ ...dnsConfig, ip: e.target.value })}
                    placeholder="81.181.166.45"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <p className="mt-2 text-sm text-gray-500">
                    IP-ul serverului pe care utilizatorii vor configura înregistrările DNS A
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    API Ninjas API Key (Opțional)
                  </label>
                  <div className="relative">
                    <input
                      type={showApiNinjasKey ? "text" : "password"}
                      value={dnsConfig.apiNinjasKey}
                      onChange={(e) => setDnsConfig({ ...dnsConfig, apiNinjasKey: e.target.value })}
                      placeholder="Introduce API key de la api-ninjas.com"
                      className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowApiNinjasKey(!showApiNinjasKey)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                    >
                      {showApiNinjasKey ? (
                        <EyeOff className="h-4 w-4 text-gray-400" />
                      ) : (
                        <Eye className="h-4 w-4 text-gray-400" />
                      )}
                    </button>
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    API key de la API Ninjas pentru verificare DNS automată.{' '}
                    <a href="https://api-ninjas.com" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800 underline">
                      Obține cheie gratuită
                    </a>
                  </p>
                </div>

                <div className="flex justify-end">
                  <button
                    onClick={handleSaveDnsConfig}
                    disabled={saving}
                    className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
                  >
                    <Save className="h-4 w-4" />
                    <span>{saving ? 'Se salvează...' : 'Salvează Configurare'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}        {/* Homepage Hero Carousel Tab */}
        {activeTab === 'homepage' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Configurare Homepage Hero Carousel</h2>
              <p className="text-gray-600">Selectează tenant-ii ale căror unități vor apărea în hero carousel-ul de pe homepage</p>
            </div>
            <div className="p-6">
              {/* Mode toggle: per-unit carousel vs tenant-card grid */}
              <label className="mb-6 flex items-start gap-3 p-4 rounded border border-indigo-200 bg-indigo-50 cursor-pointer">
                <input
                  type="checkbox"
                  checked={heroConfig.featuredTenantsEnabled}
                  onChange={(e) =>
                    setHeroConfig((prev) => ({ ...prev, featuredTenantsEnabled: e.target.checked }))
                  }
                  className="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600"
                />
                <div>
                  <div className="font-medium text-gray-900">Afișează grid cu tenanți pe homepage</div>
                  <div className="text-sm text-gray-600">
                    Când e activ, secțiunea „Unitățile Noastre de Cazare” afișează un grid de cartonașe portrait,
                    fiecare cu imaginile hero ale tenantului și un buton Vizitează către domeniul custom (sau
                    <code className="mx-1 text-xs">360booking.ro/&lt;slug&gt;</code>). Folosește aceeași listă de
                    tenanți bifată mai jos.
                  </div>
                </div>
              </label>
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-4">
                  Bifează tenant-ii ale căror unități active vor fi afișate în hero carousel-ul de pe homepage.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
                  <label className="flex items-center gap-2 p-3 rounded border border-gray-200 bg-gray-50">
                    <input
                      type="checkbox"
                      checked={heroConfig.unitsDisplay.showPrice}
                      onChange={(e) =>
                        setHeroConfig((prev) => ({
                          ...prev,
                          unitsDisplay: { ...prev.unitsDisplay, showPrice: e.target.checked },
                        }))
                      }
                      className="h-4 w-4 rounded border-gray-300 text-blue-600"
                    />
                    <span className="text-sm text-gray-800">Afișează preț</span>
                  </label>
                  <label className="flex items-center gap-2 p-3 rounded border border-gray-200 bg-gray-50">
                    <input
                      type="checkbox"
                      checked={heroConfig.unitsDisplay.showBedrooms}
                      onChange={(e) =>
                        setHeroConfig((prev) => ({
                          ...prev,
                          unitsDisplay: { ...prev.unitsDisplay, showBedrooms: e.target.checked },
                        }))
                      }
                      className="h-4 w-4 rounded border-gray-300 text-blue-600"
                    />
                    <span className="text-sm text-gray-800">Afișează camere</span>
                  </label>
                  <label className="flex items-center gap-2 p-3 rounded border border-gray-200 bg-gray-50">
                    <input
                      type="checkbox"
                      checked={heroConfig.unitsDisplay.showBathrooms}
                      onChange={(e) =>
                        setHeroConfig((prev) => ({
                          ...prev,
                          unitsDisplay: { ...prev.unitsDisplay, showBathrooms: e.target.checked },
                        }))
                      }
                      className="h-4 w-4 rounded border-gray-300 text-blue-600"
                    />
                    <span className="text-sm text-gray-800">Afișează băi</span>
                  </label>
                  <label className="flex items-center gap-2 p-3 rounded border border-gray-200 bg-gray-50">
                    <input
                      type="checkbox"
                      checked={heroConfig.unitsDisplay.showCapacity}
                      onChange={(e) =>
                        setHeroConfig((prev) => ({
                          ...prev,
                          unitsDisplay: { ...prev.unitsDisplay, showCapacity: e.target.checked },
                        }))
                      }
                      className="h-4 w-4 rounded border-gray-300 text-blue-600"
                    />
                    <span className="text-sm text-gray-800">Afișează persoane</span>
                  </label>
                  <label className="flex items-center gap-2 p-3 rounded border border-gray-200 bg-gray-50 sm:col-span-2 lg:col-span-1">
                    <input
                      type="checkbox"
                      checked={heroConfig.unitsDisplay.showDescription}
                      onChange={(e) =>
                        setHeroConfig((prev) => ({
                          ...prev,
                          unitsDisplay: { ...prev.unitsDisplay, showDescription: e.target.checked },
                        }))
                      }
                      className="h-4 w-4 rounded border-gray-300 text-blue-600"
                    />
                    <span className="text-sm text-gray-800">Afișează descriere</span>
                  </label>
                </div>
                {heroConfig.selectedTenantIds.length > 0 && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <p className="text-sm text-blue-800">
                      <strong>{heroConfig.selectedTenantIds.length}</strong>{' '}
                      {heroConfig.selectedTenantIds.length === 1 ? 'tenant selectat' : 'tenanti selectați'}
                    </p>
                  </div>
                )}
              </div>              {allTenants.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-gray-600">Nu există tenanti disponibili.</p>
                </div>
              ) : (
                <div className="space-y-3 mb-6">
                  {allTenants.map((tenant) => (
                    <div
                      key={tenant.id}
                      className={`flex items-center justify-between p-4 border rounded-lg cursor-pointer transition-colors ${
                        heroConfig.selectedTenantIds.includes(tenant.id)
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                      }`}
                      onClick={() => toggleTenantSelection(tenant.id)}
                    >
                      <div className="flex items-center space-x-4">
                        <input
                          type="checkbox"
                          checked={heroConfig.selectedTenantIds.includes(tenant.id)}
                          onChange={() => toggleTenantSelection(tenant.id)}
                          className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer"
                          onClick={(e) => e.stopPropagation()}
                        />
                        <div className="flex-1">
                          <div className="font-medium text-gray-900">{tenant.name}</div>
                          <div className="text-sm text-gray-500">/{tenant.slug}</div>
                        </div>
                      </div>
                      {heroConfig.selectedTenantIds.includes(tenant.id) && (
                        <CheckCircle className="h-5 w-5 text-blue-600" />
                      )}
                    </div>
                  ))}
                </div>
              )}

              <div className="flex justify-end">
                <button
                  onClick={handleSaveHeroCarouselConfig}
                  disabled={saving}
                  className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
                >
                  <Save className="h-4 w-4" />
                  <span>{saving ? 'Se salvează...' : 'Salvează Configurare'}</span>
                </button>
              </div>
            </div>
          </div>
        )}        {/* Admini Tenant Tab */}
        {activeTab === 'admins' && (
          <div className="bg-white rounded-lg shadow">
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Admini Tenant</h2>
                  <p className="text-gray-600">Lista adminilor și statusul lor</p>
                </div>
                <div className="flex items-center space-x-4">
                  <select
                    value={adminFilter}
                    onChange={(e) => setAdminFilter(e.target.value as 'all' | 'active' | 'inactive')}
                    className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="all">Toți</option>
                    <option value="active">Activi</option>
                    <option value="inactive">Inactivi</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => fetchTenantAdmins()}
                    className="p-2 text-gray-600 hover:text-gray-800"
                    title="Reîmprospătează"
                  >
                    <RefreshCw className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
            <div className="p-6 overflow-x-auto">
              {loadingAdmins ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
                </div>
              ) : (
                <>
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead>
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Admin</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tenant</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Unități</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rezervări</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ultima conectare</th>
                        <th className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acțiuni</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {tenantAdmins.map((row) => (
                        <tr key={row.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div className="font-medium text-gray-900">{row.name}</div>
                            <div className="text-sm text-gray-500">{row.email}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${row.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}`}>
                              {row.isActive ? <CheckCircle className="h-3.5 w-3.5" /> : null}
                              {row.isActive ? 'Activ' : 'Inactiv'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            {row.tenant ? (
                              <>
                                <div className="font-medium text-gray-900">{row.tenant.name}</div>
                                <div className="text-sm text-gray-500">/{row.tenant.slug}</div>
                              </>
                            ) : (
                              <span className="text-gray-400">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-gray-700">{row.unitsCount}</td>
                          <td className="px-4 py-3 text-gray-700">{row.bookingsCount}</td>
                          <td className="px-4 py-3 text-sm text-gray-600">
                            {row.lastLoginAt ? new Date(row.lastLoginAt).toLocaleDateString('ro-RO') : '—'}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                type="button"
                                onClick={() => { setEditingAdmin(row); setAdminForm({ name: row.name, email: row.email, password: '', tenantId: row.tenant?.id ?? '', isActive: row.isActive }); }}
                                className="p-2 text-gray-500 hover:text-blue-600"
                                title="Editează"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <a
                                href={`mailto:${row.email}`}
                                className="p-2 text-gray-500 hover:text-blue-600"
                                title="Trimite email"
                              >
                                <Mail className="h-4 w-4" />
                              </a>
                              <button
                                type="button"
                                onClick={async () => {
                                  if (!window.confirm(`Ștergi adminul ${row.name}?`)) return
                                  try {
                                    await superAdminApi.deleteUser(row.id)
                                    fetchTenantAdmins()
                                  } catch (e: any) {
                                    alert(e?.response?.data?.detail || 'Eroare la ștergere')
                                  }
                                }}
                                className="p-2 text-gray-500 hover:text-red-600"
                                title="Șterge"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {tenantAdmins.length === 0 && !loadingAdmins && (
                    <p className="text-center text-gray-500 py-8">Niciun admin tenant.</p>
                  )}
                  <div className="mt-6">
                    <button
                      type="button"
                      onClick={() => { setEditingAdmin(null); setAdminForm({ name: '', email: '', password: '', tenantId: '', isActive: true }); setShowAddAdminModal(true); }}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      <Plus className="h-5 w-5" />
                      Adaugă Admin Nou
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}        {/* Add/Edit Admin Modal */}
        {(showAddAdminModal || editingAdmin) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50" onClick={() => { setShowAddAdminModal(false); setEditingAdmin(null); }}>
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full mx-4 p-6" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">{editingAdmin ? 'Editează Admin' : 'Adaugă Admin Nou'}</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nume</label>
                  <input
                    type="text"
                    value={adminForm.name}
                    onChange={(e) => setAdminForm((f) => ({ ...f, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                  <input
                    type="email"
                    value={adminForm.email}
                    onChange={(e) => setAdminForm((f) => ({ ...f, email: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    disabled={!!editingAdmin}
                  />
                </div>
                {!editingAdmin && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Parolă</label>
                    <input
                      type="password"
                      value={adminForm.password}
                      onChange={(e) => setAdminForm((f) => ({ ...f, password: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    />
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tenant</label>
                  <select
                    value={adminForm.tenantId}
                    onChange={(e) => setAdminForm((f) => ({ ...f, tenantId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                  >
                    <option value="">— Selectează tenant —</option>
                    {adminTenants.map((t) => (
                      <option key={t.id} value={t.id}>{t.name} (/{t.slug})</option>
                    ))}
                  </select>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="admin-active"
                    checked={adminForm.isActive}
                    onChange={(e) => setAdminForm((f) => ({ ...f, isActive: e.target.checked }))}
                  />
                  <label htmlFor="admin-active" className="text-sm text-gray-700">Activ</label>
                </div>
              </div>
              <div className="mt-6 flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => { setShowAddAdminModal(false); setEditingAdmin(null); }}
                  className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Anulare
                </button>
                <button
                  type="button"
                  disabled={savingAdmin || (!!editingAdmin ? false : !adminForm.name || !adminForm.email || !adminForm.password || !adminForm.tenantId)}
                  onClick={async () => {
                    setSavingAdmin(true)
                    try {
                      if (editingAdmin) {
                        await superAdminApi.updateUser(editingAdmin.id, {
                          name: adminForm.name,
                          tenantId: adminForm.tenantId || undefined,
                          isActive: adminForm.isActive,
                        })
                        alert('Admin actualizat.')
                      } else {
                        await superAdminApi.createUser({
                          name: adminForm.name,
                          email: adminForm.email,
                          password: adminForm.password,
                          role: 'tenant_admin',
                          tenantId: adminForm.tenantId || undefined,
                          isActive: adminForm.isActive,
                        })
                        alert('Admin adăugat.')
                      }
                      setShowAddAdminModal(false)
                      setEditingAdmin(null)
                      fetchTenantAdmins()
                    } catch (e: any) {
                      alert(e?.response?.data?.detail || 'Eroare la salvare')
                    } finally {
                      setSavingAdmin(false)
                    }
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
                >
                  {savingAdmin ? 'Se salvează...' : (editingAdmin ? 'Salvează' : 'Adaugă')}
                </button>
              </div>
            </div>
          </div>
        )}        {/* SMS & Email Configuration Tab */}
        {activeTab === 'sms-email' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">SMS & Email Config</h2>
                <p className="text-gray-600">Configurează SMS și Email pentru platformă</p>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">
                  Pentru configurarea SMS și Email, folosește paginile dedicate:
                </p>
                <div className="flex gap-4">
                  <Link
                    to="/super-admin/sms"
                    className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Configurare SMS
                  </Link>
                  <Link
                    to="/super-admin/mailgun"
                    className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Configurare Mailgun
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}        {/* Payment Configuration Tab */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Payment Configuration</h2>
                <p className="text-gray-600">Configurează metodele de plată pentru platformă</p>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">
                  Pentru configurarea Stripe, folosește pagina dedicată:
                </p>
                <Link
                  to="/super-admin/stripe"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Configurare Stripe
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </SuperAdminLayout>
  )
}