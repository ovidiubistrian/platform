/**
 * Super Admin Tenants Page
 */
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Building,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  CheckCircle,
  XCircle,
  ArrowLeft,
  Loader2,
  X,
  Users,
  Sparkles,
  RotateCcw,
  Globe,
} from 'lucide-react'
import { superAdminApi, type Tenant } from '../../lib/api/super_admin'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'

export default function SuperAdminTenantsPage() {
  const navigate = useNavigate()
  const [tenants, setTenants] = useState<Tenant[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [showDeleted, setShowDeleted] = useState(false)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingTenant, setEditingTenant] = useState<Tenant | null>(null)
  const [formData, setFormData] = useState({
    name: '',
    slug: '',
    status: 'trial',
    subscriptionPlan: 'free',
    productType: 'accommodation' as 'accommodation' | 'restaurant' | 'both',
    restaurantTier: 'full' as 'full' | 'menu_site',
    planCatalogId: '',
    planOverridesJson: '{}',
    isActive: true
  })
  const [saving, setSaving] = useState(false)
  const [planCatalogOptions, setPlanCatalogOptions] = useState<Array<{ id: string; slug: string; name: string }>>([])

  useEffect(() => {
    // Load active catalog rows for the Plan dropdown.
    void (async () => {
      try {
        const { default: apiClient } = await import('../../lib/api/client')
        const { data } = await apiClient.get('/api/plan-catalog')
        if (Array.isArray(data?.plans)) {
          setPlanCatalogOptions(data.plans.map((p: any) => ({ id: p.id, slug: p.slug, name: p.name })))
        } else if (Array.isArray(data)) {
          setPlanCatalogOptions(data.map((p: any) => ({ id: p.id, slug: p.slug, name: p.name })))
        }
      } catch (e) {
        console.warn('plan catalog list fetch failed', e)
      }
    })()
  }, [])

  useEffect(() => {
    fetchTenants()
  }, [statusFilter, showDeleted])

  const fetchTenants = async () => {
    setLoading(true)
    try {
      const data = await superAdminApi.getTenants(undefined, undefined, showDeleted)
      setTenants(data.tenants)
    } catch (error) {
      console.error('Error fetching tenants:', error)
    } finally {
      setLoading(false)
    }
  }

  // Helpers for the soft-delete lifecycle. A tenant is "deleted" when
  // deletedAt is set; it stays recoverable for 30 days.
  const getDeletedAt = (t: Tenant): string | null =>
    ((t as any).deletedAt || (t as any).deleted_at || null) as string | null
  const getCustomDomain = (t: Tenant): string | null =>
    (((t as any).customDomain || (t as any).custom_domain || '') as string).trim() || null
  const daysLeft = (deletedAt: string): number => {
    const purgeAt = new Date(deletedAt).getTime() + 30 * 24 * 60 * 60 * 1000
    return Math.max(0, Math.ceil((purgeAt - Date.now()) / (24 * 60 * 60 * 1000)))
  }

  const handleCreateTenant = async () => {
    if (!formData.name || !formData.slug) {
      alert('Nume și slug sunt obligatorii')
      return
    }

    setSaving(true)
    try {
      await superAdminApi.createTenant(formData)
      await fetchTenants()
      setShowCreateModal(false)
      resetForm()
      alert('✅ Tenant creat cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.message || 'Nu am putut crea tenant-ul'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleUpdateTenant = async () => {
    if (!editingTenant) return
    if (!formData.name || !formData.slug) {
      alert('Nume și slug sunt obligatorii')
      return
    }

    setSaving(true)
    let planOverrides: Record<string, unknown> = {}
    try {
      planOverrides = formData.planOverridesJson ? JSON.parse(formData.planOverridesJson) : {}
    } catch {
      alert('❌ JSON invalid în câmpul Plan Overrides')
      setSaving(false)
      return
    }
    try {
      const { planOverridesJson, ...rest } = formData
      void planOverridesJson
      await superAdminApi.updateTenant(editingTenant.id, {
        ...(rest as any),
        planOverrides,
      } as any)
      await fetchTenants()
      setShowEditModal(false)
      setEditingTenant(null)
      resetForm()
      alert('✅ Tenant actualizat cu succes!')
    } catch (error: any) {
      alert(`❌ Eroare: ${error.message || 'Nu am putut actualiza tenant-ul'}`)
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteTenant = async (tenant: Tenant) => {
    const domain = getCustomDomain(tenant)
    if (domain) {
      alert(`⛔ Tenantul are domeniul „${domain}” asignat. Dezasignează domeniul (Editează) înainte de a-l șterge.`)
      return
    }
    if (!confirm('Muți acest tenant în coșul de gunoi? Site-ul se dezactivează imediat, dar îl poți restaura în următoarele 30 de zile. După 30 de zile se șterge definitiv automat.')) return

    try {
      await superAdminApi.deleteTenant(tenant.id)
      await fetchTenants()
      alert('✅ Tenant mutat în coșul de gunoi (recuperabil 30 de zile).')
    } catch (error: any) {
      const detail = error?.response?.data?.detail
      alert(`❌ Eroare: ${detail || error.message || 'Nu am putut șterge tenant-ul'}`)
    }
  }

  const handleRestoreTenant = async (id: string) => {
    try {
      await superAdminApi.restoreTenant(id)
      await fetchTenants()
      alert('✅ Tenant restaurat.')
    } catch (error: any) {
      const detail = error?.response?.data?.detail
      alert(`❌ Eroare: ${detail || error.message || 'Nu am putut restaura tenant-ul'}`)
    }
  }

  const handlePurgeTenant = async (tenant: Tenant) => {
    if (!confirm(`ȘTERGERE DEFINITIVĂ pentru „${tenant.name}”. Toate datele asociate dispar și NU pot fi recuperate. Continui?`)) return
    try {
      await superAdminApi.purgeTenant(tenant.id)
      await fetchTenants()
      alert('✅ Tenant șters definitiv.')
    } catch (error: any) {
      const detail = error?.response?.data?.detail
      alert(`❌ Eroare: ${detail || error.message || 'Nu am putut șterge definitiv tenant-ul'}`)
    }
  }

  const openEditModal = (tenant: Tenant) => {
    setEditingTenant(tenant)
    setFormData({
      name: tenant.name,
      slug: tenant.slug,
      status: tenant.status,
      subscriptionPlan: tenant.subscriptionPlan,
      productType: ((tenant as any).productType || (tenant as any).product_type || 'accommodation') as 'accommodation' | 'restaurant' | 'both',
      restaurantTier: ((tenant as any).restaurantTier || (tenant as any).restaurant_tier || 'full') as 'full' | 'menu_site',
      planCatalogId: ((tenant as any).planCatalogId || (tenant as any).plan_catalog_id || '') as string,
      planOverridesJson: JSON.stringify(((tenant as any).planOverrides || (tenant as any).plan_overrides || {}), null, 2),
      isActive: tenant.isActive
    })
    setShowEditModal(true)
  }

  const resetForm = () => {
    setFormData({
      name: '',
      slug: '',
      status: 'trial',
      subscriptionPlan: 'free',
      productType: 'accommodation',
      restaurantTier: 'full',
      planCatalogId: '',
      planOverridesJson: '{}',
      isActive: true
    })
  }

  const filteredTenants = tenants.filter(tenant => {
    const ownerEmail = ((tenant as any).ownerEmail || (tenant as any).owner_email || '') as string
    const matchesSearch = !searchTerm ||
      tenant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tenant.slug.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ownerEmail.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = !statusFilter || tenant.status === statusFilter
    return matchesSearch && matchesStatus
  })

  return (
    <SuperAdminLayout>
      <div className="p-6">
        <div className="mb-6">
          <button
            onClick={() => navigate('/super-admin')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Tenants</h1>
              <p className="text-gray-600 mt-1">Manage all platform tenants</p>
            </div>
            <button
              onClick={() => {
                resetForm()
                setShowCreateModal(true)
              }}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adaugă Tenant
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Caută după nume, slug sau email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Statuses</option>
              <option value="trial">Trial</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
            </select>
            <button
              onClick={() => {
                setSearchTerm('')
                setStatusFilter('')
              }}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Filter className="w-4 h-4 inline mr-2" />
              Clear
            </button>
          </div>
          <label className="flex items-center gap-2 mt-4 text-sm text-gray-700 cursor-pointer w-fit">
            <input
              type="checkbox"
              checked={showDeleted}
              onChange={(e) => setShowDeleted(e.target.checked)}
              className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
            />
            <Trash2 className="w-4 h-4 text-red-500" />
            Arată tenanții șterși (coș de gunoi)
          </label>
        </div>

        {/* Tenants Grid */}
        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <p className="mt-4 text-gray-600">Loading tenants...</p>
          </div>
        ) : filteredTenants.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-12 text-center">
            <Building className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No tenants found</h3>
            <p className="text-gray-600">No tenants match your filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTenants.map((tenant) => {
              const deletedAt = getDeletedAt(tenant)
              const isDeleted = !!deletedAt
              const customDomain = getCustomDomain(tenant)
              return (
              <div key={tenant.id} className={`bg-white rounded-lg shadow p-6 transition-shadow ${isDeleted ? 'opacity-70 ring-1 ring-red-200' : 'hover:shadow-lg'}`}>
                {isDeleted && deletedAt && (
                  <div className="mb-3 flex items-center gap-2 text-xs font-medium text-red-700 bg-red-50 border border-red-200 rounded-md px-2 py-1">
                    <Trash2 className="w-3 h-3" />
                    În coșul de gunoi — ștergere definitivă în {daysLeft(deletedAt)} zile
                  </div>
                )}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-gray-900 truncate">{tenant.name}</h3>
                    <p className="text-sm text-gray-500 truncate">{tenant.slug}</p>
                    {customDomain && (
                      <p className="text-xs text-emerald-700 truncate mt-1 flex items-center gap-1" title={`Domeniu asignat: ${customDomain}`}>
                        <Globe className="w-3 h-3" /> {customDomain}
                      </p>
                    )}
                    {(() => {
                      const ownerEmail = ((tenant as any).ownerEmail || (tenant as any).owner_email) as string | null | undefined
                      return ownerEmail ? (
                        <p className="text-xs text-gray-600 truncate mt-1" title={ownerEmail}>{ownerEmail}</p>
                      ) : (
                        <p className="text-xs text-gray-400 italic mt-1">fără owner</p>
                      )
                    })()}
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    tenant.isActive
                      ? 'bg-green-100 text-green-800'
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    {tenant.isActive ? (
                      <>
                        <CheckCircle className="w-3 h-3 inline mr-1" />
                        Active
                      </>
                    ) : (
                      <>
                        <XCircle className="w-3 h-3 inline mr-1" />
                        Inactive
                      </>
                    )}
                  </span>
                </div>

                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Status:</span>
                    <span className="font-medium capitalize">{tenant.status}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Plan:</span>
                    {(() => {
                      const planName = ((tenant as any).planCatalogName || (tenant as any).plan_catalog_name) as string | null | undefined
                      const planSlug = ((tenant as any).planCatalogSlug || (tenant as any).plan_catalog_slug) as string | null | undefined
                      return planName ? (
                        <span className="font-medium px-2 py-0.5 rounded-full text-xs bg-emerald-100 text-emerald-800" title={planSlug || ''}>{planName}</span>
                      ) : (
                        <span className="font-medium text-gray-500 italic">{tenant.subscriptionPlan} (neasignat)</span>
                      )
                    })()}
                  </div>
                  {(() => {
                    // Badge for the product family. Kept subtle to not
                    // crowd the card; super-admin uses it to spot
                    // restaurant-only clients at a glance.
                    const pt = (tenant as any).productType || (tenant as any).product_type || 'accommodation'
                    const style =
                      pt === 'restaurant' ? 'bg-rose-100 text-rose-800'
                        : pt === 'both' ? 'bg-purple-100 text-purple-800'
                        : 'bg-blue-100 text-blue-800'
                    const label = pt === 'restaurant' ? 'Restaurant' : pt === 'both' ? 'Cazare + Restaurant' : 'Cazare'
                    return (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Produs:</span>
                        <span className={`font-medium px-2 py-0.5 rounded-full text-xs ${style}`}>{label}</span>
                      </div>
                    )
                  })()}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                  <div className="text-xs text-gray-500">
                    {new Date(tenant.createdAt).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-2">
                    {isDeleted ? (
                      <>
                        <button
                          onClick={() => handleRestoreTenant(tenant.id)}
                          className="text-green-600 hover:text-green-900"
                          title="Restaurează (rollback)"
                        >
                          <RotateCcw className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handlePurgeTenant(tenant)}
                          className="text-red-700 hover:text-red-900"
                          title="Șterge definitiv (ireversibil)"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => navigate(`/super-admin/tenants/${tenant.id}/staff`)}
                          className="text-indigo-600 hover:text-indigo-900"
                          title="Personal restaurant (ospătar/bucătar)"
                        >
                          <Users className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => navigate(`/super-admin/seo-demo/${tenant.slug}`)}
                          className="text-purple-600 hover:text-purple-900"
                          title="Raport SEO Booster"
                        >
                          <Sparkles className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => openEditModal(tenant)}
                          className="text-blue-600 hover:text-blue-900"
                          title="Editează"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteTenant(tenant)}
                          className={customDomain ? 'text-gray-300 cursor-not-allowed' : 'text-red-600 hover:text-red-900'}
                          title={customDomain ? 'Nu se poate șterge: are domeniu asignat' : 'Șterge (coș de gunoi)'}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
              )
            })}
          </div>
        )}

        {/* Create Tenant Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Adaugă Tenant</h2>
                <button
                  onClick={() => {
                    setShowCreateModal(false)
                    resetForm()
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <TenantForm
                formData={formData}
                setFormData={setFormData}
                onSubmit={handleCreateTenant}
                onCancel={() => {
                  setShowCreateModal(false)
                  resetForm()
                }}
                saving={saving}
                isEdit={false}
                planCatalogOptions={planCatalogOptions}
              />
            </div>
          </div>
        )}

        {/* Edit Tenant Modal */}
        {showEditModal && editingTenant && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg p-6 max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Editează Tenant</h2>
                <button
                  onClick={() => {
                    setShowEditModal(false)
                    setEditingTenant(null)
                    resetForm()
                  }}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <TenantForm
                formData={formData}
                setFormData={setFormData}
                onSubmit={handleUpdateTenant}
                onCancel={() => {
                  setShowEditModal(false)
                  setEditingTenant(null)
                  resetForm()
                }}
                saving={saving}
                isEdit={true}
                planCatalogOptions={planCatalogOptions}
              />
            </div>
          </div>
        )}
      </div>
    </SuperAdminLayout>
  )
}

// Tenant Form Component
function TenantForm({
  formData,
  setFormData,
  onSubmit,
  onCancel,
  saving,
  isEdit,
  planCatalogOptions = [],
}: {
  formData: {
    name: string
    slug: string
    status: string
    subscriptionPlan: string
    productType: 'accommodation' | 'restaurant' | 'both'
    restaurantTier: 'full' | 'menu_site'
    planCatalogId?: string
    planOverridesJson?: string
    isActive: boolean
  }
  setFormData: (data: any) => void
  onSubmit: () => void
  onCancel: () => void
  saving: boolean
  isEdit: boolean
  planCatalogOptions?: Array<{ id: string; slug: string; name: string }>
}) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Nume *</label>
        <input
          type="text"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          required
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Slug *</label>
        <input
          type="text"
          value={formData.slug}
          onChange={(e) => setFormData({ ...formData, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-') })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="ex: my-tenant"
          required
        />
        <p className="text-xs text-gray-500 mt-1">Doar litere mici, cifre și cratime</p>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
        <select
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="trial">Trial</option>
          <option value="active">Active</option>
          <option value="suspended">Suspended</option>
        </select>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Plan Abonament (legacy)</label>
        <select
          value={formData.subscriptionPlan}
          onChange={(e) => setFormData({ ...formData, subscriptionPlan: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="free">Free</option>
          <option value="basic">Basic</option>
          <option value="premium">Premium</option>
          <option value="enterprise">Enterprise</option>
        </select>
        <p className="text-xs text-gray-500 mt-1">Câmp legacy — limitele reale vin din Plan Catalog mai jos.</p>
      </div>
      <div className="border-t border-gray-200 pt-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Plan Catalog (sursa de adevăr pentru limite)</label>
        <select
          value={formData.planCatalogId || ''}
          onChange={(e) => setFormData({ ...formData, planCatalogId: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">— neasignat —</option>
          {planCatalogOptions.map((p) => (
            <option key={p.id} value={p.id}>{p.name} ({p.slug})</option>
          ))}
        </select>
        <p className="text-xs text-gray-500 mt-1">
          La schimbare, trial-ul se setează automat din <code>plan_catalog.trial_days</code>.
        </p>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Plan Overrides (JSON)</label>
        <textarea
          value={formData.planOverridesJson || '{}'}
          onChange={(e) => setFormData({ ...formData, planOverridesJson: e.target.value })}
          rows={4}
          spellCheck={false}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-xs"
          placeholder='{"maxUnits": 10, "includedSmsPerMonth": 500}'
        />
        <p className="text-xs text-gray-500 mt-1">
          Suprascrie cheile din <code>plan_catalog.limits</code>. Folosit pentru contracte vechi /
          grandfathering. Ex: <code>{`{"maxUnits": 10}`}</code> ridică limita unități fără să schimbe planul.
        </p>
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">Tip Produs</label>
        <select
          value={formData.productType}
          onChange={(e) => setFormData({ ...formData, productType: e.target.value as 'accommodation' | 'restaurant' | 'both' })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="accommodation">Cazare (pensiune / hotel — restaurantul e inclus gratuit)</option>
          <option value="restaurant">Restaurant standalone (fără cazare)</option>
          <option value="both">Mixt — cazare + restaurant activ</option>
        </select>
        <p className="text-xs text-gray-500 mt-1">
          Controlează ce tab-uri vede tenantul în admin și ce secțiuni apar pe site. Toate setările rămân editabile după creare.
        </p>
      </div>
      {(formData.productType === 'restaurant' || formData.productType === 'both') && (
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Variantă restaurant</label>
          <select
            value={formData.restaurantTier}
            onChange={(e) => setFormData({ ...formData, restaurantTier: e.target.value as 'full' | 'menu_site' })}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="full">Completă (POS + gestiune + bucătărie + fiscal + staff)</option>
            <option value="menu_site">Site + SmartMenu (meniu + QR + comenzi online + rezervări + POS comenzi)</option>
          </select>
          <p className="text-xs text-gray-500 mt-1">
            La „Site + SmartMenu", partea de gestiune (stocuri, furnizori, NIR, bucătărie, fiscal, personal) e ascunsă. Rămân meniul, QR-ul, comenzile online, rezervările și POS-ul de comenzi online.
          </p>
        </div>
      )}
      <div className="flex items-center">
        <input
          type="checkbox"
          checked={formData.isActive}
          onChange={(e) => setFormData({ ...formData, isActive: e.target.checked })}
          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
        />
        <label className="ml-2 block text-sm text-gray-900">Activ</label>
      </div>
      <div className="mt-6 flex justify-end space-x-3">
        <button
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
        >
          Anulează
        </button>
        <button
          onClick={onSubmit}
          disabled={saving}
          className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center space-x-2"
        >
          {saving ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Se salvează...</span>
            </>
          ) : (
            <span>{isEdit ? 'Actualizează' : 'Creează'}</span>
          )}
        </button>
      </div>
    </div>
  )
}













