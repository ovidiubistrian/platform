/**
 * Super Admin — Plan Catalog
 *
 * Manages the public-facing marketing plan catalog (homepage carousel).
 * Distinct from /super-admin/subscription-plans which manages Stripe-billed
 * tenant subscriptions.
 */
import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ArrowLeft, Plus, Edit, Trash2, Copy, Check, X, ArrowUp, ArrowDown,
  Loader2, Save, Sparkles, RefreshCw, CheckCircle2, AlertCircle,
} from 'lucide-react'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'
import {
  planCatalogApi,
  AUDIENCE_OPTIONS,
  type PlanCatalogPlan,
  type PlanCatalogFeature,
  type PlanCatalogGlobalFeature,
} from '../../lib/api/plan_catalog'

const FEATURE_CATEGORIES = [
  'Website', 'Booking Engine', 'Channel Manager', 'Facturare',
  'AI', 'Growth Center', 'SMS', 'Restaurant/POS', 'Rapoarte',
  'Cursuri', 'Suport', 'Onboarding', 'general',
]

export default function PlanCatalogPage() {
  const [plans, setPlans] = useState<PlanCatalogPlan[]>([])
  const [globalFeatures, setGlobalFeatures] = useState<PlanCatalogGlobalFeature[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)
  const [showGlobalEditor, setShowGlobalEditor] = useState(false)

  const fetchAll = async () => {
    setLoading(true)
    try {
      const [list, gf] = await Promise.all([
        planCatalogApi.adminList(),
        planCatalogApi.adminListGlobalFeatures(),
      ])
      setPlans(list)
      setGlobalFeatures(gf)
    } catch (err) {
      console.error(err)
      alert('Nu s-au putut încărca pachetele.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { void fetchAll() }, [])

  const handleToggleField = async (id: string, field: keyof PlanCatalogPlan, value: boolean) => {
    try {
      await planCatalogApi.adminUpdate(id, { [field]: value } as any)
      setPlans((prev) => prev.map((p) => (p.id === id ? { ...p, [field]: value } : p)))
    } catch {
      alert('Nu s-a putut actualiza.')
    }
  }

  const handleSortMove = async (id: string, direction: -1 | 1) => {
    const sorted = [...plans].sort((a, b) => a.sort_order - b.sort_order)
    const idx = sorted.findIndex((p) => p.id === id)
    const swapWith = sorted[idx + direction]
    if (!swapWith) return
    const a = sorted[idx]
    try {
      await Promise.all([
        planCatalogApi.adminUpdate(a.id, { sort_order: swapWith.sort_order }),
        planCatalogApi.adminUpdate(swapWith.id, { sort_order: a.sort_order }),
      ])
      await fetchAll()
    } catch {
      alert('Eroare la reordonare.')
    }
  }

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Sigur ștergi pachetul "${name}"?`)) return
    try {
      await planCatalogApi.adminDelete(id)
      setPlans((prev) => prev.filter((p) => p.id !== id))
    } catch {
      alert('Nu s-a putut șterge.')
    }
  }

  const handleDuplicate = async (id: string) => {
    try {
      await planCatalogApi.adminDuplicate(id)
      await fetchAll()
    } catch {
      alert('Nu s-a putut duplica.')
    }
  }

  const [syncingId, setSyncingId] = useState<string | null>(null)
  const [syncingAll, setSyncingAll] = useState(false)

  const handleSyncStripe = async (id: string) => {
    setSyncingId(id)
    try {
      const r = await planCatalogApi.adminSyncStripe(id)
      await fetchAll()
      alert(`✅ Sincronizat cu Stripe.\nProduct: ${r.stripe_product_id}\nMonthly: ${r.stripe_monthly_price_id || '—'}\nYearly: ${r.stripe_yearly_price_id || '—'}`)
    } catch (e: any) {
      alert(`❌ ${e?.response?.data?.detail || e?.message || 'Eroare la sync Stripe.'}`)
    } finally {
      setSyncingId(null)
    }
  }

  const handleSyncStripeAll = async () => {
    if (!confirm('Sincronizez toate planurile active cu Stripe? Asta creează/actualizează Products + Prices în contul tău Stripe.')) return
    setSyncingAll(true)
    try {
      const { results } = await planCatalogApi.adminSyncStripeAll()
      const ok = results.filter((r: any) => !r.error).length
      const fail = results.filter((r: any) => r.error)
      let msg = `✅ Sync complet: ${ok}/${results.length} planuri.`
      if (fail.length) msg += `\n\nErori:\n${fail.map((f: any) => `${f.slug}: ${f.error}`).join('\n')}`
      alert(msg)
      await fetchAll()
    } catch (e: any) {
      alert(`❌ ${e?.response?.data?.detail || e?.message || 'Eroare la sync.'}`)
    } finally {
      setSyncingAll(false)
    }
  }

  return (
    <SuperAdminLayout>
      <div className="px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-3">
            <Link
              to="/super-admin/dashboard"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-200 text-gray-600 hover:text-indigo-600"
            >
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <div>
              <h1 className="text-xl sm:text-2xl font-semibold text-gray-900">Plan Catalog</h1>
              <p className="text-sm text-gray-500">
                Pachetele de abonament afișate pe homepage. Editează prețuri, beneficii, audience și ordinea în carusel.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowGlobalEditor((v) => !v)}
              className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-white px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50"
            >
              <Sparkles className="h-4 w-4" />
              Beneficii globale ({globalFeatures.length})
            </button>
            <button
              type="button"
              onClick={handleSyncStripeAll}
              disabled={syncingAll}
              className="inline-flex items-center gap-2 rounded-full border border-purple-300 bg-purple-50 px-4 py-2 text-sm font-semibold text-purple-700 hover:bg-purple-100 disabled:opacity-60"
              title="Push toate planurile active în Stripe (Product + Prices)"
            >
              {syncingAll ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
              Sync toate cu Stripe
            </button>
            <button
              type="button"
              onClick={() => { setCreating(true); setEditingId(null) }}
              className="inline-flex items-center gap-2 rounded-full bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
            >
              <Plus className="h-4 w-4" />
              Pachet nou
            </button>
          </div>
        </div>

        {showGlobalEditor && (
          <GlobalFeaturesPanel
            features={globalFeatures}
            onChange={fetchAll}
            onClose={() => setShowGlobalEditor(false)}
          />
        )}

        {(creating || editingId) && (
          <PlanEditor
            planId={editingId}
            onClose={() => { setCreating(false); setEditingId(null) }}
            onSaved={() => { setCreating(false); setEditingId(null); void fetchAll() }}
          />
        )}

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="h-8 w-8 animate-spin text-indigo-600" /></div>
        ) : (
          <div className="rounded-2xl border border-gray-200 bg-white shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-xs uppercase text-gray-500">
                <tr>
                  <th className="px-3 py-3 text-left">Ordine</th>
                  <th className="px-3 py-3 text-left">Nume</th>
                  <th className="px-3 py-3 text-left">Categorie</th>
                  <th className="px-3 py-3 text-left">Audiență</th>
                  <th className="px-3 py-3 text-right">Lunar</th>
                  <th className="px-3 py-3 text-right">Anual</th>
                  <th className="px-3 py-3 text-center">Activ</th>
                  <th className="px-3 py-3 text-center">Public</th>
                  <th className="px-3 py-3 text-center">Carusel</th>
                  <th className="px-3 py-3 text-center">Recomandat</th>
                  <th className="px-3 py-3 text-center">Stripe</th>
                  <th className="px-3 py-3 text-right">Acțiuni</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {plans.map((p, idx) => (
                  <tr key={p.id} className="hover:bg-gray-50">
                    <td className="px-3 py-3 text-gray-700 font-medium">
                      <div className="flex items-center gap-1">
                        <span>{p.sort_order}</span>
                        <button
                          type="button"
                          onClick={() => handleSortMove(p.id, -1)}
                          disabled={idx === 0}
                          className="p-1 text-gray-400 hover:text-gray-700 disabled:opacity-30"
                        >
                          <ArrowUp className="h-3 w-3" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSortMove(p.id, 1)}
                          disabled={idx === plans.length - 1}
                          className="p-1 text-gray-400 hover:text-gray-700 disabled:opacity-30"
                        >
                          <ArrowDown className="h-3 w-3" />
                        </button>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="font-semibold text-gray-900">{p.name}</div>
                      <div className="text-xs text-gray-500">{p.slug}</div>
                      {p.badge_text && (
                        <span className="mt-1 inline-block rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-semibold text-amber-800">
                          {p.badge_text}
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-gray-600">{p.category || '—'}</td>
                    <td className="px-3 py-3">
                      <div className="flex flex-wrap gap-1">
                        {p.audience.map((a) => (
                          <span key={a} className="rounded bg-indigo-50 px-1.5 py-0.5 text-[10px] text-indigo-700">{a}</span>
                        ))}
                      </div>
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">{Number(p.monthly_price).toFixed(0)} {p.currency}</td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {p.price_text ? <span className="text-xs text-gray-500">custom</span> : `${Number(p.annual_price).toFixed(0)} ${p.currency}`}
                    </td>
                    <td className="px-3 py-3 text-center">
                      <ToggleCell value={p.is_active} onChange={(v) => handleToggleField(p.id, 'is_active', v)} />
                    </td>
                    <td className="px-3 py-3 text-center">
                      <ToggleCell value={p.is_public} onChange={(v) => handleToggleField(p.id, 'is_public', v)} />
                    </td>
                    <td className="px-3 py-3 text-center">
                      <ToggleCell value={p.show_in_carousel} onChange={(v) => handleToggleField(p.id, 'show_in_carousel', v)} />
                    </td>
                    <td className="px-3 py-3 text-center">
                      <ToggleCell value={p.is_recommended} onChange={(v) => handleToggleField(p.id, 'is_recommended', v)} accent="amber" />
                    </td>
                    <td className="px-3 py-3 text-center">
                      {p.stripe_product_id ? (
                        <span title={`Synced: ${p.stripe_synced_at ?? ''}\nProduct: ${p.stripe_product_id}\nMonthly: ${p.stripe_monthly_price_id ?? '—'}\nYearly: ${p.stripe_yearly_price_id ?? '—'}`}
                              className="inline-flex items-center gap-1 text-emerald-600 text-xs">
                          <CheckCircle2 className="h-4 w-4" /> sync
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-amber-600 text-xs" title="Nu este sincronizat cu Stripe">
                          <AlertCircle className="h-4 w-4" /> nesync
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => handleSyncStripe(p.id)} disabled={syncingId === p.id}
                                className="p-1.5 text-purple-600 hover:bg-purple-50 rounded disabled:opacity-50"
                                title="Sincronizează cu Stripe">
                          {syncingId === p.id
                            ? <Loader2 className="h-4 w-4 animate-spin" />
                            : <RefreshCw className="h-4 w-4" />}
                        </button>
                        <button onClick={() => setEditingId(p.id)} className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded" title="Editează">
                          <Edit className="h-4 w-4" />
                        </button>
                        <button onClick={() => handleDuplicate(p.id)} className="p-1.5 text-gray-600 hover:bg-gray-100 rounded" title="Duplică">
                          <Copy className="h-4 w-4" />
                        </button>
                        <button onClick={() => handleDelete(p.id, p.name)} className="p-1.5 text-red-600 hover:bg-red-50 rounded" title="Șterge">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {plans.length === 0 && (
                  <tr><td colSpan={12} className="px-3 py-12 text-center text-gray-500">
                    Nu există pachete. Apasă „Pachet nou" pentru a crea unul.
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </SuperAdminLayout>
  )
}


function ToggleCell({ value, onChange, accent = 'indigo' }: { value: boolean; onChange: (v: boolean) => void; accent?: 'indigo' | 'amber' }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!value)}
      className={`inline-flex h-6 w-10 items-center rounded-full transition-colors ${
        value
          ? accent === 'amber' ? 'bg-amber-500' : 'bg-indigo-600'
          : 'bg-gray-200'
      }`}
    >
      <span className={`inline-block h-4 w-4 rounded-full bg-white shadow transition-transform ${value ? 'translate-x-5' : 'translate-x-1'}`} />
    </button>
  )
}


function PlanEditor({ planId, onClose, onSaved }: { planId: string | null; onClose: () => void; onSaved: () => void }) {
  const isCreate = !planId
  const [loading, setLoading] = useState(!isCreate)
  const [saving, setSaving] = useState(false)
  const [data, setData] = useState<Partial<PlanCatalogPlan>>(() => emptyPlan())
  const [features, setFeatures] = useState<PlanCatalogFeature[]>([])

  useEffect(() => {
    if (isCreate) return
    void (async () => {
      setLoading(true)
      try {
        const p = await planCatalogApi.adminGet(planId!)
        setData(p)
        setFeatures(p.features.map((f) => ({ ...f })))
      } finally {
        setLoading(false)
      }
    })()
  }, [planId])

  const update = (patch: Partial<PlanCatalogPlan>) => setData((prev) => ({ ...prev, ...patch }))
  const updateLimits = (patch: Record<string, any>) =>
    update({ limits: { ...(data.limits || {}), ...patch } } as any)

  const handleSave = async () => {
    setSaving(true)
    try {
      const payload = {
        ...data,
        monthly_price: Number(data.monthly_price ?? 0),
        annual_price: Number(data.annual_price ?? 0),
        features: features.map((f, idx) => ({
          label: f.label,
          description: f.description ?? null,
          category: f.category ?? null,
          is_included: f.is_included !== false,
          sort_order: idx,
        })),
      }
      if (isCreate) {
        await planCatalogApi.adminCreate(payload as any)
      } else {
        await planCatalogApi.adminUpdate(planId!, payload as any)
      }
      onSaved()
    } catch (err: any) {
      alert(`Eroare: ${err.response?.data?.detail || err.message || 'necunoscută'}`)
    } finally {
      setSaving(false)
    }
  }

  const toggleAudience = (val: string) => {
    const cur = new Set(data.audience || [])
    if (cur.has(val)) cur.delete(val); else cur.add(val)
    update({ audience: Array.from(cur) })
  }

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/50">
        <Loader2 className="h-8 w-8 animate-spin text-white" />
      </div>
    )
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-gray-900/50 px-4 py-8 overflow-y-auto" onClick={onClose}>
      <div className="w-full max-w-4xl rounded-3xl border border-gray-200 bg-white p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-gray-100 pb-4">
          <h2 className="text-xl font-semibold text-gray-900">
            {isCreate ? 'Pachet nou' : `Editare: ${data.name}`}
          </h2>
          <button onClick={onClose} className="rounded-full p-1.5 text-gray-400 hover:bg-gray-100">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-2">
          <Field label="Nume pachet" required>
            <input value={data.name || ''} onChange={(e) => update({ name: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Slug (auto din nume dacă lași gol)">
            <input value={data.slug || ''} onChange={(e) => update({ slug: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm font-mono" />
          </Field>
          <Field label="Descriere scurtă" full>
            <input value={data.short_description || ''} onChange={(e) => update({ short_description: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Descriere lungă" full>
            <textarea rows={3} value={data.long_description || ''} onChange={(e) => update({ long_description: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Preț lunar (RON)">
            <input type="number" step="0.01" value={data.monthly_price ?? 0}
              onChange={(e) => update({ monthly_price: e.target.value as any })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Preț anual (RON)">
            <input type="number" step="0.01" value={data.annual_price ?? 0}
              onChange={(e) => update({ annual_price: e.target.value as any })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Discount anual (%)">
            <input type="number" value={data.annual_discount_percent ?? 20}
              onChange={(e) => update({ annual_discount_percent: Number(e.target.value) })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Trial gratuit (zile, 0 = fără)">
            <input type="number" min={0} value={data.trial_days ?? 0}
              onChange={(e) => update({ trial_days: Number(e.target.value) || 0 })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Text preț custom (override afișare)">
            <input value={data.price_text || ''} onChange={(e) => update({ price_text: e.target.value })}
              placeholder="ex: Custom, de la 1.199 RON/lună"
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Categorie">
            <select value={data.category || ''} onChange={(e) => update({ category: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm">
              <option value="">—</option>
              <option value="accommodation">Cazare</option>
              <option value="restaurant">Restaurant</option>
              <option value="mixed">Mixt</option>
              <option value="hotel">Hotel</option>
            </select>
          </Field>
          <Field label="Public țintă (text liber)">
            <input value={data.target_audience || ''} onChange={(e) => update({ target_audience: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Audiență (filtrare onboarding)" full>
            <div className="flex flex-wrap gap-2">
              {AUDIENCE_OPTIONS.map((opt) => {
                const active = (data.audience || []).includes(opt.value)
                return (
                  <button key={opt.value} type="button" onClick={() => toggleAudience(opt.value)}
                    className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
                      active ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                    }`}>
                    {opt.label}
                  </button>
                )
              })}
            </div>
          </Field>

          <Field label="Badge text">
            <input value={data.badge_text || ''} onChange={(e) => update({ badge_text: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="CTA text">
            <input value={data.cta_text || ''} onChange={(e) => update({ cta_text: e.target.value })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="CTA URL">
            <input value={data.cta_url || ''} onChange={(e) => update({ cta_url: e.target.value })}
              placeholder="/admin/onboarding?plan=slug"
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Sort order">
            <input type="number" value={data.sort_order ?? 0}
              onChange={(e) => update({ sort_order: Number(e.target.value) })}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" />
          </Field>
          <Field label="Accent color (hex)">
            <input value={data.accent_color || ''} onChange={(e) => update({ accent_color: e.target.value })}
              placeholder="#6366f1"
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm font-mono" />
          </Field>
          <Field label="Icon (Lucide name)">
            <input value={data.icon_name || ''} onChange={(e) => update({ icon_name: e.target.value })}
              placeholder="Home, Building2, Hotel, ChefHat..."
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm font-mono" />
          </Field>
        </div>

        {/* Flags */}
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
          <FlagToggle label="Activ" value={!!data.is_active} onChange={(v) => update({ is_active: v })} />
          <FlagToggle label="Public" value={!!data.is_public} onChange={(v) => update({ is_public: v })} />
          <FlagToggle label="Afișare homepage" value={!!data.show_on_homepage} onChange={(v) => update({ show_on_homepage: v })} />
          <FlagToggle label="Afișare carusel" value={!!data.show_in_carousel} onChange={(v) => update({ show_in_carousel: v })} />
          <FlagToggle label="Recomandat" value={!!data.is_recommended} onChange={(v) => update({ is_recommended: v })} accent="amber" />
          <FlagToggle label="Ofertă fondator" value={!!data.is_founder_offer} onChange={(v) => update({ is_founder_offer: v })} accent="amber" />
        </div>

        {/* Limits */}
        <h3 className="mt-6 mb-2 text-sm font-semibold text-gray-700">Limite</h3>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          <LimitField label="Proprietăți" k="includedProperties" data={data} update={updateLimits} />
          <LimitField label="Unități / camere max" k="maxUnits" data={data} update={updateLimits} />
          <LimitField label="Locații max" k="maxLocations" data={data} update={updateLimits} />
          <LimitField label="Produse meniu max" k="maxMenuProducts" data={data} update={updateLimits} />
          <LimitField label="Comenzi/lună" k="maxOrdersPerMonth" data={data} update={updateLimits} />
          <LimitField label="Mese max" k="maxTables" data={data} update={updateLimits} />
          <LimitField label="Utilizatori admin" k="adminUsers" data={data} update={updateLimits} />
          <LimitField label="SMS/lună" k="includedSmsPerMonth" data={data} update={updateLimits} />
          <LimitField label="Postări Growth/lună" k="growthCenterPostsPerMonth" data={data} update={updateLimits} />
          <LimitField label="Suport (text)" k="supportLevel" data={data} update={updateLimits} text />
          <LimitField label="Onboarding (text)" k="onboardingType" data={data} update={updateLimits} text />
          <LimitField label="Limbi (text)" k="includedLanguages" data={data} update={updateLimits} text />
        </div>

        {/* Features */}
        <div className="mt-6 mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-700">Beneficii ({features.length})</h3>
          <button type="button" onClick={() => setFeatures([...features, { label: '', category: 'general', is_included: true }])}
            className="inline-flex items-center gap-1 rounded-lg bg-indigo-50 px-3 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100">
            <Plus className="h-3 w-3" /> Adaugă beneficiu
          </button>
        </div>
        <div className="space-y-2">
          {features.map((f, idx) => (
            <div key={idx} className="grid grid-cols-12 gap-2 rounded-lg border border-gray-200 bg-gray-50 p-2">
              <input
                value={f.label}
                onChange={(e) => setFeatures(features.map((x, i) => i === idx ? { ...x, label: e.target.value } : x))}
                placeholder="Label"
                className="col-span-7 rounded border border-gray-200 bg-white px-2 py-1.5 text-sm"
              />
              <select
                value={f.category || 'general'}
                onChange={(e) => setFeatures(features.map((x, i) => i === idx ? { ...x, category: e.target.value } : x))}
                className="col-span-3 rounded border border-gray-200 bg-white px-2 py-1.5 text-xs"
              >
                {FEATURE_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
              <div className="col-span-2 flex items-center justify-end gap-1">
                <button type="button" onClick={() => idx > 0 && setFeatures(swap(features, idx, idx - 1))}
                  disabled={idx === 0} className="p-1 text-gray-400 hover:text-gray-700 disabled:opacity-30">
                  <ArrowUp className="h-3 w-3" />
                </button>
                <button type="button" onClick={() => idx < features.length - 1 && setFeatures(swap(features, idx, idx + 1))}
                  disabled={idx === features.length - 1} className="p-1 text-gray-400 hover:text-gray-700 disabled:opacity-30">
                  <ArrowDown className="h-3 w-3" />
                </button>
                <button type="button" onClick={() => setFeatures(features.filter((_, i) => i !== idx))}
                  className="p-1 text-red-600 hover:bg-red-50 rounded">
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex items-center justify-end gap-2 border-t border-gray-100 pt-4">
          <button type="button" onClick={onClose} className="rounded-lg border border-gray-200 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
            Anulează
          </button>
          <button type="button" onClick={handleSave} disabled={saving || !data.name}
            className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-60">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Salvează
          </button>
        </div>
      </div>
    </div>
  )
}


function Field({ label, children, full = false, required = false }: { label: string; children: React.ReactNode; full?: boolean; required?: boolean }) {
  return (
    <label className={`block ${full ? 'md:col-span-2' : ''}`}>
      <span className="mb-1 block text-xs font-medium uppercase tracking-wide text-gray-500">
        {label}{required && <span className="text-red-500"> *</span>}
      </span>
      {children}
    </label>
  )
}


function FlagToggle({ label, value, onChange, accent = 'indigo' }: { label: string; value: boolean; onChange: (v: boolean) => void; accent?: 'indigo' | 'amber' }) {
  return (
    <button type="button" onClick={() => onChange(!value)}
      className={`flex items-center justify-between rounded-lg border p-2 text-left transition ${
        value
          ? accent === 'amber' ? 'border-amber-300 bg-amber-50' : 'border-indigo-300 bg-indigo-50'
          : 'border-gray-200 bg-white hover:bg-gray-50'
      }`}>
      <span className="text-xs font-semibold text-gray-700">{label}</span>
      {value ? <Check className={`h-4 w-4 ${accent === 'amber' ? 'text-amber-600' : 'text-indigo-600'}`} /> : <X className="h-4 w-4 text-gray-300" />}
    </button>
  )
}


function LimitField({ label, k, data, update, text = false }: { label: string; k: string; data: Partial<PlanCatalogPlan>; update: (patch: Record<string, any>) => void; text?: boolean }) {
  const v = (data.limits as any)?.[k] ?? ''
  return (
    <label className="block">
      <span className="mb-1 block text-xs font-medium uppercase tracking-wide text-gray-500">{label}</span>
      <input
        type={text ? 'text' : 'text'}
        value={v}
        onChange={(e) => {
          const raw = e.target.value
          if (text) { update({ [k]: raw }); return }
          if (raw === '') { update({ [k]: undefined }); return }
          const num = Number(raw)
          update({ [k]: Number.isNaN(num) ? raw : num })
        }}
        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm"
      />
    </label>
  )
}


function GlobalFeaturesPanel({ features, onChange, onClose }: { features: PlanCatalogGlobalFeature[]; onChange: () => void; onClose: () => void }) {
  const [editing, setEditing] = useState<PlanCatalogGlobalFeature[]>(features)
  const [saving, setSaving] = useState(false)

  useMemo(() => setEditing(features), [features])

  const handleAdd = () => setEditing([...editing, {
    id: '', label: '', category: 'core', sort_order: editing.length, is_active: true, created_at: ''
  }])

  const handleSave = async () => {
    setSaving(true)
    try {
      // Sync: create new ones, update existing, delete missing.
      const existingIds = new Set(features.map((f) => f.id))
      const editingIds = new Set(editing.filter((f) => f.id).map((f) => f.id))
      // Delete removed
      for (const f of features) {
        if (!editingIds.has(f.id)) await planCatalogApi.adminDeleteGlobalFeature(f.id)
      }
      // Create / update
      for (let i = 0; i < editing.length; i++) {
        const f = editing[i]
        if (!f.label.trim()) continue
        const payload = { label: f.label, category: f.category, sort_order: i, is_active: f.is_active }
        if (f.id && existingIds.has(f.id)) {
          await planCatalogApi.adminUpdateGlobalFeature(f.id, payload)
        } else {
          await planCatalogApi.adminCreateGlobalFeature(payload)
        }
      }
      onChange()
      onClose()
    } catch (err: any) {
      alert(`Eroare: ${err.response?.data?.detail || 'necunoscută'}`)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="mb-6 rounded-2xl border border-amber-200 bg-amber-50/40 p-5">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-base font-semibold text-amber-900">Beneficii globale</h3>
          <p className="text-xs text-amber-700">Afișate ca „Toate abonamentele includ" deasupra caruselului.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleAdd} className="rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700">
            + Beneficiu
          </button>
          <button onClick={handleSave} disabled={saving} className="inline-flex items-center gap-1 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-indigo-700 disabled:opacity-60">
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
            Salvează
          </button>
          <button onClick={onClose} className="rounded p-1.5 text-amber-700 hover:bg-amber-100"><X className="h-4 w-4" /></button>
        </div>
      </div>
      <div className="space-y-2">
        {editing.map((f, idx) => (
          <div key={idx} className="grid grid-cols-12 gap-2">
            <input value={f.label}
              onChange={(e) => setEditing(editing.map((x, i) => i === idx ? { ...x, label: e.target.value } : x))}
              placeholder="Label" className="col-span-9 rounded border border-amber-200 bg-white px-2 py-1.5 text-sm" />
            <input value={f.category || ''}
              onChange={(e) => setEditing(editing.map((x, i) => i === idx ? { ...x, category: e.target.value } : x))}
              placeholder="categorie" className="col-span-2 rounded border border-amber-200 bg-white px-2 py-1.5 text-xs" />
            <button onClick={() => setEditing(editing.filter((_, i) => i !== idx))}
              className="col-span-1 rounded p-1 text-red-600 hover:bg-red-50"><Trash2 className="h-3 w-3 mx-auto" /></button>
          </div>
        ))}
      </div>
    </div>
  )
}


function emptyPlan(): Partial<PlanCatalogPlan> {
  return {
    name: '',
    slug: '',
    monthly_price: 0,
    annual_price: 0,
    annual_discount_percent: 20,
    currency: 'RON',
    audience: ['accommodation'],
    is_active: true,
    is_public: true,
    show_on_homepage: true,
    show_in_carousel: true,
    is_recommended: false,
    is_founder_offer: false,
    cta_text: 'Alege pachetul',
    sort_order: 99,
    limits: {},
    trial_days: 14,
  }
}


function swap<T>(arr: T[], i: number, j: number): T[] {
  const out = [...arr]
  ;[out[i], out[j]] = [out[j], out[i]]
  return out
}
