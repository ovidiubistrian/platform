/**
 * Super Admin Stripe Configuration Page
 * Matches: app/super-admin/stripe/page.tsx
 */
import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  CreditCard,
  Loader2,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Unplug
} from 'lucide-react'
import { stripeConfigApi, type PlatformOblioStatus } from '../../lib/api/stripe_config'
import SuperAdminLayout from '../../components/layouts/SuperAdminLayout'

interface StripeConfig {
  publishableKey: string
  secretKey: string
  webhookSecret: string
  isTestMode: boolean
  isConfigured: boolean
}

export default function SuperAdminStripePage() {
  const navigate = useNavigate()
  const [config, setConfig] = useState<StripeConfig>({
    publishableKey: '',
    secretKey: '',
    webhookSecret: '',
    isTestMode: true,
    isConfigured: false
  })
  const [loading, setLoading] = useState(true)
  const [testing, setTesting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [oblioStatus, setOblioStatus] = useState<PlatformOblioStatus | null>(null)
  const [oblioEmail, setOblioEmail] = useState('')
  const [oblioSecret, setOblioSecret] = useState('')
  const [oblioCompanyCif, setOblioCompanyCif] = useState('')
  const [oblioSeries, setOblioSeries] = useState('')
  const [oblioProductName, setOblioProductName] = useState('')
  const [oblioVat, setOblioVat] = useState('19')
  const [oblioTesting, setOblioTesting] = useState(false)
  const [oblioSaving, setOblioSaving] = useState(false)
  const [oblioDisconnecting, setOblioDisconnecting] = useState(false)
  const [oblioCompanies, setOblioCompanies] = useState<Array<{ cif?: string; company?: string; name?: string }>>([])
  const [oblioSeriesList, setOblioSeriesList] = useState<Array<{ name?: string; seriesName?: string; type?: string }>>([])
  const [oblioLoadingCompanies, setOblioLoadingCompanies] = useState(false)
  const [oblioLoadingSeries, setOblioLoadingSeries] = useState(false)

  useEffect(() => {
    fetchConfig()
  }, [])

  const fetchConfig = async () => {
    setLoading(true)
    setError(null)
    try {
      const [stripeData, oblioData] = await Promise.all([
        stripeConfigApi.getConfig(),
        stripeConfigApi.getPlatformOblioStatus().catch(() => null),
      ])
      setConfig(stripeData)
      setOblioStatus(oblioData)
      if (oblioData) {
        setOblioEmail(oblioData.oblio_client_id || '')
        setOblioCompanyCif(oblioData.selected_company_cif || '')
        setOblioSeries(oblioData.default_invoice_series || '')
        setOblioProductName(oblioData.invoice_product_name || '')
        setOblioVat(oblioData.default_vat_percentage || '19')
        if (oblioData.has_secret && oblioData.oblio_client_id) {
          loadOblioCompanies()
          if (oblioData.selected_company_cif) {
            loadOblioSeries(oblioData.selected_company_cif)
          }
        }
      }
    } catch (err: any) {
      setError(err.message || 'A apărut o eroare la încărcarea configurației Stripe.')
    } finally {
      setLoading(false)
    }
  }

  const handleTest = async () => {
    setTesting(true)
    setError(null)
    setSuccessMessage(null)
    try {
      const result = await stripeConfigApi.testConnection()
      setSuccessMessage(`Test reușit! ${result.message}`)
    } catch (err: any) {
      setError(err.message || 'A apărut o eroare la testarea configurației Stripe.')
    } finally {
      setTesting(false)
    }
  }

  const loadOblioCompanies = async () => {
    setOblioLoadingCompanies(true)
    try {
      const { companies } = await stripeConfigApi.getPlatformOblioCompanies()
      setOblioCompanies(companies || [])
    } catch (err) {
      // Connection may still be invalid; silently clear
      setOblioCompanies([])
    } finally {
      setOblioLoadingCompanies(false)
    }
  }

  const loadOblioSeries = async (cif: string) => {
    if (!cif) { setOblioSeriesList([]); return }
    setOblioLoadingSeries(true)
    try {
      const { series } = await stripeConfigApi.getPlatformOblioSeries(cif)
      setOblioSeriesList(series || [])
    } catch (err) {
      setOblioSeriesList([])
    } finally {
      setOblioLoadingSeries(false)
    }
  }

  const handleOblioCompanyChange = (cif: string) => {
    setOblioCompanyCif(cif)
    setOblioSeries('')
    setOblioSeriesList([])
    if (cif) loadOblioSeries(cif)
  }

  const handleOblioTest = async () => {
    setOblioTesting(true)
    setError(null)
    setSuccessMessage(null)
    try {
      const result = await stripeConfigApi.testPlatformOblio({
        clientId: oblioEmail || undefined,
        clientSecret: oblioSecret || undefined,
      })
      setSuccessMessage(result.message || 'Conexiune Oblio validată.')
      const status = await stripeConfigApi.getPlatformOblioStatus()
      setOblioStatus(status)
      // Populate companies dropdown from test response or fresh fetch
      if (result.companies && result.companies.length > 0) {
        setOblioCompanies(result.companies as any)
      } else {
        await loadOblioCompanies()
      }
      if (oblioCompanyCif) {
        await loadOblioSeries(oblioCompanyCif)
      }
    } catch (err: any) {
      setError(err.message || 'Nu am putut testa integrarea Oblio.')
    } finally {
      setOblioTesting(false)
    }
  }

  const handleOblioSave = async () => {
    setOblioSaving(true)
    setError(null)
    setSuccessMessage(null)
    try {
      const result = await stripeConfigApi.connectPlatformOblio({
        clientId: oblioEmail,
        clientSecret: oblioSecret || undefined,
        companyCif: oblioCompanyCif || undefined,
        defaultInvoiceSeries: oblioSeries || undefined,
        invoiceProductName: oblioProductName || undefined,
        defaultVatPercentage: oblioVat || undefined,
      })
      setSuccessMessage(result.message || 'Integrarea Oblio a fost salvată.')
      setOblioSecret('')
      const status = await stripeConfigApi.getPlatformOblioStatus()
      setOblioStatus(status)
      setOblioEmail(status.oblio_client_id || '')
      setOblioCompanyCif(status.selected_company_cif || '')
      setOblioSeries(status.default_invoice_series || '')
      setOblioProductName(status.invoice_product_name || '')
      setOblioVat(status.default_vat_percentage || '19')
      // Refresh dropdowns with the freshly saved credentials
      if (status.has_secret && status.oblio_client_id) {
        await loadOblioCompanies()
        if (status.selected_company_cif) {
          await loadOblioSeries(status.selected_company_cif)
        }
      }
    } catch (err: any) {
      setError(err.message || 'Nu am putut salva integrarea Oblio.')
    } finally {
      setOblioSaving(false)
    }
  }

  const handleOblioDisconnect = async () => {
    if (!confirm('Sigur vrei să deconectezi integrarea Oblio pentru facturarea tenantilor?')) return
    setOblioDisconnecting(true)
    setError(null)
    setSuccessMessage(null)
    try {
      const result = await stripeConfigApi.disconnectPlatformOblio()
      setSuccessMessage(result.message || 'Integrare Oblio deconectată.')
      const status = await stripeConfigApi.getPlatformOblioStatus()
      setOblioStatus(status)
      setOblioSecret('')
      setOblioCompanyCif(status.selected_company_cif || '')
      setOblioSeries(status.default_invoice_series || '')
    } catch (err: any) {
      setError(err.message || 'Nu am putut deconecta integrarea Oblio.')
    } finally {
      setOblioDisconnecting(false)
    }
  }

  if (loading) {
    return (
      <SuperAdminLayout>
        <div className="flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          <p className="ml-3 text-lg text-gray-600">Se încarcă configurația Stripe...</p>
        </div>
      </SuperAdminLayout>
    )
  }

  return (
    <SuperAdminLayout>
      <div className="p-6">
        <div className="mb-6">
          <button
            onClick={() => navigate('/super-admin')}
            className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
            <CreditCard className="h-8 w-8 mr-3 text-blue-600" />
            Configurare Stripe
          </h1>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-center">
            <AlertCircle className="h-5 w-5 text-red-600 mr-3" />
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
            <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
            <p className="text-green-800">{successMessage}</p>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <div className="mb-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Status Stripe din environment</h2>
            <p className="text-gray-600 mb-6">
              Configurarea se face din fișierul de environment pe server. În interfață ai doar validare și test de conexiune.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Publishable Key
              </label>
              <div className="mt-1 rounded-md border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 break-all">
                {config.publishableKey || 'Neconfigurat'}
              </div>
              <p className="text-xs text-gray-500 mt-1">Cheia publică Stripe (începe cu pk_)</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Secret Key
              </label>
              <div className="mt-1 rounded-md border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 break-all">
                {config.secretKey || 'Neconfigurat'}
              </div>
              <p className="text-xs text-gray-500 mt-1">Cheia secretă Stripe (începe cu sk_)</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Webhook Secret
              </label>
              <div className="mt-1 rounded-md border border-gray-300 bg-gray-50 px-3 py-2 text-sm text-gray-800 break-all">
                {config.webhookSecret || 'Neconfigurat'}
              </div>
              <p className="text-xs text-gray-500 mt-1">Secretul webhook-ului Stripe (începe cu whsec_)</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Mod de Funcționare
              </label>
              <div className="mt-1">
                <span className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-medium ${
                  config.isTestMode ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {config.isTestMode ? 'Test Mode' : 'Live Mode'}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Detectat automat din `STRIPE_SECRET_KEY`
              </p>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-between">
            <div className="flex items-center">
              {config.isConfigured ? (
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span className="text-sm font-medium">Stripe este configurat</span>
                </div>
              ) : (
                <div className="flex items-center text-orange-600">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  <span className="text-sm font-medium">Stripe nu este configurat</span>
                </div>
              )}
            </div>

            <div className="flex space-x-4">
              <button
                onClick={handleTest}
                disabled={testing}
                className={`px-4 py-2 rounded-md font-medium transition-colors flex items-center ${
                  testing
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                    : 'bg-green-600 text-white hover:bg-green-700'
                }`}
              >
                {testing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Testează...
                  </>
                ) : (
                  'Testează Configurația'
                )}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-white rounded-lg shadow-md p-6 border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">
            Integrare Oblio (facturare tenant după purchase)
          </h2>
          <p className="text-sm text-gray-600 mb-4">
            Folosită pentru emiterea automată a facturii către tenant când plata Stripe se finalizează cu succes.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email Oblio</label>
              <input
                type="email"
                value={oblioEmail}
                onChange={(e) => setOblioEmail(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                placeholder="ex: billing@firma.ro"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">API Secret Oblio</label>
              <input
                type="password"
                value={oblioSecret}
                onChange={(e) => setOblioSecret(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                placeholder={oblioStatus?.has_secret ? 'Lăsați gol pentru a păstra secretul' : 'Introdu API secret'}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Companie {oblioLoadingCompanies && <span className="text-xs text-gray-500">(se încarcă...)</span>}
              </label>
              {oblioCompanies.length > 0 ? (
                <select
                  value={oblioCompanyCif}
                  onChange={(e) => handleOblioCompanyChange(e.target.value)}
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="">-- Selectează o companie --</option>
                  {oblioCompanies.map((c) => (
                    <option key={c.cif} value={c.cif}>
                      {c.company || c.name} ({c.cif})
                    </option>
                  ))}
                </select>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={oblioCompanyCif}
                    onChange={(e) => setOblioCompanyCif(e.target.value)}
                    className="flex-1 rounded-md border border-gray-300 px-3 py-2 text-sm"
                    placeholder="RO12345678"
                  />
                  <button
                    type="button"
                    onClick={loadOblioCompanies}
                    disabled={oblioLoadingCompanies || !oblioStatus?.has_secret}
                    className="px-3 py-2 rounded-md bg-gray-200 text-gray-700 text-xs disabled:opacity-50"
                  >
                    Încarcă
                  </button>
                </div>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Serie factură {oblioLoadingSeries && <span className="text-xs text-gray-500">(se încarcă...)</span>}
              </label>
              {oblioSeriesList.length > 0 ? (
                <select
                  value={oblioSeries}
                  onChange={(e) => setOblioSeries(e.target.value)}
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm bg-white"
                >
                  <option value="">-- Selectează o serie --</option>
                  {oblioSeriesList.map((s) => {
                    const val = s.name || s.seriesName || ''
                    return (
                      <option key={val} value={val}>
                        {val} {s.type ? `(${s.type})` : ''}
                      </option>
                    )
                  })}
                </select>
              ) : (
                <input
                  type="text"
                  value={oblioSeries}
                  onChange={(e) => setOblioSeries(e.target.value)}
                  className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                  placeholder={oblioCompanyCif ? 'Selectează compania mai întâi' : 'FACT'}
                />
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Serviciu factură</label>
              <input
                type="text"
                value={oblioProductName}
                onChange={(e) => setOblioProductName(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                placeholder="Abonament 360Booking"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">TVA (%)</label>
              <input
                type="text"
                value={oblioVat}
                onChange={(e) => setOblioVat(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                placeholder="19"
              />
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              onClick={handleOblioTest}
              disabled={oblioTesting || !oblioEmail}
              className="px-4 py-2 rounded-md bg-gray-800 text-white text-sm disabled:opacity-50"
            >
              {oblioTesting ? 'Testează...' : 'Testează Oblio'}
            </button>
            <button
              onClick={handleOblioSave}
              disabled={oblioSaving || !oblioEmail || (!oblioSecret && !oblioStatus?.has_secret)}
              className="px-4 py-2 rounded-md bg-blue-600 text-white text-sm disabled:opacity-50"
            >
              {oblioSaving ? 'Se salvează...' : 'Salvează integrarea'}
            </button>
            <button
              onClick={handleOblioDisconnect}
              disabled={oblioDisconnecting || oblioStatus?.status !== 'connected'}
              className="px-4 py-2 rounded-md bg-red-600 text-white text-sm disabled:opacity-50 inline-flex items-center"
            >
              <Unplug className="w-4 h-4 mr-2" />
              {oblioDisconnecting ? 'Se deconectează...' : 'Deconectează'}
            </button>
          </div>

          <div className="mt-3 text-sm">
            <span className={`font-medium ${oblioStatus?.status === 'connected' ? 'text-green-700' : 'text-orange-700'}`}>
              Status: {oblioStatus?.status === 'connected' ? 'Conectat' : 'Neconectat'}
            </span>
            {oblioStatus?.last_error && (
              <p className="text-red-600 mt-1">Ultima eroare: {oblioStatus.last_error}</p>
            )}
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 bg-blue-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-blue-900 mb-4">Unde configurezi variabilele</h3>
          <div className="text-blue-800 space-y-2 text-sm">
            <p>
              1. Variabilele Stripe se setează în <code className="bg-blue-100 px-1 rounded">platform/.env</code> pe server (nu în UI).
            </p>
            <p>
              2. Variabile necesare:
              {' '}
              <code className="bg-blue-100 px-1 rounded">STRIPE_PUBLISHABLE_KEY</code>,
              {' '}
              <code className="bg-blue-100 px-1 rounded">STRIPE_SECRET_KEY</code>,
              {' '}
              <code className="bg-blue-100 px-1 rounded">STRIPE_WEBHOOK_SECRET</code>.
            </p>
            <p>
              3. După modificare `.env`, repornește backend-ul ca să încarce noile valori.
            </p>
            <p>
              4. Endpoint webhook Stripe: <code className="bg-blue-100 px-1 rounded">https://360booking.ro/api/webhooks/stripe</code>.
            </p>
            <p>
              5. În Stripe Dashboard: <strong>Developers → Webhooks</strong> și adaugă evenimentele de plată folosite de platformă.
            </p>
          </div>
        </div>
      </div>
    </SuperAdminLayout>
  )
}







