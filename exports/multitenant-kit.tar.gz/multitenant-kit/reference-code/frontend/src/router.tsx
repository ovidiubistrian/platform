/**
 * React Router setup.
 */
import { lazy, Suspense } from 'react'
import { createBrowserRouter, RouterProvider, Outlet, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { TenantSlugProvider } from './context/TenantSlugContext'
import TrackingProvider from './components/tracking/TrackingProvider'
import DocumentTitleUpdater from './components/common/DocumentTitleUpdater'

// Pages
import HomePage from './pages/HomePage'
import RootPage from './pages/RootPage'
import LoginPage from './pages/auth/LoginPage'
import RegisterPage from './pages/auth/RegisterPage'
import ForgotPasswordPage from './pages/auth/ForgotPasswordPage'
import ResetPasswordPage from './pages/auth/ResetPasswordPage'
import VerifyEmailPage from './pages/auth/VerifyEmailPage'
import TenantHomePage from './pages/TenantHomePage'
import UnitDetailsPage from './pages/public/UnitDetailsPage'
import BookingPage from './pages/public/BookingPage'
import BookingSuccessPage from './pages/public/BookingSuccessPage'
import FAQPage from './pages/public/FAQPage'
import AboutPage from './pages/public/AboutPage'
import GalleryPage from './pages/public/GalleryPage'
import PublicPackagesPage from './pages/public/PackagesPage'
import PackageDetailsPage from './pages/public/PackageDetailsPage'
import RestaurantPublicPage from './pages/public/RestaurantPublicPage'
import RestaurantReservePage from './pages/public/RestaurantReservePage'
import ContactPage from './pages/public/ContactPage'
import TermsPage from './pages/public/TermsPage'
import GuestRegistrationPage from './pages/public/GuestRegistrationPage'
import PublicFeedbackPage from './pages/public/FeedbackPage'
import PrivacyPage from './pages/public/PrivacyPage'
import UnsubscribePage from './pages/public/UnsubscribePage'
import DownloadAppPage from './pages/public/DownloadAppPage'
import BlogIndexPage from './pages/public/BlogIndexPage'
import BlogPostPage from './pages/public/BlogPostPage'
import UnsubscribeLeadPage from './pages/UnsubscribeLeadPage'
import ActivityDetailsPage from './pages/public/ActivityDetailsPage'
import TouristAttractionDetailsPage from './pages/public/TouristAttractionDetailsPage'
import EventDetailsPage from './pages/public/EventDetailsPage'
import FacilityDetailsPage from './pages/public/FacilityDetailsPage'
import RequestDemoPage from './pages/public/RequestDemoPage'
import CookiesPage from './pages/public/CookiesPage'
import PublicAccountPage from './pages/public/AccountPage'
import PublicAccountLoginPage from './pages/public/AccountLoginPage'
import PublicAccountMagicPage from './pages/public/AccountMagicPage'
import PublicAccountRegisterPage from './pages/public/AccountRegisterPage'
import RestaurantReviewPage from './pages/public/RestaurantReviewPage'
const RestaurantReviewsPage = lazy(() => import('./pages/admin/restaurant/ReviewsPage'))
const GrowthLayout = lazy(() => import('./pages/admin/restaurant/growth/GrowthLayout'))
const GrowthDashboardPage = lazy(() => import('./pages/admin/restaurant/growth/UniversalDashboardPage'))
const GrowthAutoMenuPage = lazy(() => import('./pages/admin/restaurant/growth/AutoMenuPage'))
const GrowthCustomersPage = lazy(() => import('./pages/admin/restaurant/growth/CustomersPage'))
const GrowthCampaignsPage = lazy(() => import('./pages/admin/restaurant/growth/CampaignsPage'))
const GrowthDiscountsPage = lazy(() => import('./pages/admin/restaurant/growth/DiscountsPage'))
const GrowthPostsPage = lazy(() => import('./pages/admin/restaurant/growth/PostsPage'))
const GrowthAISettingsPage = lazy(() => import('./pages/admin/restaurant/growth/AISettingsPage'))
const GrowthPlaceholderPage = lazy(() => import('./pages/admin/restaurant/growth/PlaceholderPage'))
const GoogleReviewsPage = lazy(() => import('./pages/admin/restaurant/growth/GoogleReviewsPage'))
const GrowthReportsPage = lazy(() => import('./pages/admin/restaurant/growth/ReportsPage'))
import TwoFactorPage from './pages/auth/TwoFactorPage'
import ChangePasswordPage from './pages/auth/ChangePasswordPage'
const AdminDashboardPage = lazy(() => import('./pages/admin/DashboardPage'))
const SeoChecklistPage = lazy(() => import('./pages/admin/SeoChecklistPage'))
const BookingsPage = lazy(() => import('./pages/admin/BookingsPage'))
const BookingDetailPage = lazy(() => import('./pages/admin/bookings/[id]/BookingDetailPage'))
const EditBookingPage = lazy(() => import('./pages/admin/bookings/[id]/EditBookingPage'))
const NewBookingPage = lazy(() => import('./pages/admin/bookings/NewBookingPage'))
const PropertiesUnitsPage = lazy(() => import('./pages/admin/PropertiesUnitsPage'))
const LodgingPosPage = lazy(() => import('./pages/admin/LodgingPosPage'))
const ConfigureUnitPage = lazy(() => import('./pages/admin/properties/units/ConfigureUnitPage'))
const PropertySetupWizardPage = lazy(() => import('./pages/admin/properties/PropertySetupWizardPage'))
const CalendarPage = lazy(() => import('./pages/admin/CalendarPage'))
const FacilityBookingsPage = lazy(() => import('./pages/admin/facility-bookings/FacilityBookingsPage'))
const FacilityCheckinPage = lazy(() => import('./pages/admin/facility-bookings/FacilityCheckinPage'))
const FacilityTicketPage = lazy(() => import('./pages/public/FacilityTicketPage'))
const InvoicesPage = lazy(() => import('./pages/admin/InvoicesPage'))
const NewInvoicePage = lazy(() => import('./pages/admin/invoices/NewInvoicePage'))
const RestaurantOrdersInvoicingPage = lazy(() => import('./pages/admin/invoices/RestaurantOrdersInvoicingPage'))
import { AccommodationOnlyAdmin, AccommodationOnlyPublic, RestaurantSubRoute, RestaurantFullOnlyAdmin, RestaurantSectionAdmin } from './components/guards/TenantTypeGuards'
const InvoiceDetailPage = lazy(() => import('./pages/admin/invoices/[id]/InvoiceDetailPage'))
const InvoiceReportsPage = lazy(() => import('./pages/admin/invoices/InvoiceReportsPage'))
const MessagesPage = lazy(() => import('./pages/admin/MessagesPage'))
const MessengerInboxPage = lazy(() => import('./pages/admin/MessengerInboxPage'))
const CampaignsPage = lazy(() => import('./pages/admin/CampaignsPage'))
const NewCampaignPage = lazy(() => import('./pages/admin/NewCampaignPage'))
const CouponsPage = lazy(() => import('./pages/admin/CouponsPage'))
const SeasonalRulesPage = lazy(() => import('./pages/admin/SeasonalRulesPage'))
const PendingBookingsPage = lazy(() => import('./pages/admin/PendingBookingsPage'))
const FeedbackPage = lazy(() => import('./pages/admin/FeedbackPage'))
const AdminPackagesPage = lazy(() => import('./pages/admin/PackagesPage'))
const RestaurantPage = lazy(() => import('./pages/admin/RestaurantPage'))
const RestaurantIngredientsPage = lazy(() => import('./pages/admin/restaurant/IngredientsPage'))
const RestaurantComplianceQueuePage = lazy(() => import('./pages/admin/restaurant/ComplianceQueuePage'))
const MenuItemCompliancePage = lazy(() => import('./pages/admin/restaurant/MenuItemCompliancePage'))
const RecipesLibraryPage = lazy(() => import('./pages/admin/restaurant/RecipesLibraryPage'))
const ShoppingListPage = lazy(() => import('./pages/admin/restaurant/ShoppingListPage'))
const RestaurantPOSPage = lazy(() => import('./pages/admin/restaurant/POSPage'))
const RestaurantKDSPage = lazy(() => import('./pages/admin/restaurant/KDSPage'))
const RestaurantTableQrPage = lazy(() => import('./pages/admin/restaurant/TableQrPage'))
const RestaurantReportsPage = lazy(() => import('./pages/admin/restaurant/ReportsPage'))
const RestaurantOrdersHistoryPage = lazy(() => import('./pages/admin/restaurant/OrdersHistoryPage'))
const RestaurantInventoryPage = lazy(() => import('./pages/admin/restaurant/InventoryPage'))
const GestiuneReceiptsPage = lazy(() => import('./pages/admin/gestiune/PurchaseReceiptsPage'))
const GestiuneReceiptCreatePage = lazy(() => import('./pages/admin/gestiune/PurchaseReceiptCreatePage'))
const GestiuneReceiptDetailPage = lazy(() => import('./pages/admin/gestiune/PurchaseReceiptDetailPage'))
const GestiuneSuppliersPage = lazy(() => import('./pages/admin/gestiune/SuppliersPage'))
const GestiunePurchaseOrdersPage = lazy(() => import('./pages/admin/gestiune/PurchaseOrdersPage'))
const GestiuneReorderPage = lazy(() => import('./pages/admin/gestiune/ReorderPage'))
const GestiuneDashboardPage = lazy(() => import('./pages/admin/gestiune/InventoryDashboardPage'))
const GestiuneMovementsPage = lazy(() => import('./pages/admin/gestiune/StockMovementsPage'))
const GestiuneIngredientDetailPage = lazy(() => import('./pages/admin/gestiune/IngredientDetailPage'))
const GestiuneInventoryCountsPage = lazy(() => import('./pages/admin/gestiune/InventoryCountsPage'))
const GestiuneInventoryCountDetailPage = lazy(() => import('./pages/admin/gestiune/InventoryCountDetailPage'))
const GestiuneReportsPage = lazy(() => import('./pages/admin/gestiune/ReportsPage'))
const RestaurantFiscalSettingsPage = lazy(() => import('./pages/admin/restaurant/FiscalSettingsPage'))
const RestaurantWhatsAppSettingsPage = lazy(() => import('./pages/admin/restaurant/WhatsAppSettingsPage'))
const RestaurantExternalLinksPage = lazy(() => import('./pages/admin/restaurant/ExternalLinksPage'))
const RestaurantDeliveryPage = lazy(() => import('./pages/admin/restaurant/DeliveryPage'))
const RestaurantDeliveryFeePage = lazy(() => import('./pages/admin/restaurant/DeliveryFeePage'))
const RestaurantStaffPage = lazy(() => import('./pages/admin/restaurant/StaffPage'))
const RestaurantKioskSettingsPage = lazy(() => import('./pages/admin/restaurant/KioskSettingsPage'))
const RestaurantPrintersPage = lazy(() => import('./pages/admin/restaurant/PrintersPage'))
import KioskShellPage from './pages/public/KioskShellPage'
const RestaurantMenuPdfPage = lazy(() => import('./pages/admin/restaurant/MenuPdfPage'))
const AnafIntegrationPage = lazy(() => import('./pages/admin/integrations/AnafIntegrationPage'))
const IntegrationsHubPage = lazy(() => import('./pages/admin/integrations/IntegrationsHubPage'))
const PaymentLogsPage = lazy(() => import('./pages/admin/integrations/PaymentLogsPage'))
const FacebookIntegrationPage = lazy(() => import('./pages/admin/integrations/FacebookIntegrationPage'))
const IncomingInvoicesPage = lazy(() => import('./pages/admin/invoices/IncomingInvoicesPage'))
const IncomingInvoiceDetailPage = lazy(() => import('./pages/admin/invoices/[id]/IncomingInvoiceDetailPage'))
const SuppliersPage = lazy(() => import('./pages/admin/invoices/SuppliersPage'))
import TableOrderPage from './pages/public/TableOrderPage'
import OnlineOrderPage from './pages/public/OnlineOrderPage'
const ChannelManagerPage = lazy(() => import('./pages/admin/ChannelManagerPage'))
const AnalyticsPage = lazy(() => import('./pages/admin/AnalyticsPage'))
const AnalyticsLayout = lazy(() => import('./pages/admin/analytics/AnalyticsLayout'))
const AnalyticsHighlightsPage = lazy(() => import('./pages/admin/analytics/HighlightsPage'))
const AnalyticsRealTimePage = lazy(() => import('./pages/admin/analytics/RealTimePage'))
const AnalyticsTrafficPage = lazy(() => import('./pages/admin/analytics/TrafficPage'))
const AnalyticsMarketingSeoPage = lazy(() => import('./pages/admin/analytics/MarketingSeoPage'))
const MonitoringPage = lazy(() => import('./pages/admin/MonitoringPage'))
const SubscriptionPage = lazy(() => import('./pages/admin/SubscriptionPage'))
const SupportPage = lazy(() => import('./pages/admin/SupportPage'))
const AccountPage = lazy(() => import('./pages/admin/AccountPage'))
const SettingsPage = lazy(() => import('./pages/admin/SettingsPage'))
const SiteConfigPage = lazy(() => import('./pages/admin/settings/SiteConfigPage'))
const LanguagesPage = lazy(() => import('./pages/admin/settings/LanguagesPage'))
const FacilitiesPage = lazy(() => import('./pages/admin/settings/FacilitiesPage'))
const ActivitiesPage = lazy(() => import('./pages/admin/settings/ActivitiesPage'))
const TouristAttractionsPage = lazy(() => import('./pages/admin/settings/TouristAttractionsPage'))
const PartnersPage = lazy(() => import('./pages/admin/settings/PartnersPage'))
const EventsPage = lazy(() => import('./pages/admin/settings/EventsPage'))
const BusinessEmailPage = lazy(() => import('./pages/admin/settings/BusinessEmailPage'))
const ChatPage = lazy(() => import('./pages/admin/settings/ChatPage'))
const DomainPage = lazy(() => import('./pages/admin/settings/DomainPage'))
const LegalEntityPage = lazy(() => import('./pages/admin/settings/LegalEntityPage'))
const SocialMediaPage = lazy(() => import('./pages/admin/settings/SocialMediaPage'))
const ChatWidgetPage = lazy(() => import('./pages/admin/settings/ChatWidgetPage'))
const MailgunPage = lazy(() => import('./pages/admin/settings/MailgunPage'))
const PricesPage = lazy(() => import('./pages/admin/settings/PricesPage'))
const SavedRepliesPage = lazy(() => import('./pages/admin/settings/SavedRepliesPage'))
const TrackingSettingsPage = lazy(() => import('./pages/admin/settings/TrackingSettingsPage'))
const SuperAdminDashboardPage = lazy(() => import('./pages/super-admin/DashboardPage'))
const SuperAdminArchitecturePage = lazy(() => import('./pages/super-admin/ArchitecturePage'))
const SuperAdminUsersPage = lazy(() => import('./pages/super-admin/UsersPage'))
const SuperAdminTenantsPage = lazy(() => import('./pages/super-admin/TenantsPage'))
const SuperAdminSubscriptionPlansPage = lazy(() => import('./pages/super-admin/SubscriptionPlansPage'))
const SuperAdminPlanCatalogPage = lazy(() => import('./pages/super-admin/PlanCatalogPage'))
const SuperAdminAddOnPackagesPage = lazy(() => import('./pages/super-admin/AddOnPackagesPage'))
const SuperAdminBillingReportPage = lazy(() => import('./pages/super-admin/BillingReportPage'))
const SuperAdminRestaurantOrdersSettingsPage = lazy(() => import('./pages/super-admin/RestaurantOrdersSettingsPage'))
const SuperAdminTenantStaffPage = lazy(() => import('./pages/super-admin/TenantStaffPage'))
const SuperAdminPlatformSmsTemplatesPage = lazy(() => import('./pages/super-admin/PlatformSmsTemplatesPage'))
const SuperAdminPlatformContactPage = lazy(() => import('./pages/super-admin/PlatformContactPage'))
const SuperAdminMarketplaceBrandingPage = lazy(() => import('./pages/super-admin/MarketplaceBrandingPage'))
const SuperAdminMarketplaceBenefitsPage = lazy(() => import('./pages/super-admin/MarketplaceBenefitsPage'))
const SuperAdminAnalyticsPage = lazy(() => import('./pages/super-admin/AnalyticsPage'))
const SuperAdminVisitorAnalyticsPage = lazy(() => import('./pages/super-admin/VisitorAnalyticsPage'))
const SuperAdminCostDashboardPage = lazy(() => import('./pages/super-admin/CostDashboardPage'))
const SuperAdminSeoDemoPage = lazy(() => import('./pages/super-admin/SeoDemoPage'))
const SuperAdminBlogPage = lazy(() => import('./pages/super-admin/BlogPage'))
const SuperAdminMarketingHubPage = lazy(() => import('./pages/super-admin/MarketingHubPage'))
const SuperAdminVisibilityFeaturesPage = lazy(() => import('./pages/super-admin/VisibilityFeaturesPage'))
const SuperAdminLeadMarketingPage = lazy(() => import('./pages/super-admin/LeadMarketingPage'))
const SuperAdminLeadTemplatesPage = lazy(() => import('./pages/super-admin/LeadTemplatesPage'))
const SuperAdminGlobalSuppliersPage = lazy(() => import('./pages/super-admin/GlobalSuppliersPage'))
const SuperAdminGlobalTaxonomyPage = lazy(() => import('./pages/super-admin/GlobalTaxonomyPage'))
const SuperAdminGlobalRulesPage = lazy(() => import('./pages/super-admin/GlobalRulesPage'))
const SuperAdminGlobalSuggestionsPage = lazy(() => import('./pages/super-admin/GlobalSuggestionsPage'))
const SuperAdminLeadCampaignsPage = lazy(() => import('./pages/super-admin/LeadCampaignsPage'))
const SuperAdminDocsScreenshotsPage = lazy(() => import('./pages/super-admin/DocsScreenshotsPage'))
const SuperAdminTutorialPhotographyAssetsPage = lazy(() => import('./pages/super-admin/TutorialPhotographyAssetsPage'))
const SuperAdminSystemPage = lazy(() => import('./pages/super-admin/SystemPage'))
const SuperAdminTranslationsPage = lazy(() => import('./pages/super-admin/TranslationsPage'))
const SuperAdminLanguagesPage = lazy(() => import('./pages/super-admin/LanguagesPage'))
const SuperAdminDNSPage = lazy(() => import('./pages/super-admin/DNSPage'))
const SuperAdminIntegrationsPage = lazy(() => import('./pages/super-admin/IntegrationsPage'))
const SuperAdminAnafConfigPage = lazy(() => import('./pages/super-admin/AnafConfigPage'))
const SuperAdminLimitsPage = lazy(() => import('./pages/super-admin/LimitsPage'))
const SuperAdminPricingPage = lazy(() => import('./pages/super-admin/PricingPage'))
const SuperAdminSalesPage = lazy(() => import('./pages/super-admin/SalesPage'))
const SuperAdminDemoPage = lazy(() => import('./pages/super-admin/DemoPage'))
const SuperAdminDemoBuilderPage = lazy(() => import('./pages/super-admin/DemoBuilderPage'))
const SuperAdminDemoTenantListPage = lazy(() => import('./pages/super-admin/DemoTenantListPage'))
const SuperAdminEcosystemPage = lazy(() => import('./pages/super-admin/EcosystemPage'))
const SuperAdminDemoRequestsPage = lazy(() => import('./pages/super-admin/DemoRequestsPage'))
const SuperAdminSupportPage = lazy(() => import('./pages/super-admin/SupportPage'))
const SuperAdminSmsPage = lazy(() => import('./pages/super-admin/SmsPage'))
const SuperAdminMailgunPage = lazy(() => import('./pages/super-admin/MailgunPage'))
const SuperAdminConfigurationsPage = lazy(() => import('./pages/super-admin/ConfigurationsPage'))
const SuperAdminStripePage = lazy(() => import('./pages/super-admin/StripePage'))
const SuperAdminOnboardingWelcomePage = lazy(() => import('./pages/super-admin/OnboardingWelcomePage'))
const SuperAdminNotificationsSettingsPage = lazy(() => import('./pages/super-admin/NotificationsSettingsPage'))
const SuperAdminSalesCodesPage = lazy(() => import('./pages/super-admin/SalesCodesPage'))
const AdminNotificationsPage = lazy(() => import('./pages/admin/settings/NotificationsPage'))
const OnboardingWizardPage = lazy(() => import('./pages/admin/onboarding/OnboardingWizardPage'))
const BookingAutopilotPage = lazy(() => import('./pages/admin/BookingAutopilotPage'))
const GoogleHotelsPage = lazy(() => import('./pages/admin/GoogleHotelsPage'))
const SmartLockPage = lazy(() => import('./pages/admin/settings/SmartLockPage'))
const HousekeeperProfilePage = lazy(() => import('./pages/admin/HousekeeperProfilePage'))
const WelcomeAdminPage = lazy(() => import('./pages/admin/WelcomePage'))
import WelcomePublicPage from './pages/public/WelcomePublicPage'
import HousekeeperLayout from './components/layouts/HousekeeperLayout'
const HousekeeperTasksPage = lazy(() => import('./pages/housekeeper/HousekeeperTasksPage'))
const HousekeeperHistoryPage = lazy(() => import('./pages/housekeeper/HousekeeperHistoryPage'))
const HousekeeperCalendarPage = lazy(() => import('./pages/housekeeper/HousekeeperCalendarPage'))
const BookingEnginePage = lazy(() => import('./pages/demo/BookingEnginePage'))
const AdminPage = lazy(() => import('./pages/demo/AdminPage'))
const DemoPricingPage = lazy(() => import('./pages/demo/PricingPage'))
const DemoRestaurantPage = lazy(() => import('./pages/demo/RestaurantPage'))
const DemoPackagesPage = lazy(() => import('./pages/demo/PackagesPage'))
const DemoCampaignsPage = lazy(() => import('./pages/demo/CampaignsPage'))
const AutoLoginPage = lazy(() => import('./pages/demo/AutoLoginPage'))
const SalesDashboardPage = lazy(() => import('./pages/sales/DashboardPage'))
const OnboardTenantPage = lazy(() => import('./pages/sales/OnboardTenantPage'))
const OnboardPage = lazy(() => import('./pages/sales/OnboardPage'))
const DocsLayout = lazy(() => import('./pages/docs/DocsLayout'))
const DocsIndexPage = lazy(() => import('./pages/docs/topics/_index'))
const DocsTopicRouter = lazy(() => import('./pages/docs/topics/_router'))
// Layouts
import AdminLayout from './components/layouts/AdminLayout'
import SuperAdminLayout from './components/layouts/SuperAdminLayout'

// Auth
import ProtectedRoute from './components/auth/ProtectedRoute'

// SEO
import { AutoNoIndex } from './lib/seo'

const router = createBrowserRouter([
  {
    element: (
      <TenantSlugProvider>
        <DocumentTitleUpdater />
        <AutoNoIndex />
        <TrackingProvider>
          {/* Lazy admin/super-admin/sales/demo/docs/onboarding routes
              live in their own chunks downloaded on demand. The fallback
              is intentionally blank — every lazy route is behind a login
              wall (no SEO impact) so a brief empty paint while the
              chunk arrives is the right UX. */}
          <Suspense fallback={<div />}>
            <Outlet />
          </Suspense>
        </TrackingProvider>
      </TenantSlugProvider>
    ),
    children: [
      {
        path: '/',
        element: <RootPage />,
      },
      {
        path: '/auth/login',
    element: <LoginPage />,
  },
  {
    path: '/auth/register',
    element: <RegisterPage />,
  },
  {
    // Friendly aliases — /login and /register are shorter and what docs /
    // support messages naturally use. Without these they fall through to
    // /:slug and show "Pensiunea nu a fost găsită" (same trap as /sales
    // earlier today).
    path: '/login',
    element: <Navigate to="/auth/login" replace />,
  },
  {
    path: '/register',
    element: <Navigate to="/auth/register" replace />,
  },
  {
    path: '/auth/forgot-password',
    element: <ForgotPasswordPage />,
  },
  {
    path: '/auth/reset-password',
    element: <ResetPasswordPage />,
  },
  {
    path: '/auth/verify-email',
    element: <VerifyEmailPage />,
  },
  {
    path: '/auth/two-factor',
    element: <TwoFactorPage />,
  },
  {
    path: '/auth/change-password',
    element: <ChangePasswordPage />,
  },
  {
    path: '/request-demo',
    element: <RequestDemoPage />,
  },
  {
    path: '/cookies',
    element: <CookiesPage />,
  },
  {
    path: '/account',
    element: <PublicAccountPage />,
  },
  {
    path: '/account/login',
    element: <PublicAccountLoginPage />,
  },
  {
    path: '/account/register',
    element: <PublicAccountRegisterPage />,
  },
  {
    path: '/account/magic',
    element: <PublicAccountMagicPage />,
  },
  // Per-tenant path variants (360booking.ro/<slug>/account). The slug
  // comes from the URL param, which useTenantSlug() picks up; the
  // same pages render.
  {
    path: '/:slug/account',
    element: <PublicAccountPage />,
  },
  {
    path: '/:slug/account/login',
    element: <PublicAccountLoginPage />,
  },
  {
    path: '/:slug/account/register',
    element: <PublicAccountRegisterPage />,
  },
  {
    path: '/:slug/account/magic',
    element: <PublicAccountMagicPage />,
  },
  {
    path: '/r/:qrToken',
    element: <RestaurantReviewPage />,
  },
  {
    path: '/docs',
    element: <DocsLayout />,
    children: [
      { index: true, element: <DocsIndexPage /> },
      { path: ':slug', element: <DocsTopicRouter /> },
    ],
  },
  {
    path: '/demo/booking-engine',
    element: <BookingEnginePage />,
  },
  {
    path: '/demo/admin',
    element: <AdminPage />,
  },
  {
    path: '/demo/pricing',
    element: <DemoPricingPage />,
  },
  {
    path: '/demo/restaurant',
    element: <DemoRestaurantPage />,
  },
  {
    path: '/demo/packages',
    element: <DemoPackagesPage />,
  },
  {
    path: '/demo/campaigns',
    element: <DemoCampaignsPage />,
  },
  {
    path: '/demo/auto-login',
    element: <AutoLoginPage />,
  },
  {
    path: '/sales',
    element: <Navigate to="/sales/dashboard" replace />,
  },
  {
    path: '/sales/dashboard',
    element: <SalesDashboardPage />,
  },
  {
    path: '/sales/onboard-tenant',
    element: <OnboardTenantPage />,
  },
  {
    path: '/sales/onboard',
    element: <OnboardPage />,
  },
  // Tenant-by-domain: pe domeniu dedicat (ex. pine-hill.ro) rute fără /slug
  { path: '/despre', element: <AboutPage /> },
  { path: '/galerie', element: <GalleryPage /> },
  { path: '/contact', element: <ContactPage /> },
  { path: '/faq', element: <FAQPage /> },
  { path: '/termeni', element: <TermsPage /> },
  { path: '/confidentialitate', element: <PrivacyPage /> },
  { path: '/unsubscribe', element: <UnsubscribePage /> },
  { path: '/unsubscribe/lead', element: <UnsubscribeLeadPage /> },
  { path: '/app', element: <DownloadAppPage /> },
  // Travel blog — marketplace-only (360booking.ro/blog)
  { path: '/blog', element: <BlogIndexPage /> },
  { path: '/blog/:slug', element: <BlogPostPage /> },
  { path: '/booking', element: <AccommodationOnlyPublic><BookingPage /></AccommodationOnlyPublic> },
  { path: '/booking/success', element: <AccommodationOnlyPublic><BookingSuccessPage /></AccommodationOnlyPublic> },
  { path: '/packages', element: <AccommodationOnlyPublic><PublicPackagesPage /></AccommodationOnlyPublic> },
  { path: '/packages/:packageSlug', element: <AccommodationOnlyPublic><PackageDetailsPage /></AccommodationOnlyPublic> },
  { path: '/restaurant', element: <RestaurantSubRoute><RestaurantPublicPage /></RestaurantSubRoute> },
  { path: '/restaurant/reserve', element: <RestaurantReservePage /> },
  { path: '/masa/:qrToken', element: <TableOrderPage /> },
  // Kiosk shell: the tablet boots here; if the device has no paired
  // token yet it shows the pairing screen, otherwise it calls /pair
  // and renders the session snapshot.
  { path: '/kiosk', element: <KioskShellPage /> },
  // Tenant-scoped kiosk: locked to the slug in the URL so a tablet
  // paired against tenant A can't be pointed at tenant B's branded
  // page and accidentally leak through. The slug travels on every
  // backend call as an extra scope gate on top of the token.
  { path: '/:slug/kiosk', element: <KioskShellPage /> },
  { path: '/restaurant/order-online', element: <OnlineOrderPage /> },
  { path: '/activity/:activitySlug', element: <ActivityDetailsPage /> },
  { path: '/tourist-attraction/:attractionSlug', element: <TouristAttractionDetailsPage /> },
  { path: '/event/:eventSlug', element: <EventDetailsPage /> },
  { path: '/facility/:facilitySlug', element: <FacilityDetailsPage /> },
  { path: '/facilitati/bilet/:token', element: <FacilityTicketPage /> },
  { path: '/unit/:unitSlug', element: <AccommodationOnlyPublic><UnitDetailsPage /></AccommodationOnlyPublic> },
  {
    path: '/:slug',
    element: <TenantHomePage />,
  },
  {
    path: '/units/:slug',
    element: <AccommodationOnlyPublic><UnitDetailsPage /></AccommodationOnlyPublic>,
  },
  {
    path: '/:slug/unit/:unitSlug',
    element: <AccommodationOnlyPublic><UnitDetailsPage /></AccommodationOnlyPublic>,
  },
  {
    path: '/:slug/booking',
    element: <AccommodationOnlyPublic><BookingPage /></AccommodationOnlyPublic>,
  },
  {
    path: '/:slug/booking/success',
    element: <AccommodationOnlyPublic><BookingSuccessPage /></AccommodationOnlyPublic>,
  },
  {
    path: '/:slug/faq',
    element: <FAQPage />,
  },
  {
    path: '/:slug/despre',
    element: <AboutPage />,
  },
      {
        path: '/:slug/galerie',
        element: <GalleryPage />,
      },
      {
        path: '/:slug/packages',
        element: <AccommodationOnlyPublic><PublicPackagesPage /></AccommodationOnlyPublic>,
      },
      {
        path: '/:slug/packages/:packageSlug',
        element: <AccommodationOnlyPublic><PackageDetailsPage /></AccommodationOnlyPublic>,
      },
  {
    path: '/:slug/restaurant',
    element: <RestaurantSubRoute><RestaurantPublicPage /></RestaurantSubRoute>,
  },
  {
    path: '/:slug/restaurant/reserve',
    element: <RestaurantReservePage />,
  },
  {
    path: '/:slug/masa/:qrToken',
    element: <TableOrderPage />,
  },
  {
    path: '/:slug/restaurant/order-online',
    element: <OnlineOrderPage />,
  },
  {
    path: '/:slug/welcome/:unitSlug',
    element: <WelcomePublicPage />,
  },
  {
    path: '/welcome/:unitSlug',
    element: <WelcomePublicPage />,
  },
  {
    path: '/:slug/contact',
    element: <ContactPage />,
  },
  {
    path: '/:slug/termeni',
    element: <TermsPage />,
  },
  {
    path: '/:slug/confidentialitate',
    element: <PrivacyPage />,
  },
  {
    path: '/:slug/guest-form',
    element: <GuestRegistrationPage />,
  },
  {
    path: '/:slug/feedback',
    element: <PublicFeedbackPage />,
  },
  {
    path: '/:slug/activity/:activitySlug',
    element: <ActivityDetailsPage />,
  },
  {
    path: '/:slug/tourist-attraction/:attractionSlug',
    element: <TouristAttractionDetailsPage />,
  },
  {
    path: '/:slug/event/:eventSlug',
    element: <EventDetailsPage />,
  },
  {
    path: '/:slug/facility/:facilitySlug',
    element: <FacilityDetailsPage />,
  },
  {
    path: '/admin',
    element: (
      <ProtectedRoute requireRole="admin">
        <AdminLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <AdminDashboardPage />,
      },
      {
        path: 'dashboard',
        element: <AdminDashboardPage />,
      },
      {
        path: 'seo',
        element: <SeoChecklistPage />,
      },
      {
        path: 'lodging-pos',
        element: <AccommodationOnlyAdmin><LodgingPosPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'bookings',
        element: <AccommodationOnlyAdmin><BookingsPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'bookings/new',
        element: <AccommodationOnlyAdmin><NewBookingPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'bookings/:id',
        element: <AccommodationOnlyAdmin><BookingDetailPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'bookings/:id/edit',
        element: <AccommodationOnlyAdmin><EditBookingPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'properties/units',
        element: <AccommodationOnlyAdmin><PropertiesUnitsPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'properties/units/configure',
        element: <AccommodationOnlyAdmin><ConfigureUnitPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'properties/setup',
        element: <AccommodationOnlyAdmin><PropertySetupWizardPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'calendar',
        element: <AccommodationOnlyAdmin><CalendarPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'facility-bookings',
        element: <FacilityBookingsPage />,
      },
      {
        path: 'facility-checkin',
        element: <FacilityCheckinPage />,
      },
      {
        path: 'invoices',
        element: <InvoicesPage />,
      },
      {
        path: 'invoices/reports',
        element: <InvoiceReportsPage />,
      },
      {
        path: 'invoices/new',
        element: <NewInvoicePage />,
      },
      {
        path: 'invoices/from-orders',
        element: <RestaurantOrdersInvoicingPage />,
      },
      {
        path: 'invoices/:id',
        element: <InvoiceDetailPage />,
      },
      {
        path: 'messages',
        element: <MessagesPage />,
      },
      {
        path: 'messenger',
        element: <MessengerInboxPage />,
      },
      {
        path: 'campaigns',
        element: <CampaignsPage />,
      },
      {
        path: 'campaigns/new',
        element: <NewCampaignPage />,
      },
      {
        path: 'coupons',
        element: <CouponsPage />,
      },
      {
        path: 'seasonal-rules',
        element: <SeasonalRulesPage />,
      },
      {
        path: 'pending-bookings',
        element: <PendingBookingsPage />,
      },
      {
        path: 'feedback',
        element: <FeedbackPage />,
      },
      {
        path: 'packages',
        element: <AccommodationOnlyAdmin><AdminPackagesPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'restaurant/pos',
        element: <RestaurantPOSPage />,
      },
      {
        path: 'restaurant/kds',
        element: <RestaurantFullOnlyAdmin><RestaurantKDSPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/table-qr',
        element: <RestaurantTableQrPage />,
      },
      {
        path: 'restaurant/reports',
        element: <RestaurantReportsPage />,
      },
      {
        path: 'restaurant/orders-history',
        element: <RestaurantOrdersHistoryPage />,
      },
      {
        path: 'restaurant/inventory',
        element: <RestaurantFullOnlyAdmin><RestaurantInventoryPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune',
        element: <RestaurantFullOnlyAdmin><GestiuneDashboardPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/miscari',
        element: <RestaurantFullOnlyAdmin><GestiuneMovementsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/ingrediente/:id',
        element: <RestaurantFullOnlyAdmin><GestiuneIngredientDetailPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/receptii',
        element: <RestaurantFullOnlyAdmin><GestiuneReceiptsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/receptii/nou',
        element: <RestaurantFullOnlyAdmin><GestiuneReceiptCreatePage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/receptii/:id',
        element: <RestaurantFullOnlyAdmin><GestiuneReceiptDetailPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/furnizori',
        element: <RestaurantFullOnlyAdmin><GestiuneSuppliersPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/comenzi',
        element: <RestaurantFullOnlyAdmin><GestiunePurchaseOrdersPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/reorder',
        element: <RestaurantFullOnlyAdmin><GestiuneReorderPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/inventar',
        element: <RestaurantFullOnlyAdmin><GestiuneInventoryCountsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/inventar/:id',
        element: <RestaurantFullOnlyAdmin><GestiuneInventoryCountDetailPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'gestiune/rapoarte',
        element: <RestaurantFullOnlyAdmin><GestiuneReportsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/fiscal',
        element: <RestaurantFullOnlyAdmin><RestaurantFiscalSettingsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/whatsapp',
        element: <RestaurantWhatsAppSettingsPage />,
      },
      {
        path: 'restaurant/links',
        element: <RestaurantExternalLinksPage />,
      },
      {
        path: 'restaurant/delivery',
        element: <RestaurantDeliveryPage />,
      },
      {
        path: 'restaurant/delivery-fee',
        element: <RestaurantDeliveryFeePage />,
      },
      {
        path: 'restaurant/staff',
        element: <RestaurantFullOnlyAdmin><RestaurantStaffPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/kiosk',
        element: <RestaurantFullOnlyAdmin><RestaurantKioskSettingsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/printers',
        element: <RestaurantFullOnlyAdmin><RestaurantPrintersPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/menu-pdf',
        element: <RestaurantMenuPdfPage />,
      },
      {
        path: 'restaurant/ingredients',
        element: <RestaurantFullOnlyAdmin><RestaurantIngredientsPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/compliance-queue',
        element: <RestaurantComplianceQueuePage />,
      },
      {
        path: 'restaurant/menu-items/:itemId/compliance',
        element: <MenuItemCompliancePage />,
      },
      {
        path: 'restaurant/recipes',
        element: <RestaurantFullOnlyAdmin><RecipesLibraryPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/shopping-list',
        element: <RestaurantFullOnlyAdmin><ShoppingListPage /></RestaurantFullOnlyAdmin>,
      },
      {
        path: 'restaurant/reviews',
        element: <RestaurantReviewsPage />,
      },
      {
        path: 'restaurant/growth-center',
        element: <GrowthLayout />,
        children: [
          { index: true, element: <Navigate to="dashboard" replace /> },
          { path: 'dashboard', element: <GrowthDashboardPage /> },
          { path: 'auto-menu', element: <GrowthAutoMenuPage /> },
          { path: 'posts', element: <GrowthPostsPage /> },
          { path: 'customers', element: <GrowthCustomersPage /> },
          { path: 'campaigns', element: <GrowthCampaignsPage /> },
          { path: 'discounts', element: <GrowthDiscountsPage /> },
          { path: 'reviews', element: <GoogleReviewsPage /> },
          { path: 'integrations', element: <Navigate to="/admin/settings/integrations" replace /> },
          { path: 'reports', element: <GrowthReportsPage /> },
          { path: 'ai-settings', element: <GrowthAISettingsPage /> },
        ],
      },
      // Universal growth center alias — same component tree, accommodation-only
      // and 'both' tenants land here from outside the /admin/restaurant section.
      { path: 'growth-center', element: <Navigate to="/admin/restaurant/growth-center/dashboard" replace /> },
      { path: 'growth-center/dashboard', element: <Navigate to="/admin/restaurant/growth-center/dashboard" replace /> },
      { path: 'growth-center/reviews', element: <Navigate to="/admin/restaurant/growth-center/reviews" replace /> },
      { path: 'growth-center/customers', element: <Navigate to="/admin/restaurant/growth-center/customers" replace /> },
      { path: 'growth-center/campaigns', element: <Navigate to="/admin/restaurant/growth-center/campaigns" replace /> },
      // Backward-compat redirects: /admin/restaurant/growth/* → /admin/restaurant/growth-center/*
      { path: 'restaurant/growth', element: <Navigate to="/admin/restaurant/growth-center/dashboard" replace /> },
      { path: 'restaurant/growth/dashboard', element: <Navigate to="/admin/restaurant/growth-center/dashboard" replace /> },
      { path: 'restaurant/growth/auto-menu', element: <Navigate to="/admin/restaurant/growth-center/auto-menu" replace /> },
      { path: 'restaurant/growth/posts', element: <Navigate to="/admin/restaurant/growth-center/posts" replace /> },
      { path: 'restaurant/growth/customers', element: <Navigate to="/admin/restaurant/growth-center/customers" replace /> },
      { path: 'restaurant/growth/campaigns', element: <Navigate to="/admin/restaurant/growth-center/campaigns" replace /> },
      { path: 'restaurant/growth/discounts', element: <Navigate to="/admin/restaurant/growth-center/discounts" replace /> },
      { path: 'restaurant/growth/reviews', element: <Navigate to="/admin/restaurant/growth-center/reviews" replace /> },
      { path: 'restaurant/growth/integrations', element: <Navigate to="/admin/restaurant/growth-center/integrations" replace /> },
      { path: 'restaurant/growth/reports', element: <Navigate to="/admin/restaurant/growth-center/reports" replace /> },
      { path: 'restaurant/growth/settings', element: <Navigate to="/admin/restaurant/growth-center/ai-settings" replace /> },
      {
        path: 'restaurant/*',
        element: <RestaurantSectionAdmin><RestaurantPage /></RestaurantSectionAdmin>,
      },
      {
        path: 'channel-manager',
        element: <AccommodationOnlyAdmin><ChannelManagerPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'analytics',
        element: <AnalyticsLayout />,
        children: [
          { index: true, element: <AnalyticsHighlightsPage /> },
          { path: 'real-time', element: <AnalyticsRealTimePage /> },
          { path: 'traffic', element: <AnalyticsTrafficPage /> },
          { path: 'marketing-seo', element: <AnalyticsMarketingSeoPage /> },
        ],
      },
      {
        path: 'analytics-legacy',
        element: <AnalyticsPage />,
      },
      {
        path: 'monitoring',
        element: <MonitoringPage />,
      },
      {
        path: 'subscription',
        element: <SubscriptionPage />,
      },
      {
        path: 'support',
        element: <SupportPage />,
      },
      {
        path: 'account',
        element: <AccountPage />,
      },
      {
        path: 'settings',
        element: <SettingsPage />,
      },
      {
        path: 'settings/site-config',
        element: <SiteConfigPage />,
      },
      {
        path: 'settings/languages',
        element: <LanguagesPage />,
      },
      {
        path: 'settings/facilities',
        element: <FacilitiesPage />,
      },
      {
        path: 'settings/activities',
        element: <ActivitiesPage />,
      },
      {
        path: 'settings/tourist-attractions',
        element: <TouristAttractionsPage />,
      },
      {
        path: 'settings/partners',
        element: <PartnersPage />,
      },
      {
        path: 'settings/events',
        element: <EventsPage />,
      },
      {
        path: 'settings/business-email',
        element: <BusinessEmailPage />,
      },
      {
        path: 'settings/chat',
        element: <ChatPage />,
      },
      {
        path: 'settings/domain',
        element: <DomainPage />,
      },
      {
        path: 'settings/legal-entity',
        element: <LegalEntityPage />,
      },
      {
        path: 'settings/social-media',
        element: <SocialMediaPage />,
      },
      {
        path: 'settings/chat-widget',
        element: <ChatWidgetPage />,
      },
      {
        path: 'settings/mailgun',
        element: <MailgunPage />,
      },
      {
        path: 'settings/prices',
        element: <PricesPage />,
      },
      {
        path: 'settings/saved-replies',
        element: <SavedRepliesPage />,
      },
      {
        path: 'settings/tracking',
        element: <TrackingSettingsPage />,
      },
      {
        path: 'settings/integrations',
        element: <IntegrationsHubPage />,
      },
      {
        path: 'settings/integrations/facebook',
        element: <FacebookIntegrationPage />,
      },
      {
        path: 'settings/integrations/anaf',
        element: <AnafIntegrationPage />,
      },
      {
        path: 'integrations/payment-logs',
        element: <PaymentLogsPage />,
      },
      // Backward-compat: old ANAF + Facebook callback paths redirect to the new hub.
      {
        path: 'integrations/anaf',
        element: <Navigate to="/admin/settings/integrations/anaf" replace />,
      },
      {
        path: 'integrations',
        element: <Navigate to="/admin/settings/integrations" replace />,
      },
      {
        path: 'invoices/incoming',
        element: <IncomingInvoicesPage />,
      },
      {
        path: 'invoices/incoming/:invoiceId',
        element: <IncomingInvoiceDetailPage />,
      },
      {
        path: 'invoices/suppliers',
        element: <SuppliersPage />,
      },
      {
        path: 'settings/notifications',
        element: <AdminNotificationsPage />,
      },
      {
        path: 'onboarding',
        element: <OnboardingWizardPage />,
      },
      {
        path: 'booking-autopilot',
        element: <AccommodationOnlyAdmin><BookingAutopilotPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'smart-lock',
        element: <AccommodationOnlyAdmin><SmartLockPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'housekeepers/:housekeeperId',
        element: <AccommodationOnlyAdmin><HousekeeperProfilePage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'welcome',
        element: <AccommodationOnlyAdmin><WelcomeAdminPage /></AccommodationOnlyAdmin>,
      },
      {
        path: 'google-hotels',
        element: <AccommodationOnlyAdmin><GoogleHotelsPage /></AccommodationOnlyAdmin>,
      },
    ],
  },
  {
    path: '/housekeeper',
    element: (
      <ProtectedRoute requireRole="housekeeper">
        <HousekeeperLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: <HousekeeperTasksPage /> },
      { path: 'calendar', element: <HousekeeperCalendarPage /> },
      { path: 'history', element: <HousekeeperHistoryPage /> },
    ],
  },
  {
    path: '/super-admin',
    element: (
      <ProtectedRoute requireRole="super_admin">
        <SuperAdminLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <SuperAdminDashboardPage />,
      },
      {
        path: 'users',
        element: <SuperAdminUsersPage />,
      },
      {
        path: 'tenants',
        element: <SuperAdminTenantsPage />,
      },
      {
        path: 'subscription-plans',
        element: <Navigate to="/super-admin/plan-catalog" replace />,
      },
      {
        path: 'plan-catalog',
        element: <SuperAdminPlanCatalogPage />,
      },
      {
        path: 'addon-packages',
        element: <SuperAdminAddOnPackagesPage />,
      },
      {
        path: 'billing-report',
        element: <SuperAdminBillingReportPage />,
      },
      {
        path: 'restaurant-orders',
        element: <SuperAdminRestaurantOrdersSettingsPage />,
      },
      {
        path: 'tenants/:tenantId/staff',
        element: <SuperAdminTenantStaffPage />,
      },
      {
        path: 'platform-sms-templates',
        element: <SuperAdminPlatformSmsTemplatesPage />,
      },
      {
        path: 'platform-contact',
        element: <SuperAdminPlatformContactPage />,
      },
      {
        path: 'marketplace-branding',
        element: <SuperAdminMarketplaceBrandingPage />,
      },
      {
        path: 'marketplace-benefits',
        element: <SuperAdminMarketplaceBenefitsPage />,
      },
      {
        path: 'system',
        element: <SuperAdminSystemPage />,
      },
      { path: 'analytics', element: <SuperAdminAnalyticsPage /> },
      { path: 'visitor-analytics', element: <SuperAdminVisitorAnalyticsPage /> },
      { path: 'cost-dashboard', element: <SuperAdminCostDashboardPage /> },
      { path: 'seo-demo/:slug', element: <SuperAdminSeoDemoPage /> },
      { path: 'blog', element: <SuperAdminBlogPage /> },
      { path: 'marketing', element: <SuperAdminMarketingHubPage /> },
      { path: 'visibility-features', element: <SuperAdminVisibilityFeaturesPage /> },
      { path: 'lead-marketing', element: <SuperAdminLeadMarketingPage /> },
      { path: 'lead-templates', element: <SuperAdminLeadTemplatesPage /> },
      { path: 'lead-campaigns', element: <SuperAdminLeadCampaignsPage /> },
      { path: 'global-suppliers', element: <SuperAdminGlobalSuppliersPage /> },
      { path: 'global-taxonomy', element: <SuperAdminGlobalTaxonomyPage /> },
      { path: 'global-rules', element: <SuperAdminGlobalRulesPage /> },
      { path: 'global-suggestions', element: <SuperAdminGlobalSuggestionsPage /> },
      { path: 'docs-screenshots', element: <SuperAdminDocsScreenshotsPage /> },
      {
        path: 'tutorials/photography',
        element: <SuperAdminTutorialPhotographyAssetsPage />,
      },
      { path: 'monitoring', element: <Navigate to="/super-admin" replace /> },
      {
        path: 'translations',
        element: <SuperAdminTranslationsPage />,
      },
      {
        path: 'languages',
        element: <SuperAdminLanguagesPage />,
      },
      {
        path: 'dns',
        element: <SuperAdminDNSPage />,
      },
      {
        path: 'integrations',
        element: <SuperAdminIntegrationsPage />,
      },
      {
        path: 'integrations/anaf',
        element: <SuperAdminAnafConfigPage />,
      },
      {
        path: 'limits',
        element: <SuperAdminLimitsPage />,
      },
      {
        path: 'pricing',
        element: <SuperAdminPricingPage />,
      },
      {
        path: 'sales',
        element: <SuperAdminSalesPage />,
      },
      {
        path: 'demo',
        element: <SuperAdminDemoPage />,
      },
      {
        path: 'ecosystem',
        element: <SuperAdminEcosystemPage />,
      },
      {
        path: 'demo-requests',
        element: <SuperAdminDemoRequestsPage />,
      },
      {
        path: 'demo-builder',
        element: <SuperAdminDemoBuilderPage />,
      },
      {
        path: 'demo-tenants',
        element: <SuperAdminDemoTenantListPage />,
      },
      {
        path: 'support',
        element: <SuperAdminSupportPage />,
      },
      {
        path: 'sms',
        element: <SuperAdminSmsPage />,
      },
      {
        path: 'mailgun',
        element: <SuperAdminMailgunPage />,
      },
      {
        path: 'configurations',
        element: <SuperAdminConfigurationsPage />,
      },
      {
        path: 'stripe',
        element: <SuperAdminStripePage />,
      },
      {
        path: 'onboarding-welcome',
        element: <SuperAdminOnboardingWelcomePage />,
      },
      {
        path: 'notifications-settings',
        element: <SuperAdminNotificationsSettingsPage />,
      },
      {
        path: 'sales-codes',
        element: <SuperAdminSalesCodesPage />,
      },
      {
        path: 'architecture',
        element: <SuperAdminArchitecturePage />,
      },
    ],
  },
    ],
  },
])

export default function AppRouter() {
  return (
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  )
}

