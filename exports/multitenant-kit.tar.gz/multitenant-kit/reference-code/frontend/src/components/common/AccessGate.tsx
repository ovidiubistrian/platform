/**
 * Billing access gate for tenant admin.
 *
 * Polls /api/subscriptions/access-status on mount. Three outcomes:
 *   - "allowed"            → render children normally (99% of the time).
 *   - "payment_required"   → render children, but redirect once to
 *                            /admin/subscription so the banner is visible.
 *   - "blocked"            → render a full-screen lock interstitial; only
 *                            logout is possible.
 *
 * When enforce=false (feature flag off in backend), access is always
 * "allowed" and this component is a no-op.
 */
import { useEffect, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Lock, LogOut } from 'lucide-react'
import { subscriptionsApi, type AccessStatus } from '@/lib/api/subscriptions'
import { useAuth } from '@/context/AuthContext'

const ALLOW_WHEN_PAYMENT_REQUIRED = [
  '/admin/subscription',
  '/admin/account',
  '/admin/support',
  '/admin/settings',
]

export default function AccessGate({ children }: { children: React.ReactNode }) {
  const [snapshot, setSnapshot] = useState<AccessStatus | null>(null)
  const [loaded, setLoaded] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useAuth()

  useEffect(() => {
    // Super-admin + restaurant staff (waiter/cook) bypass the billing
    // gate — they're ops accounts, not tenants with billing.
    if (!user || user.role === 'super_admin' || user.role === 'waiter' || user.role === 'cook') {
      setLoaded(true)
      return
    }
    let cancelled = false
    subscriptionsApi
      .getAccessStatus()
      .then((snap) => {
        if (cancelled) return
        setSnapshot(snap)
      })
      .finally(() => {
        if (!cancelled) setLoaded(true)
      })
    return () => {
      cancelled = true
    }
  }, [user?.id])

  useEffect(() => {
    if (!snapshot) return
    if (snapshot.access === 'payment_required' && snapshot.enforce) {
      const path = location.pathname || ''
      const allowed = ALLOW_WHEN_PAYMENT_REQUIRED.some((p) => path === p || path.startsWith(p + '/'))
      if (!allowed) {
        navigate('/admin/subscription', { replace: true })
      }
    }
  }, [snapshot?.access, snapshot?.enforce, location.pathname])

  if (!loaded) return <>{children}</>

  // Super-admin / no snapshot / flag off → transparent.
  if (!snapshot || !snapshot.enforce || snapshot.access === 'allowed') {
    return <>{children}</>
  }

  if (snapshot.access === 'blocked') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
        <div className="max-w-md w-full bg-white rounded-xl shadow-lg p-8 text-center">
          <div className="mx-auto w-14 h-14 rounded-full bg-red-100 flex items-center justify-center mb-4">
            <Lock className="h-7 w-7 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Acces blocat</h1>
          <p className="text-gray-600 mb-1">
            {snapshot.reason || 'Contul tău este blocat.'}
          </p>
          <p className="text-sm text-gray-500 mb-6">
            Contactează suportul pentru deblocare.
          </p>
          <button
            onClick={async () => {
              await logout()
              navigate('/auth/login')
            }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-50 text-sm font-medium"
          >
            <LogOut className="h-4 w-4" />
            Deconectare
          </button>
        </div>
      </div>
    )
  }

  // payment_required: render subscription page (redirect handled above)
  return <>{children}</>
}
