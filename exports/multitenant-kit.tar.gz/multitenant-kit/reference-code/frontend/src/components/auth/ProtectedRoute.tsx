/**
 * Protected Route Component
 * Wraps routes that require authentication
 */
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { useMemo } from 'react'

interface ProtectedRouteProps {
  children: React.ReactNode
  requireRole?: 'admin' | 'super_admin' | 'user' | 'housekeeper' | 'sales'
  redirectTo?: string
}

export default function ProtectedRoute({
  children,
  requireRole,
  redirectTo = '/auth/login'
}: ProtectedRouteProps) {
  const { user, loading } = useAuth()
  const location = useLocation()

  // Memoize redirect state to prevent unnecessary re-renders
  const redirectState = useMemo(() => ({ from: location }), [location.pathname])

  // Show loading state while checking auth
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  // Redirect to login if not authenticated
  if (!user) {
    return <Navigate to={redirectTo} state={redirectState} replace />
  }

  // Check role requirement
  if (requireRole) {
    // Get user role from user object
    const userRole = (user as any)?.role?.toLowerCase() || (user as any)?.userRole?.toLowerCase() || 'user'
    const requiredRole = requireRole.toLowerCase()

    // Super admin can access everything
    if (userRole === 'super_admin' || userRole === 'superadmin') {
      return <>{children}</>
    }

    // Admin can access admin routes (including tenant_admin). Restaurant
    // staff (waiter / cook) also enter via /admin/* because their pages
    // (POS, KDS) live under AdminLayout; AdminLayout itself scopes them
    // to a single page.
    if (requiredRole === 'admin' && (
      userRole === 'admin' ||
      userRole === 'tenant_admin' ||
      userRole === 'super_admin' ||
      userRole === 'superadmin' ||
      userRole === 'waiter' ||
      userRole === 'cook'
    )) {
      return <>{children}</>
    }

    // User can access user routes
    if (requiredRole === 'user' && (userRole === 'user' || userRole === 'admin' || userRole === 'super_admin' || userRole === 'superadmin')) {
      return <>{children}</>
    }

    // Housekeeper can access /housekeeper routes; tenant_admin + super_admin
    // are allowed in for debugging/support.
    if (requiredRole === 'housekeeper' && (userRole === 'housekeeper' || userRole === 'admin' || userRole === 'tenant_admin' || userRole === 'super_admin' || userRole === 'superadmin')) {
      return <>{children}</>
    }

    // Sales can access /sales routes; super_admin has access everywhere (handled above).
    if (requiredRole === 'sales' && userRole === 'sales') {
      return <>{children}</>
    }

    // Role mismatch - redirect to appropriate dashboard
    if (userRole === 'housekeeper') {
      return <Navigate to="/housekeeper" replace />
    }
    if (userRole === 'waiter') {
      return <Navigate to="/admin/restaurant/pos" replace />
    }
    if (userRole === 'cook') {
      return <Navigate to="/admin/restaurant/kds" replace />
    }
    if (userRole === 'admin' || userRole === 'tenant_admin') {
      return <Navigate to="/admin" replace />
    }
    if (userRole === 'super_admin' || userRole === 'superadmin') {
      return <Navigate to="/super-admin" replace />
    }
    return <Navigate to="/" replace />
  }

  // User is authenticated and role check passed
  return <>{children}</>
}

