/**
 * Super Admin Layout component.
 * Matches: app/super-admin/layout.tsx
 */
import { ReactNode } from 'react'
import { Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { useEffect } from 'react'
import SuperAdminSidebar from './SuperAdminSidebar'
import NotificationBell from '../common/NotificationBell'

interface SuperAdminLayoutProps {
  children?: ReactNode
}

export default function SuperAdminLayout({ children }: SuperAdminLayoutProps) {
  const { user, loading } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth/login?redirect=/super-admin')
    } else if (!loading && user && user.role !== 'super_admin') {
      navigate('/')
    }
  }, [user, loading, navigate])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <SuperAdminSidebar />
      <div className="fixed top-3 right-4 z-40">
        <div className="rounded-full bg-white shadow ring-1 ring-gray-200">
          <NotificationBell />
        </div>
      </div>
      {/* Main content */}
      <div className="lg:pl-64 transition-all duration-300">
        {children || <Outlet />}
      </div>
    </div>
  )
}













