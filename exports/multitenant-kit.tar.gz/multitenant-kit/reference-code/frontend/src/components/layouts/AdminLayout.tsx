/**
 * Admin Layout component.
 * Matches: app/admin/layout.tsx
 * Vizitatorii (user, sales) pot accesa doar /admin/restaurant, cu tab-uri limitate (Meniu, Mese, Rezervări).
 */
import { ReactNode, useEffect, useMemo } from 'react'
import { Outlet, useNavigate, useLocation, Link, Navigate } from 'react-router-dom'
import { MessageCircle, Sparkles } from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import BookingNotifier from '../common/BookingNotifier'
import AccessGate from '../common/AccessGate'
import RestaurantAlertBanner from '../restaurant/RestaurantAlertBanner'
import PlanLimitUpsellModal from '../admin/PlanLimitUpsellModal'
import { onboardingApi } from '@/lib/api/onboarding'

interface AdminLayoutProps {
  children?: ReactNode
}

const ADMIN_ROLES = ['tenant_admin', 'admin', 'super_admin', 'superadmin']
const VISITOR_ROLES = ['user', 'sales', 'visitor']
// Staff roles are scoped to a single screen: waiters only hit the POS,
// cooks only hit the KDS. They're allowed inside AdminLayout but the
// individual pages must check and redirect as appropriate.
const RESTAURANT_STAFF_ROLES = ['waiter', 'cook']

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { user, loading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()

  // Memoize user role to prevent unnecessary re-renders
  const userRole = useMemo(() => user?.role?.toLowerCase(), [user?.role])
  const isAdmin = useMemo(() => ADMIN_ROLES.includes(userRole || ''), [userRole])
  const isVisitor = useMemo(() => VISITOR_ROLES.includes(userRole || ''), [userRole])
  const isRestaurantStaff = useMemo(() => RESTAURANT_STAFF_ROLES.includes(userRole || ''), [userRole])
  const isRestaurantRoute = useMemo(() => (location.pathname || '').includes('/admin/restaurant'), [location.pathname])
  const isOnboardingRoute = useMemo(() => (location.pathname || '').startsWith('/admin/onboarding'), [location.pathname])

  // Detect "embedded in onboarding wizard iframe" mode. Set once on mount
  // based on the initial URL; the class persists across internal navigations
  // so AdminHeader keeps hiding itself even if the user clicks inside the
  // iframe and lands on a sub-page without the query param.
  const isEmbedded = useMemo(() => {
    if (typeof window === 'undefined') return false
    return new URLSearchParams(window.location.search).get('embedded') === '1'
  }, [])

  useEffect(() => {
    if (typeof document === 'undefined') return
    if (isEmbedded) {
      document.body.classList.add('onboarding-embedded')
    }
  }, [isEmbedded])

  // Only auto-redirect brand-new tenants (step === 0, nothing touched) to the
  // wizard. Tenants who have started and skipped/paused get the resume card on
  // the dashboard instead — no hijacking their navigation.
  useEffect(() => {
    // Restaurant staff never see the onboarding wizard — it's a tenant-
    // admin thing and would hijack their route to the POS/KDS.
    if (loading || !user || !isAdmin || isOnboardingRoute || isEmbedded || isRestaurantStaff) return
    let cancelled = false
    onboardingApi
      .getStatus()
      .then((s) => {
        if (cancelled) return
        if (!s.completed && (s.step || 0) === 0) {
          navigate('/admin/onboarding', { replace: true })
        }
      })
      .catch(() => {})
    return () => { cancelled = true }
  }, [user?.id, loading, isAdmin, isOnboardingRoute, isEmbedded, isRestaurantStaff, navigate])

  useEffect(() => {
    // Only redirect if we're sure about the auth state
    if (loading) return

    if (!user) {
      navigate('/auth/login?redirect=/admin', { replace: true })
      return
    }

    // Admin: acces complet
    if (isAdmin) return

    // Vizitator: acces doar la restaurant
    if (isVisitor && isRestaurantRoute) return

    // Housekeeper: send to their own UI.
    if (userRole === 'housekeeper') {
      navigate('/housekeeper', { replace: true })
      return
    }

    // Restaurant staff: waiter → POS only, cook → KDS only. Any other
    // admin route is forbidden; we redirect them to their home screen.
    if (isRestaurantStaff) {
      const path = location.pathname || ''
      if (userRole === 'waiter') {
        const allowed =
          path.startsWith('/admin/restaurant/pos') ||
          path.startsWith('/admin/restaurant/kds') ||
          path === '/admin/account'
        if (!allowed) {
          navigate('/admin/restaurant/pos', { replace: true })
        }
        return
      }
      if (userRole === 'cook') {
        const allowed =
          path.startsWith('/admin/restaurant/kds') || path === '/admin/account'
        if (!allowed) {
          navigate('/admin/restaurant/kds', { replace: true })
        }
        return
      }
    }

    // Altfel: redirect
    if (!isAdmin) {
      navigate('/', { replace: true })
      return
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, loading, userRole, isRestaurantRoute])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-gray-600">Se încarcă...</div>
      </div>
    )
  }

  // Force the temp-password change before any admin access (demo→client convert).
  if (user.must_change_password) {
    return <Navigate to="/auth/change-password" replace />
  }

  // Don't render if user doesn't have access: admin OR (visitor on restaurant route)
  // OR restaurant staff on their allowed pages.
  const hasAccess = isAdmin || (isVisitor && isRestaurantRoute) || isRestaurantStaff
  if (!user || !hasAccess) return null

  const isSupportPage = location.pathname.startsWith('/admin/support')
  // Hide the floating "Ajutor AI" CTA on POS + KDS — both are operational
  // screens (waiter / kitchen) where the bubble covers active controls.
  const isOperationalScreen = location.pathname.startsWith('/admin/restaurant/pos')
    || location.pathname.startsWith('/admin/restaurant/kds')

  return (
    <div className="min-h-screen bg-gray-100">
      <AccessGate>{children || <Outlet />}</AccessGate>
      <PlanLimitUpsellModal />
      <BookingNotifier />
      {isRestaurantRoute && <RestaurantAlertBanner />}
      {isAdmin && !isSupportPage && !isOperationalScreen && !isEmbedded && (
        <Link
          to="/admin/support"
          className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-indigo-600 pl-4 pr-5 py-3 text-white shadow-lg transition-all hover:scale-105 hover:bg-indigo-700 hover:shadow-xl"
          title="Cere ajutor AI"
        >
          <div className="relative">
            <MessageCircle className="h-5 w-5" />
            <Sparkles className="absolute -top-1.5 -right-1.5 h-3 w-3 text-amber-300" />
          </div>
          <span className="text-sm font-semibold">Ajutor AI</span>
        </Link>
      )}
    </div>
  )
}

