/**
 * Authentication context for React.
 * Matches functionality from NextAuth useSession
 */
import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react'
import { authApi } from '@/lib/api/auth'
import type { User, RegisterData } from '@/types/auth'

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<User | { requiresTwoFactor: true; sessionId: string }>
  logout: () => Promise<void>
  register: (data: RegisterData) => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

// Persist across Strict Mode double-mount so we don't flash loading twice
let authInitialCheckDone = false

interface AuthProviderProps {
  children: ReactNode
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(() => !authInitialCheckDone)

  const refreshUser = useCallback(async () => {
    const token = localStorage.getItem('access_token')
    if (token) {
      try {
        const currentUser = await authApi.getCurrentUser()
        setUser(currentUser)
        // Persist tenant_id for API client tracing header (x-tenant-id)
        if (currentUser?.role === 'super_admin') {
          localStorage.setItem('tenant_id', 'super_admin')
        } else if (currentUser?.tenant_id) {
          localStorage.setItem('tenant_id', currentUser.tenant_id)
        } else {
          localStorage.removeItem('tenant_id')
        }
      } catch (error) {
        console.error('Error fetching current user:', error)
        localStorage.removeItem('access_token')
        localStorage.removeItem('tenant_id')
        setUser(null)
      }
    } else {
      localStorage.removeItem('tenant_id')
      setUser(null)
    }
  }, [])

  useEffect(() => {
    if (authInitialCheckDone) return
    const checkAuth = async () => {
      try {
        await refreshUser()
      } catch (error) {
        console.error('Error in checkAuth:', error)
      } finally {
        authInitialCheckDone = true
        setLoading(false)
      }
    }
    checkAuth()
  }, [refreshUser])

  const login = useCallback(async (email: string, password: string) => {
    const response = await authApi.login({ email, password })
    // 2FA required: return full response so LoginPage can redirect
    if (response && 'requiresTwoFactor' in response && response.requiresTwoFactor) {
      return response as { requiresTwoFactor: true; sessionId: string }
    }
    const tokenResponse = response as { user: User }
    setUser(tokenResponse.user)
    if (tokenResponse.user?.role === 'super_admin') {
      localStorage.setItem('tenant_id', 'super_admin')
    } else if (tokenResponse.user?.tenant_id) {
      localStorage.setItem('tenant_id', tokenResponse.user.tenant_id)
    } else {
      localStorage.removeItem('tenant_id')
    }
    return tokenResponse.user
  }, [])

  const logout = useCallback(async () => {
    await authApi.logout()
    localStorage.removeItem('tenant_id')
    setUser(null)
  }, [])

  const register = useCallback(async (data: RegisterData) => {
    await authApi.register(data)
    // Don't auto-login after registration
  }, [])

  // Memoize the context value to prevent unnecessary re-renders
  const value = useMemo(
    () => ({
      user,
      loading,
      login,
      logout,
      register,
      refreshUser,
    }),
    [user, loading, login, logout, register, refreshUser]
  )

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

