/**
 * Subscriptions API client.
 */
import apiClient from './client'

export interface SubscriptionPlan {
  id: string
  name: string
  description?: string | null
  monthlyPrice: number
  yearlyPrice: number
  currency: string
  maxProperties: number
  maxUnits: number
  maxBookings: number
  features?: string | null
  benefits?: string | null
  isActive: boolean
  includesOnsiteOnboard?: boolean
  includes24hSupport?: boolean
  trialMonths?: number
  stripeMonthlyPriceId?: string | null
  stripeYearlyPriceId?: string | null
  createdAt?: string
  updatedAt?: string
}

export interface CurrentSubscription {
  id: string
  status: string
  plan: SubscriptionPlan
  currentPeriodEnd: string
  trialEnd?: string
  freePlanUsedAt?: string | null
}

export interface TrialStatus {
  tenant: {
    id: string
    name: string
    status: string
    subscriptionPlan: string
  }
  trial: {
    endDate?: string
    daysRemaining: number
    isExpired: boolean
    isExpiringSoon: boolean
    isActive: boolean
  }
}

export const subscriptionsApi = {
  /**
   * Normalize plan from API (backend may send camelCase or snake_case).
   */
  _normalizePlan: (p: Record<string, unknown>): SubscriptionPlan => ({
    id: String(p.id ?? ''),
    name: String(p.name ?? ''),
    description: (p.description as string) ?? null,
    monthlyPrice: Number(p.monthlyPrice ?? p.monthly_price ?? 0),
    yearlyPrice: Number(p.yearlyPrice ?? p.yearly_price ?? 0),
    currency: String(p.currency ?? 'RON'),
    maxProperties: Number(p.maxProperties ?? p.max_properties ?? 1),
    maxUnits: Number(p.maxUnits ?? p.max_units ?? 5),
    maxBookings: Number(p.maxBookings ?? p.max_bookings ?? 100),
    features: (p.features as string) ?? null,
    benefits: (p.benefits as string) ?? null,
    isActive: Boolean(p.isActive ?? p.is_active ?? true),
    includesOnsiteOnboard: Boolean(p.includesOnsiteOnboard ?? p.includes_onsite_onboard ?? false),
    includes24hSupport: Boolean(p.includes24hSupport ?? p.includes_24h_support ?? false),
    trialMonths: Number(p.trialMonths ?? p.trial_months ?? 0),
    stripeMonthlyPriceId: (p.stripeMonthlyPriceId ?? p.stripe_monthly_price_id) as string ?? null,
    stripeYearlyPriceId: (p.stripeYearlyPriceId ?? p.stripe_yearly_price_id) as string ?? null,
    createdAt: (p.createdAt ?? p.created_at) as string | undefined,
    updatedAt: (p.updatedAt ?? p.updated_at) as string | undefined,
  }),

  /**
   * Get all subscription plans. Always returns an array (empty on error or non-JSON response).
   * Plans are normalized to camelCase for admin and homepage.
   */
  getPlans: async (): Promise<SubscriptionPlan[]> => {
    // Source of truth = /api/plan-catalog (the new homepage catalog).
    // We map plan_catalog rows -> SubscriptionPlan shape so the existing
    // /admin/subscription UI keeps working without rewrite.
    try {
      const response = await apiClient.get<any>('/api/plan-catalog')
      const data = response?.data
      let list: any[] = []
      if (Array.isArray(data)) list = data
      else if (Array.isArray(data?.plans)) list = data.plans
      return list
        .filter((p) => p && typeof p === 'object')
        .map((p) => {
          const limits = (p.limits || {}) as Record<string, unknown>
          const maxUnits = typeof limits.maxUnits === 'number'
            ? (limits.maxUnits as number)
            : Number(limits.maxUnits) || 0
          const maxProperties = typeof limits.includedProperties === 'number'
            ? (limits.includedProperties as number)
            : Number(limits.includedProperties) || 1
          return {
            id: String(p.id ?? ''),
            name: String(p.name ?? ''),
            description: (p.short_description ?? p.long_description ?? null) as string | null,
            monthlyPrice: Number(p.monthly_price ?? p.monthlyPrice ?? 0),
            yearlyPrice: Number(p.annual_price ?? p.yearlyPrice ?? 0),
            currency: String(p.currency ?? 'RON'),
            maxProperties,
            maxUnits,
            maxBookings: 0,
            features: Array.isArray(p.features)
              ? JSON.stringify(p.features.map((f: any) => f?.label).filter(Boolean))
              : null,
            benefits: null,
            isActive: Boolean(p.is_active ?? p.isActive ?? true),
            includesOnsiteOnboard: false,
            includes24hSupport: false,
            trialMonths: 0,
            stripeMonthlyPriceId: null,
            stripeYearlyPriceId: null,
            createdAt: p.created_at ?? p.createdAt,
            updatedAt: p.updated_at ?? p.updatedAt,
          } as SubscriptionPlan
        })
    } catch {
      return []
    }
  },

  /**
   * Get current subscription.
   */
  getCurrent: async (): Promise<CurrentSubscription | null> => {
    try {
      const response = await apiClient.get<CurrentSubscription | null>('/api/subscriptions')
      return response.data ?? null
    } catch (error: any) {
      if (error.response?.status === 404) {
        return null
      }
      throw error
    }
  },

  /**
   * Subscribe to a plan.
   */
  subscribe: async (planId: string, billingInterval: 'monthly' | 'yearly'): Promise<any> => {
    const response = await apiClient.post('/api/subscriptions', {
      planId,
      billingInterval
    })
    return response.data
  },

  /**
   * Cancel subscription.
   */
  cancel: async (): Promise<void> => {
    await apiClient.post('/api/subscriptions/cancel')
  },

  /**
   * Update subscription.
   */
  update: async (planId: string): Promise<void> => {
    await apiClient.patch('/api/subscriptions', { planId })
  },

  // Super Admin methods
  /**
   * Get all subscription plans (super admin only). Normalized to camelCase.
   */
  getAllPlansAdmin: async (): Promise<SubscriptionPlan[]> => {
    const response = await apiClient.get<unknown[]>('/api/super-admin/subscription-plans')
    const list = Array.isArray(response.data) ? response.data : []
    return list
      .filter((p): p is Record<string, unknown> => p != null && typeof p === 'object')
      .map((p) => subscriptionsApi._normalizePlan(p))
  },

  /**
   * Create a subscription plan (super admin only).
   */
  createPlan: async (data: {
    name: string
    description?: string
    monthlyPrice: number
    yearlyPrice: number
    currency?: string
    maxProperties: number
    maxUnits: number
    maxBookings: number
    features?: string
    benefits?: string
    isActive?: boolean
    includesOnsiteOnboard?: boolean
    includes24hSupport?: boolean
    trialMonths?: number
    stripeMonthlyPriceId?: string
    stripeYearlyPriceId?: string
  }): Promise<SubscriptionPlan> => {
    const response = await apiClient.post<SubscriptionPlan>('/api/super-admin/subscription-plans', data)
    return response.data
  },

  /**
   * Update a subscription plan (super admin only).
   */
  updatePlan: async (id: string, data: Partial<SubscriptionPlan>): Promise<SubscriptionPlan> => {
    const response = await apiClient.put<SubscriptionPlan>(`/api/super-admin/subscription-plans/${id}`, data)
    return response.data
  },

  /**
   * Delete a subscription plan (super admin only).
   */
  deletePlan: async (id: string): Promise<void> => {
    await apiClient.delete(`/api/super-admin/subscription-plans/${id}`)
  },

  /**
   * List active add-on packages the tenant can see (SMS, email, business email).
   */
  getAddOns: async (): Promise<AddOnPackage[]> => {
    try {
      const response = await apiClient.get<AddOnPackage[]>('/api/subscriptions/addons')
      return Array.isArray(response.data) ? response.data : []
    } catch {
      return []
    }
  },

  /**
   * List the tenant's own add-on assignments (all types).
   */
  getMyAddOns: async (): Promise<TenantAddOnAssignment[]> => {
    try {
      const response = await apiClient.get<TenantAddOnAssignment[]>('/api/subscriptions/addons/mine')
      return Array.isArray(response.data) ? response.data : []
    } catch {
      return []
    }
  },

  /**
   * Start checkout for an add-on package. If Stripe is configured with a
   * price_id, returns a Stripe Checkout URL. Otherwise the backend grants
   * the add-on directly (dev path) and returns url=null.
   */
  buyAddOn: async (addonPackageId: string): Promise<{ url: string | null; addonId?: string }> => {
    const response = await apiClient.post<{ url: string | null; addonId?: string }>(
      '/api/subscriptions/addons/checkout',
      { addonPackageId },
    )
    return response.data
  },

  /** Current tenant access gate snapshot (allowed / payment_required / blocked). */
  getAccessStatus: async (): Promise<AccessStatus | null> => {
    try {
      const response = await apiClient.get<AccessStatus>('/api/subscriptions/access-status')
      return response.data ?? null
    } catch {
      return null
    }
  },

  /** Increment the post-expiry postpone counter. 400 if not expired / counter maxed. */
  postponePayment: async (): Promise<AccessStatus> => {
    const response = await apiClient.post<AccessStatus>('/api/subscriptions/postpone')
    return response.data
  },

  /** Create a payment-extension request (one-month delay). 409 if one pending exists. */
  requestExtension: async (reason?: string): Promise<{ id: string; status: string; requestedDays: number; reason: string | null; requestedAt: string | null }> => {
    const response = await apiClient.post('/api/subscriptions/extension-request', { reason: reason ?? '' })
    return response.data
  },
}

export interface AccessStatus {
  access: 'allowed' | 'payment_required' | 'blocked'
  reason: string | null
  tenantStatus: string
  subscriptionPlan: string | null
  subscriptionEndsAt: string | null
  daysRemaining: number
  isExpired: boolean
  loginPostExpiryCount: number
  maxPostpones: number
  pendingExtensionId: string | null
  pendingExtensionRequestedAt: string | null
  enforce: boolean
}

export type AddOnType = 'sms_pack' | 'email_pack' | 'business_email'
export type AddOnBillingCycle = 'one_time' | 'monthly'

export interface AddOnPackage {
  id: string
  type: AddOnType
  name: string
  description?: string | null
  price: number
  currency: string
  billingCycle: AddOnBillingCycle
  quantity: number | null
  sortOrder?: number
}

export interface TenantAddOnAssignment {
  id: string
  addonPackageId: string
  packageName: string
  packageType: AddOnType
  packageQuantity: number | null
  price: number
  currency: string
  billingCycle: AddOnBillingCycle
  status: 'pending' | 'active' | 'cancelled' | 'expired'
  smsRemaining: number | null
  emailRemaining: number | null
  activatedAt: string | null
  expiresAt: string | null
  createdAt: string | null
}













