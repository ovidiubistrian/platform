/**
 * Plan catalog API client (super-admin CRUD + public listing).
 *
 * The catalog is the marketing tier list rendered in the homepage
 * carousel. Distinct from `subscriptions` (Stripe-billed plans).
 */
import apiClient from './client'

export interface PlanCatalogFeature {
  id?: string
  plan_id?: string
  label: string
  description?: string | null
  category?: string | null
  is_included?: boolean
  sort_order?: number
}

export interface PlanCatalogLimits {
  includedProperties?: number
  maxUnits?: number
  maxRooms?: number
  maxLocations?: number
  maxMenuProducts?: number
  maxOrdersPerMonth?: number
  maxTables?: number
  directBookingsLimit?: string | number
  restaurantBookingsLimit?: string | number
  adminUsers?: number
  includedLanguages?: string | number
  includedSmsPerMonth?: number
  growthCenterPostsPerMonth?: number
  supportLevel?: string
  onboardingType?: string
  [key: string]: any
}

export interface PlanCatalogPlan {
  id: string
  slug: string
  name: string
  short_description?: string | null
  long_description?: string | null
  monthly_price: string | number
  annual_price: string | number
  annual_discount_percent: number
  price_text?: string | null
  currency: string
  category?: string | null
  target_audience?: string | null
  audience: string[]
  is_active: boolean
  is_public: boolean
  show_on_homepage: boolean
  show_in_carousel: boolean
  is_recommended: boolean
  is_founder_offer: boolean
  badge_text?: string | null
  cta_text: string
  cta_url?: string | null
  sort_order: number
  accent_color?: string | null
  icon_name?: string | null
  limits: PlanCatalogLimits
  trial_days: number
  stripe_product_id?: string | null
  stripe_monthly_price_id?: string | null
  stripe_yearly_price_id?: string | null
  stripe_synced_at?: string | null
  created_at: string
  updated_at: string
  features: PlanCatalogFeature[]
}

export interface PlanCatalogGlobalFeature {
  id: string
  label: string
  description?: string | null
  category?: string | null
  sort_order: number
  is_active: boolean
  created_at: string
}

export const planCatalogApi = {
  // -------- Public --------
  listPublic: async (params?: {
    audience?: string
    homepageOnly?: boolean
    carouselOnly?: boolean
  }): Promise<PlanCatalogPlan[]> => {
    const search = new URLSearchParams()
    if (params?.audience) search.set('audience', params.audience)
    if (params?.homepageOnly) search.set('homepage_only', 'true')
    if (params?.carouselOnly) search.set('carousel_only', 'true')
    const qs = search.toString()
    const r = await apiClient.get<PlanCatalogPlan[]>(`/api/plan-catalog${qs ? `?${qs}` : ''}`)
    return r.data ?? []
  },

  listGlobalFeatures: async (): Promise<PlanCatalogGlobalFeature[]> => {
    const r = await apiClient.get<PlanCatalogGlobalFeature[]>(`/api/plan-catalog/global`)
    return r.data ?? []
  },

  getPublicBySlug: async (slug: string): Promise<PlanCatalogPlan> => {
    const r = await apiClient.get<PlanCatalogPlan>(`/api/plan-catalog/slug/${slug}`)
    return r.data
  },

  // -------- Super-admin --------
  adminList: async (): Promise<PlanCatalogPlan[]> => {
    const r = await apiClient.get<PlanCatalogPlan[]>(`/api/plan-catalog/admin/all`)
    return r.data ?? []
  },

  adminGet: async (id: string): Promise<PlanCatalogPlan> => {
    const r = await apiClient.get<PlanCatalogPlan>(`/api/plan-catalog/admin/${id}`)
    return r.data
  },

  adminCreate: async (data: Partial<PlanCatalogPlan> & { features?: PlanCatalogFeature[] }): Promise<PlanCatalogPlan> => {
    const r = await apiClient.post<PlanCatalogPlan>(`/api/plan-catalog/admin`, data)
    return r.data
  },

  adminUpdate: async (id: string, data: Partial<PlanCatalogPlan> & { features?: PlanCatalogFeature[] }): Promise<PlanCatalogPlan> => {
    const r = await apiClient.patch<PlanCatalogPlan>(`/api/plan-catalog/admin/${id}`, data)
    return r.data
  },

  adminDelete: async (id: string): Promise<void> => {
    await apiClient.delete(`/api/plan-catalog/admin/${id}`)
  },

  adminDuplicate: async (id: string): Promise<PlanCatalogPlan> => {
    const r = await apiClient.post<PlanCatalogPlan>(`/api/plan-catalog/admin/${id}/duplicate`)
    return r.data
  },

  adminSyncStripe: async (id: string): Promise<{
    plan_id: string; slug: string;
    stripe_product_id: string;
    stripe_monthly_price_id: string | null;
    stripe_yearly_price_id: string | null;
    synced_at: string;
  }> => {
    const r = await apiClient.post(`/api/plan-catalog/admin/${id}/sync-stripe`)
    return r.data
  },

  adminSyncStripeAll: async (): Promise<{ results: any[] }> => {
    const r = await apiClient.post(`/api/plan-catalog/admin/sync-stripe-all`)
    return r.data
  },

  adminListGlobalFeatures: async (): Promise<PlanCatalogGlobalFeature[]> => {
    const r = await apiClient.get<PlanCatalogGlobalFeature[]>(`/api/plan-catalog/admin/global/all`)
    return r.data ?? []
  },

  adminCreateGlobalFeature: async (data: Partial<PlanCatalogGlobalFeature>): Promise<PlanCatalogGlobalFeature> => {
    const r = await apiClient.post<PlanCatalogGlobalFeature>(`/api/plan-catalog/admin/global`, data)
    return r.data
  },

  adminUpdateGlobalFeature: async (id: string, data: Partial<PlanCatalogGlobalFeature>): Promise<PlanCatalogGlobalFeature> => {
    const r = await apiClient.patch<PlanCatalogGlobalFeature>(`/api/plan-catalog/admin/global/${id}`, data)
    return r.data
  },

  adminDeleteGlobalFeature: async (id: string): Promise<void> => {
    await apiClient.delete(`/api/plan-catalog/admin/global/${id}`)
  },
}

export const AUDIENCE_OPTIONS: { value: string; label: string }[] = [
  { value: 'accommodation', label: 'Cazare (general)' },
  { value: 'apartment', label: 'Apartament / cabană' },
  { value: 'pension', label: 'Pensiune' },
  { value: 'restaurant', label: 'Restaurant' },
  { value: 'mixed', label: 'Mixt (cazare + restaurant)' },
  { value: 'hotel', label: 'Hotel / Complex' },
]
