/**
 * API client setup using Axios.
 * Adds x-request-id and x-tenant-id for request tracing and tenant-aware logging.
 */
import axios, { AxiosInstance, AxiosError } from 'axios'

// Use relative paths in browser to leverage Vite proxy
// The Vite dev server will proxy /api/* requests to the backend
const getApiBaseUrl = () => {
  const envUrl = import.meta.env.VITE_API_BASE_URL
  if (envUrl) {
    // If explicitly set, use it (for production builds)
    return envUrl
  }

  // In development, use empty string for relative paths
  // Vite proxy will handle forwarding to backend
  return ''
}

const API_BASE_URL = getApiBaseUrl()

/** Generate a UUID v4 for request correlation (backend echoes it in response and logs). */
function generateRequestId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0
    const v = c === 'x' ? r : (r & 0x3) | 0x8
    return v.toString(16)
  })
}

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
  // Global cap so a wedged backend endpoint can't leave a page stuck
  // on a loader forever. 30s is well above the slowest legitimate
  // admin query. Individual calls can override via { timeout }.
  timeout: 30_000,
})

// Request interceptor - Auth token + tracing headers (x-request-id, x-tenant-id)
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    // Tracing: backend uses these for structured logs and echoes them in response
    config.headers['x-request-id'] = config.headers['x-request-id'] ?? generateRequestId()
    const tenantId = localStorage.getItem('tenant_id')
    if (tenantId) {
      config.headers['x-tenant-id'] = tenantId
    }
    // For FormData, remove Content-Type header to let browser set it with boundary
    if (config.data instanceof FormData) {
      delete config.headers['Content-Type']
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor - Handle errors
// Public customer-facing pages manage their own 401s (wrong pairing
// token, expired QR, etc.) — redirecting them to /auth/login would
// throw a guest into a staff login screen, which is confusing and
// kicks the tablet out of kiosk mode.
//
// Matches both the platform URLs (/kiosk, /masa/…) and the tenant-
// scoped variants (/pizzeria-la-club/kiosk, /pinehill/masa/abc…). A
// regex feels heavier than startsWith but the alternative (listing
// every tenant slug) isn't tenable.
const PUBLIC_401_SAFE_PATTERNS: RegExp[] = [
  /^\/auth\//,
  /(?:^|\/)kiosk(?:\/|$|\?)/,   // /kiosk, /:slug/kiosk, /kiosk?x=1
  /(?:^|\/)masa\//,             // /masa/:token, /:slug/masa/:token
  /^\/r\//,                      // QR reviews — platform-only
  /(?:^|\/)account(?:\/|$)/,
  /(?:^|\/)restaurant\/order-online(?:\/|$|\?)/,
]

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    if (error.response?.status === 401) {
      const path = typeof window !== 'undefined' ? window.location.pathname : ''
      const isPublicPage = PUBLIC_401_SAFE_PATTERNS.some((rx) => rx.test(path))
      // On staff pages we clear the stale token and bounce to login;
      // on public pages we only surface the error to the caller and
      // leave navigation alone.
      if (!isPublicPage) {
        localStorage.removeItem('access_token')
        window.location.href = '/auth/login'
      }
    }
    // Global plan-limit gate: backend returns 402 with structured detail
    // {code: "plan_limit_reached", metric, used, cap, plan_name, message,
    // upgrade_url}. Surface as a custom event so a single mount-level
    // listener can render an upsell modal without coupling every caller.
    if (error.response?.status === 402) {
      const detail = (error.response?.data as any)?.detail
      if (detail && typeof window !== 'undefined') {
        if (detail.code === 'plan_limit_reached') {
          window.dispatchEvent(new CustomEvent('plan-limit-reached', { detail }))
        } else if (detail.error === 'cost_limit_reached') {
          // Bridge super-admin cost-dashboard limits into the same upsell modal.
          window.dispatchEvent(new CustomEvent('plan-limit-reached', {
            detail: {
              code: 'plan_limit_reached',
              metric: detail.metric,
              used: detail.used,
              cap: detail.limit,
              plan_name: null,
              message: detail.message,
              upgrade_url: '/admin/subscription',
            },
          }))
        }
      }
    }
    return Promise.reject(error)
  }
)

export default apiClient

