/**
 * Billing API client – providers, Oblio status, connect, test, disconnect, companies, series.
 * Base path: /api/billing
 */
import apiClient from './client'

export interface BillingProviderInfo {
  id: string
  name: string
  capabilities: string[]
}
export interface EffectiveBillingProviderResponse {
  provider: string
}

export interface OblioStatusResponse {
  provider: string
  status: 'connected' | 'disconnected' | 'error'
  oblio_client_id?: string | null
  selected_company_cif?: string | null
  default_invoice_series?: string | null
  invoice_product_name?: string | null
  default_vat_percentage?: string | null
  last_test_at?: string | null
  last_error?: string | null
}

export interface OblioConnectBody {
  clientId: string
  clientSecret?: string
  companyCif?: string
  defaultInvoiceSeries?: string
  invoiceProductName?: string
  defaultVatPercentage?: string
}

export interface OblioCompany {
  cif?: string
  id?: string
  name?: string
  [key: string]: unknown
}

export interface OblioSeriesItem {
  name?: string
  seriesName?: string
  [key: string]: unknown
}

export interface OblioProductItem {
  id?: string
  name?: string
  code?: string
  description?: string
  vatPercentage?: number
  vatName?: string
  measuringUnit?: string
  productType?: string
  [key: string]: unknown
}

export interface OblioProduct {
  name?: string
  code?: string
  vatPercentage?: number
  vatName?: string
  measuringUnit?: string
  [key: string]: unknown
}

export const billingApi = {
  getProviders: async (): Promise<BillingProviderInfo[]> => {
    const { data } = await apiClient.get<BillingProviderInfo[]>('/api/billing/providers')
    return data
  },

  getEffectiveProvider: async (): Promise<EffectiveBillingProviderResponse> => {
    const { data } = await apiClient.get<EffectiveBillingProviderResponse>('/api/billing/effective-provider')
    return data
  },

  /** Setează providerul folosit la facturare: oblio | smartbill | fgo | proforma */
  setActiveProvider: async (provider: 'oblio' | 'smartbill' | 'fgo' | 'proforma'): Promise<{ ok: boolean; message: string; provider: string }> => {
    const { data } = await apiClient.put<{ ok: boolean; message: string; provider: string }>('/api/billing/active-provider', { provider })
    return data
  },

  getOblioStatus: async (): Promise<OblioStatusResponse> => {
    const { data } = await apiClient.get<OblioStatusResponse>('/api/billing/oblio/status')
    return data
  },

  connectOblio: async (body: OblioConnectBody): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/billing/oblio/connect', body)
    return data
  },

  testOblio: async (body?: { clientId?: string; clientSecret?: string }): Promise<{ ok: boolean; message: string; companies?: OblioCompany[] }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string; companies?: OblioCompany[] }>('/api/billing/oblio/test', body ?? {})
    return data
  },

  disconnectOblio: async (): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/billing/oblio/disconnect')
    return data
  },

  getOblioCompanies: async (): Promise<{ companies: OblioCompany[] }> => {
    const { data } = await apiClient.get<{ companies: OblioCompany[] }>('/api/billing/oblio/companies')
    return data
  },

  getOblioSeries: async (companyCif?: string): Promise<{ series: OblioSeriesItem[] }> => {
    const params = companyCif ? { companyCif } : {}
    const { data } = await apiClient.get<{ series: OblioSeriesItem[] }>('/api/billing/oblio/series', { params })
    return data
  },

  /** Lista de produse/servicii din Oblio pentru selectare la facturare */
  getOblioProducts: async (companyCif?: string): Promise<{ products: OblioProductItem[] }> => {
    const params = companyCif ? { companyCif } : {}
    const { data } = await apiClient.get<{ products: OblioProductItem[] }>('/api/billing/oblio/products', { params })
    return data
  },

  /** Încarcă seriile pentru o companie înainte de conectare (trimite clientId/clientSecret). */
  getOblioSeriesWithCredentials: async (
    companyCif: string,
    clientId: string,
    clientSecret: string
  ): Promise<{ series: OblioSeriesItem[] }> => {
    const { data } = await apiClient.post<{ series: OblioSeriesItem[] }>('/api/billing/oblio/series', {
      companyCif,
      clientId,
      clientSecret,
    })
    return data
  },

  // SmartBill
  getSmartBillStatus: async (): Promise<SmartBillStatusResponse> => {
    const { data } = await apiClient.get<SmartBillStatusResponse>('/api/billing/smartbill/status')
    return data
  },

  connectSmartBill: async (body: SmartBillConnectBody): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/billing/smartbill/connect', body)
    return data
  },

  testSmartBill: async (body?: { email?: string; token?: string; companyCif?: string }): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/billing/smartbill/test', body ?? {})
    return data
  },

  disconnectSmartBill: async (): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/billing/smartbill/disconnect')
    return data
  },

  getSmartBillSeries: async (companyCif?: string): Promise<{ series: SmartBillSeriesItem[] }> => {
    const params = companyCif ? { companyCif } : {}
    const { data } = await apiClient.get<{ series: SmartBillSeriesItem[] }>('/api/billing/smartbill/series', { params })
    return data
  },

  getSmartBillVatRates: async (companyCif?: string): Promise<{ vatRates: unknown[] }> => {
    const params = companyCif ? { companyCif } : {}
    const { data } = await apiClient.get<{ vatRates: unknown[] }>('/api/billing/smartbill/vat-rates', { params })
    return data
  },

  // Tenant-scoped SmartBill settings facade
  getTenantSmartBillSettings: async (): Promise<TenantSmartBillSettings> => {
    const { data } = await apiClient.get<TenantSmartBillSettings>('/api/tenant/billing/smartbill/settings')
    return data
  },

  saveTenantSmartBillSettings: async (body: SmartBillConnectBody): Promise<{ ok: boolean; settings: TenantSmartBillSettings }> => {
    const { data } = await apiClient.put<{ ok: boolean; settings: TenantSmartBillSettings }>('/api/tenant/billing/smartbill/settings', body)
    return data
  },

  testTenantSmartBillConnection: async (body: Partial<SmartBillConnectBody>): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/tenant/billing/smartbill/test-connection', body)
    return data
  },

  issueTenantSmartBillInvoice: async (body: { sourceType: string; sourceId: string; idempotencyKey?: string; amountType?: string }) => {
    const { data } = await apiClient.post('/api/tenant/billing/smartbill/issue-invoice', body)
    return data
  },

  // Tenant-scoped FGO settings facade
  getTenantFGOSettings: async (): Promise<TenantFGOSettings> => {
    const { data } = await apiClient.get<TenantFGOSettings>('/api/tenant/billing/fgo/settings')
    return data
  },

  saveTenantFGOSettings: async (body: FGOConnectBody): Promise<{ ok: boolean; settings: TenantFGOSettings }> => {
    const { data } = await apiClient.put<{ ok: boolean; settings: TenantFGOSettings }>('/api/tenant/billing/fgo/settings', body)
    return data
  },

  testTenantFGOConnection: async (body: Partial<FGOConnectBody>): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/tenant/billing/fgo/test-connection', body)
    return data
  },

  disconnectTenantFGO: async (): Promise<{ ok: boolean; message: string }> => {
    const { data } = await apiClient.post<{ ok: boolean; message: string }>('/api/tenant/billing/fgo/disconnect')
    return data
  },

  issueTenantFGOInvoice: async (body: { sourceType: string; sourceId: string; idempotencyKey?: string; amountType?: string }) => {
    const { data } = await apiClient.post('/api/tenant/billing/fgo/issue-invoice', body)
    return data
  },

  cancelTenantFGOInvoice: async (invoiceId: string, body?: { reason?: string; issueSeriesName?: string; issueNumber?: string }) => {
    const { data } = await apiClient.post(`/api/tenant/billing/fgo/cancel-invoice/${invoiceId}`, body ?? {})
    return data
  },

  getTenantBillingInvoices: async (params?: { provider?: string; sourceType?: string; sourceId?: string }): Promise<{ items: TenantIssuedInvoice[] }> => {
    const { data } = await apiClient.get<{ items: TenantIssuedInvoice[] }>('/api/tenant/billing/invoices', { params })
    return data
  },
}

export interface SmartBillStatusResponse {
  provider: string
  status: 'connected' | 'disconnected' | 'error'
  enabled?: boolean | null
  smartbill_email?: string | null
  selected_company_cif?: string | null
  default_invoice_series?: string | null
  default_currency?: string | null
  default_language?: string | null
  default_is_tax_payer?: boolean | null
  default_payment_method?: string | null
  default_notes?: string | null
  invoice_settings?: Record<string, unknown> | null
  last_connection_check_at?: string | null
  last_connection_status?: string | null
  last_sync_at?: string | null
  last_test_at?: string | null
  last_error?: string | null
}

export interface SmartBillConnectBody {
  email: string
  token?: string
  companyCif: string
  defaultSeries?: string
  enabled?: boolean
  defaultCurrency?: string
  defaultLanguage?: string
  defaultIsTaxPayer?: boolean
  defaultPaymentMethod?: string
  defaultNotes?: string
  invoiceSettings?: Record<string, unknown>
}

export interface SmartBillSeriesItem {
  name?: string
  seriesName?: string
  [key: string]: unknown
}

export interface FGOConnectBody {
  codUnic: string
  privateKey?: string
  platformaUrl?: string
  environment?: 'test' | 'production'
  defaultSeries?: string
  enabled?: boolean
  defaultCurrency?: string
  defaultInvoiceType?: string
  defaultDueDays?: number
  verifyDuplicate?: boolean
  defaultPaymentType?: string
  defaultNotes?: string
}

export interface TenantFGOSettings {
  provider: string
  status: 'connected' | 'disconnected' | 'error'
  enabled: boolean
  codUnic?: string | null
  platformaUrl?: string | null
  environment?: 'test' | 'production'
  defaultSeries?: string | null
  defaultCurrency?: string | null
  defaultInvoiceType?: string | null
  defaultDueDays?: number | null
  verifyDuplicate?: boolean | null
  defaultPaymentType?: string | null
  defaultNotes?: string | null
  lastConnectionCheckAt?: string | null
  lastConnectionStatus?: string | null
  lastSyncAt?: string | null
  lastError?: string | null
}

export interface TenantSmartBillSettings {
  provider: string
  status: 'connected' | 'disconnected' | 'error'
  enabled: boolean
  email?: string | null
  companyCif?: string | null
  defaultSeries?: string | null
  defaultCurrency?: string | null
  defaultLanguage?: string | null
  defaultIsTaxPayer?: boolean | null
  defaultPaymentMethod?: string | null
  defaultNotes?: string | null
  invoiceSettings?: Record<string, unknown> | null
  lastConnectionCheckAt?: string | null
  lastConnectionStatus?: string | null
  lastSyncAt?: string | null
  lastError?: string | null
}

export interface TenantIssuedInvoice {
  id: string
  invoiceNumber: string
  provider: string
  sourceType?: string | null
  sourceId?: string | null
  seriesName?: string | null
  status?: string | null
  externalDocumentId?: string | null
  link?: string | null
  issuedAt?: string | null
  createdAt?: string | null
  totalAmount?: number | null
  errorMessage?: string | null
}
