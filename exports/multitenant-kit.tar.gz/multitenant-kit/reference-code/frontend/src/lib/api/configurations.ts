/**
 * Configurations API client (Super Admin)
 */
import apiClient from './client'

export interface SocialConfig {
  facebook: {
    appId: string
    appSecret: string
    enabled: boolean
  }
  google: {
    clientId: string
    clientSecret: string
    enabled: boolean
  }
}

export interface AiConfig {
  openaiApiKey: string
  enabled: boolean
  features: {
    textImprovement: boolean
    autoTranslation: boolean
    contentGeneration: boolean
  }
  limits: {
    requestsPerDay: number
    requestsPerTenant: number
  }
}

export interface DnsConfig {
  ip: string
  apiNinjasKey: string
}

export interface HomepageUnitsDisplayConfig {
  showDescription: boolean
  showPrice: boolean
  showBedrooms: boolean
  showBathrooms: boolean
  showCapacity: boolean
}

export interface Tenant {
  id: string
  name: string
  slug: string
}

export const configurationsApi = {
  /**
   * Get social integrations configuration (super admin only).
   */
  getSocialConfig: async (): Promise<SocialConfig> => {
    const response = await apiClient.get<SocialConfig>('/api/super-admin/integrations')
    return response.data
  },

  /**
   * Update social integrations configuration (super admin only).
   */
  updateSocialConfig: async (config: SocialConfig): Promise<void> => {
    await apiClient.put('/api/super-admin/integrations', config)
  },

  /**
   * Get AI configuration (super admin only).
   */
  getAiConfig: async (): Promise<AiConfig> => {
    const response = await apiClient.get<AiConfig>('/api/super-admin/ai-config')
    return response.data
  },

  /**
   * Update AI configuration (super admin only).
   */
  updateAiConfig: async (config: AiConfig): Promise<void> => {
    await apiClient.put('/api/super-admin/ai-config', config)
  },

  /**
   * Test AI connection (super admin only).
   */
  testAiConnection: async (apiKey: string): Promise<{ message: string }> => {
    const response = await apiClient.post<{ message: string }>('/api/super-admin/ai-config/test', { openaiApiKey: apiKey })
    return response.data
  },

  /**
   * Get DNS configuration (super admin only).
   */
  getDnsConfig: async (): Promise<DnsConfig> => {
    const response = await apiClient.get<DnsConfig>('/api/system/dns-ip')
    return response.data
  },

  /**
   * Update DNS configuration (super admin only).
   */
  updateDnsConfig: async (config: DnsConfig): Promise<void> => {
    await apiClient.put('/api/system/dns-ip', config)
  },

  /**
   * Get all tenants (for hero carousel selection).
   */
  getTenants: async (): Promise<Tenant[]> => {
    const response = await apiClient.get<{ tenants: Tenant[] }>('/api/super-admin/tenants')
    return response.data.tenants || []
  },

  /**
   * Get homepage hero carousel configuration.
   */
  getHeroCarouselConfig: async (): Promise<string[]> => {
    const response = await apiClient.get<{ value: string | null }>('/api/system/config?key=homepage_hero_carousel_tenant_ids')
    if (response.data.value) {
      try {
        return JSON.parse(response.data.value)
      } catch {
        return []
      }
    }
    return []
  },

  /**
   * Update homepage hero carousel configuration (super admin only).
   */
  updateHeroCarouselConfig: async (tenantIds: string[]): Promise<void> => {
    await apiClient.put('/api/system/config', {
      key: 'homepage_hero_carousel_tenant_ids',
      value: JSON.stringify(tenantIds)
    })
  },

  /**
   * Get homepage units display fields configuration.
   */
  getHomepageUnitsDisplayConfig: async (): Promise<HomepageUnitsDisplayConfig> => {
    const response = await apiClient.get<{ value: string | null }>('/api/system/config?key=homepage_units_display_config')
    const defaults: HomepageUnitsDisplayConfig = {
      showDescription: true,
      showPrice: true,
      showBedrooms: true,
      showBathrooms: true,
      showCapacity: true,
    }
    if (!response.data?.value) return defaults
    try {
      const parsed = JSON.parse(response.data.value)
      return {
        showDescription: parsed.showDescription !== false,
        showPrice: parsed.showPrice !== false,
        showBedrooms: parsed.showBedrooms !== false,
        showBathrooms: parsed.showBathrooms !== false,
        showCapacity: parsed.showCapacity !== false,
      }
    } catch {
      return defaults
    }
  },

  /**
   * Update homepage units display fields configuration.
   */
  updateHomepageUnitsDisplayConfig: async (config: HomepageUnitsDisplayConfig): Promise<void> => {
    await apiClient.put('/api/system/config', {
      key: 'homepage_units_display_config',
      value: JSON.stringify(config),
    })
  },

  /**
   * Get the flag that swaps the per-unit hero carousel for a grid of
   * featured tenant cards on the marketing homepage.
   */
  getFeaturedTenantsEnabled: async (): Promise<boolean> => {
    const response = await apiClient.get<{ value: string | null }>('/api/system/config?key=homepage_featured_tenants_enabled')
    const raw = response.data?.value
    if (raw == null) return false
    try {
      const parsed = JSON.parse(raw)
      if (typeof parsed === 'boolean') return parsed
    } catch { /* fall through */ }
    return String(raw).trim().toLowerCase() === 'true'
  },

  /**
   * Update the featured-tenants toggle (super admin only).
   */
  updateFeaturedTenantsEnabled: async (enabled: boolean): Promise<void> => {
    await apiClient.put('/api/system/config', {
      key: 'homepage_featured_tenants_enabled',
      value: JSON.stringify(enabled),
    })
  },

  /**
   * List domain requests (tenants who submitted a custom domain). Super admin only.
   */
  getDomainRequests: async (status?: string): Promise<DomainRequestItem[]> => {
    const url = status ? `/api/super-admin/domain-requests?status=${encodeURIComponent(status)}` : '/api/super-admin/domain-requests'
    const response = await apiClient.get<{ items: DomainRequestItem[] }>(url)
    return response.data.items || []
  },

  /**
   * Update a domain request (status, tenant_id_associated, notes). Super admin only.
   */
  updateDomainRequest: async (
    requestId: string,
    data: { status?: string; tenant_id_associated?: string | null; notes?: string | null }
  ): Promise<DomainRequestItem> => {
    const response = await apiClient.patch<DomainRequestItem>(`/api/super-admin/domain-requests/${requestId}`, data)
    return response.data
  }
}

export interface DomainRequestItem {
  id: string
  tenant_id: string
  tenant_name: string | null
  tenant_slug: string | null
  domain: string
  is_active: boolean
  status: string
  tenant_id_associated: string | null
  notes: string | null
  created_at: string | null
  updated_at: string | null
}








