"""
BillingIntegration SQLAlchemy model.
Per-tenant billing provider connection (Oblio/SmartBill): credentials, defaults and audit fields.
"""
from sqlalchemy import Boolean, Column, String, DateTime, ForeignKey, Text, UniqueConstraint
from sqlalchemy.sql import func
from src.db.base import Base


class BillingIntegration(Base):
    __tablename__ = "billing_integrations"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)

    provider = Column(String, nullable=False, index=True)  # e.g. "oblio"

    # Status: connected | disconnected | error
    status = Column(String, nullable=False, default="disconnected")
    enabled = Column(Boolean, nullable=False, default=False, server_default="false")

    # Oblio-specific (provider = "oblio")
    oblio_client_id = Column(String, nullable=True)  # email
    oblio_client_secret_encrypted = Column(Text, nullable=True)  # never expose to API response
    # SmartBill-specific (provider = "smartbill")
    smartbill_email = Column(String, nullable=True)
    smartbill_token_encrypted = Column(Text, nullable=True)  # never expose to API response
    # FGO-specific (provider = "fgo")
    fgo_cod_unic = Column(String, nullable=True)
    fgo_private_key_encrypted = Column(Text, nullable=True)  # never expose to API response
    fgo_platform_url = Column(String, nullable=True)
    fgo_environment = Column(String, nullable=True)  # test | production
    fgo_default_invoice_type = Column(String, nullable=True)
    fgo_default_due_days = Column(String, nullable=True)
    fgo_verify_duplicate = Column(Boolean, nullable=True)
    fgo_default_payment_type = Column(String, nullable=True)

    # Shared: company CIF / default series (used by Oblio, SmartBill, FGO)
    selected_company_cif = Column(String, nullable=True)
    default_invoice_series = Column(String, nullable=True)
    default_proforma_series = Column(String, nullable=True)
    # Optional defaults (JSON or separate columns as needed)
    work_station = Column(String, nullable=True)
    management = Column(String, nullable=True)
    currency = Column(String, nullable=True)
    default_language = Column(String, nullable=True)
    default_payment_method = Column(String, nullable=True)
    default_notes = Column(Text, nullable=True)
    invoice_settings_json = Column(Text, nullable=True)
    default_is_tax_payer = Column(Boolean, nullable=True)
    vat_included = Column(String, nullable=True)
    # Serviciu factură: nume și TVA (configurabil sau din listă Oblio)
    invoice_product_name = Column(String, nullable=True)
    default_vat_percentage = Column(String, nullable=True)  # e.g. "9", "19"

    last_test_at = Column(DateTime(timezone=True), nullable=True)
    last_connection_check_at = Column(DateTime(timezone=True), nullable=True)
    last_connection_status = Column(String, nullable=True)
    last_sync_at = Column(DateTime(timezone=True), nullable=True)
    last_error = Column(Text, nullable=True)
    created_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    updated_by = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

    __table_args__ = (UniqueConstraint("tenant_id", "provider", name="ix_billing_integrations_tenant_provider"),)


class BillingInvoiceIdempotency(Base):
    """Maps internal invoice id to provider document (e.g. Oblio series/number) to avoid duplicates."""
    __tablename__ = "billing_invoice_idempotency"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    provider = Column(String, nullable=False, index=True)
    idempotency_key = Column(String, nullable=False, index=True)  # internal key (e.g. booking_id or uuid)
    oblio_series_name = Column(String, nullable=True)
    oblio_number = Column(String, nullable=True)
    smartbill_series_name = Column(String, nullable=True)
    smartbill_number = Column(String, nullable=True)
    fgo_series_name = Column(String, nullable=True)
    fgo_number = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
