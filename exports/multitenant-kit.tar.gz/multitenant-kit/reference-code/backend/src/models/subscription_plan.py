"""
SubscriptionPlan SQLAlchemy model.
Matches: prisma/schema.prisma SubscriptionPlan model
"""
from sqlalchemy import Column, String, DateTime, Integer, Float, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from src.db.base import Base


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"
    
    id = Column(String, primary_key=True)
    name = Column(String, unique=True, nullable=False, index=True)
    description = Column(String, nullable=True)
    monthly_price = Column(Float, nullable=False)
    yearly_price = Column(Float, nullable=False)
    currency = Column(String, default="RON", nullable=False)
    
    max_properties = Column(Integer, default=1, nullable=False)
    max_units = Column(Integer, default=5, nullable=False)
    max_bookings = Column(Integer, default=100, nullable=False)
    
    features = Column(String, nullable=True)  # JSON string
    benefits = Column(String, nullable=True)  # JSON string
    
    is_active = Column(Boolean, default=True, nullable=False)
    stripe_monthly_price_id = Column(String, nullable=True)
    stripe_yearly_price_id = Column(String, nullable=True)
    
    includes_onsite_onboard = Column(Boolean, default=False, nullable=False)
    includes_24h_support = Column(Boolean, default=False, nullable=False)
    trial_months = Column(Integer, default=0, nullable=False)
    
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    # subscriptions = relationship("Subscription", back_populates="plan")  # TODO: Uncomment when Subscription model is created

