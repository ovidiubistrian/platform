"""
Tenant model - SQLAlchemy.
"""
from sqlalchemy import Column, String, Boolean, DateTime, Integer, ForeignKey, Date
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from src.db.base import Base


class Tenant(Base):
    """Tenant model matching Prisma schema."""
    __tablename__ = "tenants"
    
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    slug = Column(String, unique=True, nullable=False, index=True)
    domain = Column(String, nullable=True)
    root_domain = Column(String, nullable=True)
    status = Column(String, default="trial", nullable=False)
    subscription_plan = Column(String, default="free", nullable=False)
    # FK -> plan_catalog.id. Source of truth for limits going forward; the
    # legacy `subscription_plan` string remains for backwards compat.
    plan_catalog_id = Column(String, ForeignKey("plan_catalog.id", ondelete="SET NULL"),
                             nullable=True, index=True)
    # Per-tenant overrides to plan_catalog.limits (e.g. legacy contract that
    # keeps a higher unit ceiling). Same shape as plan_catalog.limits; keys
    # present here win over the catalog row.
    plan_overrides = Column(JSONB, nullable=False, server_default="{}", default=dict)
    subscription_ends_at = Column(DateTime, nullable=True)
    # Timestamp of when this tenant first landed on the Free plan. Once set,
    # the tenant can never be downgraded back to Free — enforced by the
    # subscribe endpoint and super-admin tenant update. Free plans always
    # expire 30 days after this stamp.
    free_plan_used_at = Column(DateTime, nullable=True)
    # Billing access gate counters. Incremented each time the tenant admin
    # clicks "Amână" on the payment-required banner after subscription has
    # expired. When it reaches 3 the tenant is blocked from admin access
    # until they pay or super-admin resets.
    login_post_expiry_count = Column(Integer, default=0, nullable=False, server_default="0")
    # Human-readable reason populated when the access gate blocks / super-admin
    # suspends the tenant. Used for the billing report, no business logic.
    suspended_reason = Column(String, nullable=True)
    max_properties = Column(Integer, default=1, nullable=False)
    max_units = Column(Integer, default=5, nullable=False)
    max_bookings = Column(Integer, default=100, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    onboarding_completed = Column(Boolean, default=False, nullable=False)
    onboarding_step = Column(Integer, default=0, nullable=False, server_default="0")
    onboarding_skipped_steps = Column(String, nullable=True)  # JSON array of skipped step indices
    # Onboarding wizard requests that super-admin resolves manually.
    onboarding_requested_domain = Column(String, nullable=True)
    onboarding_requested_domain_at = Column(DateTime, nullable=True)
    onboarding_requested_domain_status = Column(String, nullable=True)  # pending|resolved|rejected
    onboarding_requested_whatsapp = Column(String, nullable=True)
    onboarding_requested_whatsapp_at = Column(DateTime, nullable=True)
    onboarding_requested_whatsapp_status = Column(String, nullable=True)  # pending|resolved|rejected
    # Business email provisioning request (e.g. "info@pensiunea.ro") — paid option
    onboarding_requested_business_email = Column(String, nullable=True)
    onboarding_requested_business_email_at = Column(DateTime, nullable=True)
    onboarding_requested_business_email_status = Column(String, nullable=True)  # pending|resolved|rejected
    # Free alternative: Reply-To address used when sending from no-reply@360booking.ro
    onboarding_reply_to_email = Column(String, nullable=True)
    settings = Column(String, nullable=True)  # JSON string
    # Template used when sending SMS notifications to housekeepers.
    # Supports placeholders: {date}, {property}, {unit}, {link}.
    # null = use DEFAULT_HOUSEKEEPING_SMS_TEMPLATE from services/housekeeping_sms.
    housekeeping_sms_template = Column(String, nullable=True)
    custom_domain = Column(String, unique=True, nullable=True, index=True)
    subdomain = Column(String, unique=True, nullable=True, index=True)
    is_custom_domain_active = Column(Boolean, default=False, nullable=False)
    is_subdomain_active = Column(Boolean, default=True, nullable=False)
    dns_configured = Column(Boolean, default=False, nullable=False)
    last_dns_check = Column(DateTime, nullable=True)
    is_demo = Column(Boolean, default=False, nullable=False)
    demo_expires_at = Column(DateTime, nullable=True)
    phone_number = Column(String, nullable=True)
    # Separate override for where booking SMS notifications land. If null, falls
    # back to `phone_number` (the registration / business contact number).
    sms_notification_phone = Column(String, nullable=True)
    sms_notifications_enabled = Column(Boolean, default=False, nullable=False)
    # Monthly SMS free-tier tracking. `sms_monthly_free_override` lets a super-admin
    # set a custom allowance for a tenant (null = use super_admin_sms_configs.default_monthly_free_sms).
    # `sms_monthly_used` resets at the start of every calendar month (via credit_service).
    sms_monthly_free_override = Column(Integer, nullable=True)
    sms_monthly_used = Column(Integer, nullable=False, default=0, server_default="0")
    sms_period_start = Column(Date, nullable=True)
    business_email_provider = Column(String, nullable=True)
    business_email_status = Column(String, nullable=True)
    email_api_key = Column(String, nullable=True)
    email_configured = Column(Boolean, default=False, nullable=False)
    email_from_email = Column(String, nullable=True)
    email_from_name = Column(String, nullable=True)
    email_provider = Column(String, nullable=True)
    email_verified_at = Column(DateTime, nullable=True)
    # Referral — codul promoțional folosit la signup îl asociază cu un
    # vânzător. Ambele câmpuri sunt NULLABLE; tenanții fără cod la signup
    # rămân fără referral și nu apar în dashboard-ul niciunui vânzător.
    referral_sales_code = Column(String, nullable=True, index=True)
    referral_sales_user_id = Column(String, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    # Which product this tenant subscribed to. Drives sidebar + public
    # page rendering — not a billing gate. Values:
    #   accommodation : pensiune/hotel (current default, restaurant free)
    #   restaurant    : standalone restaurant product (no accommodation UI)
    #   both          : mixed site (accommodation + restaurant sections)
    # Editable only by super-admin.
    product_type = Column(String(20), nullable=False, default="accommodation", server_default="accommodation")
    # Restaurant flavour. Only meaningful when product_type is restaurant/both.
    #   full      : complete solution (POS + gestiune + kitchen + fiscal + ...)
    #   menu_site : simplified — public site + SmartMenu QR + online orders +
    #               reservations + a POS view for online orders; the gestiune/
    #               stock/supplier/kitchen-hardware surface is hidden.
    # Editable only by super-admin. Defaults to full so existing restaurants
    # keep every feature.
    restaurant_tier = Column(String(20), nullable=False, default="full", server_default="full")
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)
    # Soft-delete stamp. NULL = live tenant. When set, the tenant is
    # considered deleted: hidden from the default super-admin list and
    # deactivated (is_active=False) so the public site 404s. A daily cron
    # hard-purges tenants whose deleted_at is older than 30 days; until
    # then a super-admin can restore (rollback) the tenant.
    deleted_at = Column(DateTime, nullable=True, index=True)

    # Relationships
    # foreign_keys disambiguates from `referral_sales_user_id` which also
    # points to users.id but is not the tenancy relationship.
    users = relationship(
        "User",
        back_populates="tenant",
        cascade="all, delete-orphan",
        foreign_keys="User.tenant_id",
    )
    properties = relationship("Property", back_populates="tenant", cascade="all, delete-orphan")
    bookings = relationship("Booking", back_populates="tenant", cascade="all, delete-orphan")
    units = relationship("Unit", back_populates="tenant", cascade="all, delete-orphan")
    customers = relationship("Customer", back_populates="tenant", cascade="all, delete-orphan")
    site_config = relationship("SiteConfig", back_populates="tenant", uselist=False, cascade="all, delete-orphan")
    invoices = relationship("Invoice", back_populates="tenant", cascade="all, delete-orphan")
    coupons = relationship("Coupon", back_populates="tenant", cascade="all, delete-orphan")
    facilities = relationship("Facility", back_populates="tenant", cascade="all, delete-orphan")
    activities = relationship("Activity", back_populates="tenant", cascade="all, delete-orphan")
    tourist_attractions = relationship("TouristAttraction", back_populates="tenant", cascade="all, delete-orphan")
    events = relationship("Event", back_populates="tenant", cascade="all, delete-orphan")
    feedbacks = relationship("Feedback", back_populates="tenant", cascade="all, delete-orphan")
    packages = relationship("Package", back_populates="tenant", cascade="all, delete-orphan")
    restaurant = relationship("Restaurant", back_populates="tenant", uselist=False, cascade="all, delete-orphan")
    campaigns = relationship("Campaign", back_populates="tenant", cascade="all, delete-orphan")
    customers = relationship("Customer", back_populates="tenant", cascade="all, delete-orphan")
    media_assets = relationship("MediaAsset", back_populates="tenant", cascade="all, delete-orphan")
    email_sending_domains = relationship(
        "TenantEmailSendingDomain", back_populates="tenant", cascade="all, delete-orphan"
    )
    email_usage_monthly = relationship(
        "EmailUsageMonthly", back_populates="tenant", cascade="all, delete-orphan"
    )
    email_messages = relationship(
        "EmailMessage", back_populates="tenant", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<Tenant(id={self.id}, name={self.name}, slug={self.slug})>"

