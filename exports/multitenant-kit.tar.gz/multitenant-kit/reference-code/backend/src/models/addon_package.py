"""
AddOnPackage and TenantAddOn models.

AddOnPackage is a catalog of add-on offerings a super-admin can sell on
top of a subscription plan: SMS packs for campaigns, email packs for
campaigns, and a Business Email monthly subscription. Each row has an
`is_active` flag — while false, the package is hidden from tenants so
the super-admin can prepare the catalog before going live.

TenantAddOn is the join table between tenants and add-on packages, and
tracks the remaining credits for one-shot packs and the expiration date
for monthly subscriptions.
"""
from sqlalchemy import Column, String, DateTime, Integer, Float, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from src.db.base import Base


# Supported add-on types (kept as strings so we can add new ones without
# an enum migration).
ADDON_TYPE_SMS_PACK = "sms_pack"
ADDON_TYPE_EMAIL_PACK = "email_pack"
ADDON_TYPE_BUSINESS_EMAIL = "business_email"
# SEO content SKUs (seeded by alembic seoaddon01). Activation hooks in
# super_admin.create_tenant_addon / update_tenant_addon recognise these
# and fire src.services.seo_content.onboarding.trigger_full_generation.
ADDON_TYPE_SEO_BOOSTER = "seo_booster"
ADDON_TYPE_SEO_CARE = "seo_care"

SEO_ADDON_TYPES = frozenset((ADDON_TYPE_SEO_BOOSTER, ADDON_TYPE_SEO_CARE))

# Billing cycles
BILLING_CYCLE_ONE_TIME = "one_time"
BILLING_CYCLE_MONTHLY = "monthly"


class AddOnPackage(Base):
    __tablename__ = "addon_packages"

    id = Column(String, primary_key=True)
    type = Column(String, nullable=False, index=True)  # sms_pack | email_pack | business_email
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)

    price = Column(Float, nullable=False, default=0)
    currency = Column(String, nullable=False, default="RON")
    billing_cycle = Column(String, nullable=False, default=BILLING_CYCLE_ONE_TIME)

    # For sms_pack / email_pack: how many units (SMSes, emails) the buyer
    # gets. NULL for business_email because the value is unlimited /
    # bound by the tenant's sending domain.
    quantity = Column(Integer, nullable=True)

    # Super-admin visibility toggle. When false, /api/subscriptions/addons
    # hides the row from tenants.
    is_active = Column(Boolean, nullable=False, default=False)

    # Optional Stripe integration bits — populated when the super-admin
    # wires billing up later.
    stripe_product_id = Column(String, nullable=True)
    stripe_price_id = Column(String, nullable=True)

    sort_order = Column(Integer, nullable=False, default=0)

    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    tenant_addons = relationship("TenantAddOn", back_populates="package", cascade="all, delete-orphan")


# Lifecycle states for a tenant's add-on purchase.
TENANT_ADDON_STATUS_PENDING = "pending"
TENANT_ADDON_STATUS_ACTIVE = "active"
TENANT_ADDON_STATUS_CANCELLED = "cancelled"
TENANT_ADDON_STATUS_EXPIRED = "expired"


class TenantAddOn(Base):
    __tablename__ = "tenant_addons"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    addon_package_id = Column(String, ForeignKey("addon_packages.id", ondelete="RESTRICT"), nullable=False, index=True)

    status = Column(String, nullable=False, default=TENANT_ADDON_STATUS_PENDING)

    # Credits remaining — used for sms_pack / email_pack enforcement when
    # the tenant sends campaigns. NULL for business_email (unlimited).
    sms_remaining = Column(Integer, nullable=True)
    email_remaining = Column(Integer, nullable=True)

    # For monthly subscriptions (business_email) this is the next renewal
    # timestamp. For one-shot packs it is NULL (the pack lasts until
    # credits run out).
    activated_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=True)

    notes = Column(String, nullable=True)

    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    package = relationship("AddOnPackage", back_populates="tenant_addons")
