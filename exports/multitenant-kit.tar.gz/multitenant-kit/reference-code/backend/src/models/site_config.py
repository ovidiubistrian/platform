"""
SiteConfig SQLAlchemy model.
Matches: prisma/schema.prisma SiteConfig model
"""
from sqlalchemy import Column, String, DateTime, Integer, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from src.db.base import Base


class SiteConfig(Base):
    __tablename__ = "site_configs"

    id = Column(String, primary_key=True)
    tenant_id = Column(String, ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)

    site_name = Column(String, default="Pensiune", nullable=False)
    site_slug = Column(String, unique=True, nullable=True, index=True)
    custom_domain = Column(String, unique=True, nullable=True, index=True)
    site_description = Column(String, nullable=True)
    # Per-language variants of the two homepage-hero fields: { "ro": "...", "en": "...", ... }
    site_name_translations = Column(JSON, nullable=True)
    site_description_translations = Column(JSON, nullable=True)
    logo = Column(String, nullable=True)
    hero_image = Column(String, nullable=True)
    hero_image1 = Column(String, nullable=True)
    hero_image2 = Column(String, nullable=True)
    hero_image3 = Column(String, nullable=True)
    primary_color = Column(String, default="#3b82f6", nullable=False)
    hero_text_color = Column(String, default="#ffffff", nullable=False)
    font_family = Column(String, default="Inter", nullable=False)
    currency = Column(String, default="RON", nullable=False)
    language = Column(String, default="ro", nullable=False)
    timezone = Column(String, default="Europe/Bucharest", nullable=False)
    theme = Column(String, default="pine-hill", nullable=False)
    
    # Contact info
    contact_address = Column(String, nullable=True)
    contact_phone = Column(String, nullable=True)
    contact_email = Column(String, nullable=True)
    contact_facebook = Column(String, nullable=True)
    contact_instagram = Column(String, nullable=True)
    contact_tiktok = Column(String, nullable=True)
    contact_whatsapp = Column(String, nullable=True)
    contact_latitude = Column(String, nullable=True)
    contact_longitude = Column(String, nullable=True)
    # Structured judet/localitate codes matching backend/src/data/romania_geo.json.
    # contact_address continues to hold the street + number free-form.
    contact_judet_code = Column(String, nullable=True)
    contact_localitate_id = Column(String, nullable=True)
    
    # Email config
    email_from = Column(String, nullable=True)
    email_reply_to = Column(String, nullable=True)
    email_booking_subject = Column(String, nullable=True)
    email_booking_body = Column(String, nullable=True)
    email_confirm_subject = Column(String, nullable=True)
    email_confirm_body = Column(String, nullable=True)
    
    # JSON fields (stored as String, parsed when needed)
    settings = Column(String, nullable=True)  # JSON string
    automation_settings = Column(String, nullable=True)
    email_templates = Column(String, nullable=True)
    homepage_config = Column(String, nullable=True)
    billing_system = Column(String, default="proforma", nullable=True)
    oblio_config = Column(String, nullable=True)
    smartbill_config = Column(String, nullable=True)
    facilities = Column(String, nullable=True)
    url_config = Column(String, nullable=True)
    fgo_config = Column(String, nullable=True)
    bank_accounts = Column(String, nullable=True)
    stripe_config = Column(String, nullable=True)
    netopia_config = Column(String, nullable=True)
    # Banca Transilvania e-commerce (iPay). Same JSON shape as stripe/netopia.
    btipay_config = Column(String, nullable=True)
    # When multiple providers are wired, pick one as the default the
    # checkout flow uses ("stripe" | "netopia" | "btipay"). NULL / empty
    # falls back to Stripe when configured, then whichever is first.
    preferred_payment_provider = Column(String, nullable=True)
    facebook_config = Column(String, nullable=True)
    instagram_config = Column(String, nullable=True)
    whatsapp_config = Column(String, nullable=True)
    tiktok_config = Column(String, nullable=True)
    chat_widget_config = Column(String, nullable=True)
    auto_replies = Column(String, nullable=True)
    nearby_points = Column(String, nullable=True)

    # Per-tenant cross-domain canonical strategy. One of:
    #   - 'auto'           : self-canonical on every host (default)
    #   - 'marketplace'    : canonical → 360booking.ro/{slug}/...
    #   - 'custom_domain'  : canonical → https://{custom_domain}/...
    # Application-level enum lives in src/services/seo.py.
    # See backend/docs/seo.md (Phase 2.3) for the decision matrix.
    seo_primary_domain_strategy = Column(
        String(length=32),
        nullable=False,
        server_default="auto",
        default="auto",
    )

    # Partners section near footer:
    #   {"enabled": bool, "title": str?, "items": [
    #       {"id": str, "name": str, "logo_url": str, "link_url": str?, "description": str?}
    #   ]}
    # Editable from /admin/settings/partners; toggle from homepage structure tab.
    partners_config = Column(JSON, nullable=True)

    # "Descriere locație și zonă" — public homepage section rendered
    # below the accommodation units. Shape:
    #   {"enabled": bool,
    #    "title": str, "subtitle": str?,
    #    "description": str,             # plain text, multi-paragraph allowed
    #    "highlights": [str, ...],
    #    "images": [str, ...],           # absolute or app-relative URLs
    #    "cta_label": str?, "cta_target": str?,
    #    "ai_last_generated_at": iso8601?}
    # NULL means "feature inactive" — homepage doesn't render anything.
    # Edited via /admin/settings?tab=site-config sub-tab "location-section".
    location_section_config = Column(JSON, nullable=True)

    # Per-tenant override for the three public secondary pages (Termeni &
    # Condiții / Politica de Confidențialitate / FAQ). Shape:
    #   {"terms": {"ro": "<html>", "en": "..."}, "privacy": {...}, "faq": {...}}
    # NULL or missing lang key → fall back to the hardcoded React template.
    legal_pages_content = Column(JSON, nullable=True)
    
    # Vacation cards ("carduri de vacanță") acceptance signal. Single toggle:
    # in Romania a venue that accepts holiday vouchers accepts all issuers
    # (Up, Edenred, Pluxee/Sodexo), so there is no per-provider config.
    # When true, the public homepage shows a hero badge + a thin accent band.
    # vacation_cards_note is an optional free-text line (e.g. "plata se face
    # la check-in") rendered under the band when present.
    accepts_vacation_cards = Column(Boolean, default=False, nullable=False, server_default="false")
    vacation_cards_note = Column(String, nullable=True)

    # Per-tenant online-checkout payment-method acceptance. A tenant can offer
    # card-online only, bank-transfer only, or both. Both default true so the
    # public booking flow keeps showing both options for existing tenants.
    # The "card online" option additionally requires a configured provider
    # (Stripe/Netopia/BT iPay) — see tenant.py online_payment_enabled.
    accept_card_online = Column(Boolean, default=True, nullable=False, server_default="true")
    accept_bank_transfer = Column(Boolean, default=True, nullable=False, server_default="true")

    # Chat config
    chat_provider = Column(String, default="none", nullable=True)
    chat_enabled = Column(Boolean, default=False, nullable=False)
    tawk_property_id = Column(String, nullable=True)
    tawk_widget_id = Column(String, nullable=True)
    
    # Spa config
    spa_enabled = Column(Boolean, default=False, nullable=False)
    spa_description = Column(String, nullable=True)
    spa_services = Column(String, nullable=True)
    
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    tenant = relationship("Tenant", back_populates="site_config", uselist=False)













