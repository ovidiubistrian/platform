"""
User model - SQLAlchemy.
Maps exactly to Prisma User model.
"""
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from src.db.base import Base


class User(Base):
    """User model matching Prisma schema exactly."""
    __tablename__ = "users"
    
    id = Column(String, primary_key=True)
    name = Column(String, nullable=True)
    email = Column(String, unique=True, nullable=False, index=True)
    password = Column(String, nullable=False)
    role = Column(String, nullable=False, default="tenant_admin", index=True)
    tenant_id = Column(String, ForeignKey("tenants.id", ondelete="CASCADE"), nullable=True, index=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)
    email_verified = Column(Boolean, default=False, nullable=False)
    # Contact phone — currently used by housekeeper SMS notifications.
    # Optional for all other roles.
    phone = Column(String, nullable=True)
    two_factor_enabled = Column(Boolean, default=False, nullable=False)
    # Set when a temporary password is issued (e.g. demo→client conversion);
    # the app forces a password change on next login and clears it afterward.
    must_change_password = Column(Boolean, default=False, nullable=False, server_default="false")
    email_verification_token = Column(String, nullable=True)
    email_verification_expires = Column(DateTime, nullable=True)
    reset_password_token = Column(String, nullable=True)
    reset_password_expires = Column(DateTime, nullable=True)
    last_login_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships (matching Prisma schema)
    # foreign_keys explicit: tenants are linked via tenant_id; we ignore the
    # tenants.referral_sales_user_id FK that points back to users for
    # sales attribution (otherwise SQLAlchemy can't pick between the two).
    tenant = relationship("Tenant", back_populates="users", foreign_keys=[tenant_id])
    accounts = relationship("Account", back_populates="user", cascade="all, delete-orphan")
    sessions = relationship("Session", back_populates="user", cascade="all, delete-orphan")
    # communication_logs relationship will be added when CommunicationLog model is created
    # sales_profile relationship will be added when SalesUser model is created
    
    def __repr__(self):
        return f"<User(id={self.id}, email={self.email}, role={self.role}, tenant_id={self.tenant_id})>"

