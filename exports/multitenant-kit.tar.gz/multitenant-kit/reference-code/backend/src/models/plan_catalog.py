"""SQLAlchemy models for the public-facing plan catalog.

Distinct from `SubscriptionPlan` (Stripe-billed tenant plans). The
catalog is the marketing tier list rendered in the homepage carousel
and managed from /super-admin/subscription-plans.
"""
from sqlalchemy import (
    Column, String, Text, Integer, Boolean, Numeric, DateTime, ForeignKey,
)
from sqlalchemy.dialects.postgresql import ARRAY, JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from src.db.base import Base


class PlanCatalog(Base):
    __tablename__ = "plan_catalog"

    id = Column(String, primary_key=True)
    slug = Column(String, nullable=False, unique=True)
    name = Column(String, nullable=False)
    short_description = Column(Text, nullable=True)
    long_description = Column(Text, nullable=True)

    monthly_price = Column(Numeric(10, 2), nullable=False, default=0)
    annual_price = Column(Numeric(10, 2), nullable=False, default=0)
    annual_discount_percent = Column(Integer, nullable=False, default=0)
    price_text = Column(String, nullable=True)
    currency = Column(String, nullable=False, default="RON")

    category = Column(String, nullable=True)
    target_audience = Column(Text, nullable=True)
    audience = Column(ARRAY(String), nullable=False, default=list)

    is_active = Column(Boolean, nullable=False, default=True)
    is_public = Column(Boolean, nullable=False, default=True)
    show_on_homepage = Column(Boolean, nullable=False, default=True)
    show_in_carousel = Column(Boolean, nullable=False, default=True)
    is_recommended = Column(Boolean, nullable=False, default=False)
    is_founder_offer = Column(Boolean, nullable=False, default=False)

    badge_text = Column(String, nullable=True)
    cta_text = Column(String, nullable=False, default="Alege pachetul")
    cta_url = Column(String, nullable=True)
    sort_order = Column(Integer, nullable=False, default=0, index=True)
    accent_color = Column(String, nullable=True)
    icon_name = Column(String, nullable=True)

    limits = Column(JSONB, nullable=False, default=dict)
    # Trial — configurable per plan from super-admin. 0 = no trial.
    trial_days = Column(Integer, nullable=False, default=0)

    # Stripe sync. Populated by /api/super-admin/plan-catalog/{id}/sync-stripe.
    # Subscribe endpoint reads these to start the right Stripe Checkout session.
    stripe_product_id = Column(String, nullable=True)
    stripe_monthly_price_id = Column(String, nullable=True)
    stripe_yearly_price_id = Column(String, nullable=True)
    stripe_synced_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    features = relationship(
        "PlanCatalogFeature",
        back_populates="plan",
        cascade="all, delete-orphan",
        order_by="PlanCatalogFeature.sort_order",
    )


class PlanCatalogFeature(Base):
    __tablename__ = "plan_catalog_features"

    id = Column(String, primary_key=True)
    plan_id = Column(
        String,
        ForeignKey("plan_catalog.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    label = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String, nullable=True)
    is_included = Column(Boolean, nullable=False, default=True)
    sort_order = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)

    plan = relationship("PlanCatalog", back_populates="features")


class PlanCatalogGlobalFeature(Base):
    __tablename__ = "plan_catalog_global_features"

    id = Column(String, primary_key=True)
    label = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    category = Column(String, nullable=True)
    sort_order = Column(Integer, nullable=False, default=0)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
