"""
Persist and read AI config (e.g. OpenAI API key) for Super Admin.
Used by super_admin ai-config endpoints and by translations auto-translate.
"""
import json
import os
from pathlib import Path
from typing import Any, Dict

# Path relative to project root (migration-backend/), so it works regardless of cwd (e.g. in Docker)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_DEFAULT_PATH = _PROJECT_ROOT / "data" / "ai_config.json"


def _config_path() -> Path:
    env_path = os.getenv("AI_CONFIG_FILE")
    if env_path:
        return Path(env_path)
    return _DEFAULT_PATH


def read_ai_config() -> Dict[str, Any]:
    """Read AI config from file. Returns default structure if file missing."""
    path = _config_path()
    if not path.is_file():
        return {
            "openaiApiKey": "",
            "enabled": True,
            "features": {"textImprovement": True, "autoTranslation": True, "contentGeneration": True},
            "limits": {"requestsPerDay": 1000, "requestsPerTenant": 100},
        }
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except Exception:
        return {
            "openaiApiKey": "",
            "enabled": True,
            "features": {"textImprovement": True, "autoTranslation": True, "contentGeneration": True},
            "limits": {"requestsPerDay": 1000, "requestsPerTenant": 100},
        }


def write_ai_config(data: Dict[str, Any]) -> None:
    """Write AI config to file. Creates directory if needed."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def get_openai_api_key() -> str | None:
    """OpenAI API key: from saved AI config first, then from env OPENAI_API_KEY."""
    config = read_ai_config()
    key = (config.get("openaiApiKey") or "").strip()
    if key:
        return key
    return (os.getenv("OPENAI_API_KEY") or "").strip() or None
