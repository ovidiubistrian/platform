"""
Security utilities for authentication and authorization.
"""
from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
import bcrypt
from fastapi import Depends, HTTPException, Query, Request, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from src.core.config import settings
from src.db.session import get_db
from src.models.user import User

# OAuth2 scheme
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="api/auth/login")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a hash.
    Supports both bcrypt and passlib formats.
    """
    if not hashed_password:
        return False
    
    # Try passlib first (handles $2b$ format)
    try:
        from passlib.context import CryptContext
        pwd_context = CryptContext(schemes=['bcrypt'], deprecated='auto')
        return pwd_context.verify(plain_password, hashed_password)
    except Exception:
        pass
    
    # Fallback to direct bcrypt
    try:
        # Convert to bytes and truncate to 72 bytes if necessary
        password_bytes = plain_password.encode('utf-8')
        if len(password_bytes) > 72:
            password_bytes = password_bytes[:72]
        
        # Convert hashed_password to bytes if it's a string
        if isinstance(hashed_password, str):
            hashed_password_bytes = hashed_password.encode('utf-8')
        else:
            hashed_password_bytes = hashed_password
        
        return bcrypt.checkpw(password_bytes, hashed_password_bytes)
    except Exception:
        return False


def get_password_hash(password: str) -> str:
    """Hash a password.
    Bcrypt has a 72-byte limit, so we truncate if necessary.
    """
    # Convert to bytes and truncate to 72 bytes if necessary
    password_bytes = password.encode('utf-8')
    if len(password_bytes) > 72:
        password_bytes = password_bytes[:72]
    
    # Generate salt and hash
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    
    # Return as string
    return hashed.decode('utf-8')


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token. Ensures payload is JSON-serializable and return is str."""
    to_encode = {k: (v if v is not None else "") for k, v in data.items()}
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode["exp"] = expire
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
    return encoded_jwt if isinstance(encoded_jwt, str) else encoded_jwt.decode("utf-8")


def decode_access_token(token: str) -> Optional[dict]:
    """Decode and verify a JWT token."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        return payload
    except JWTError:
        return None


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db)
) -> User:
    """Get the current authenticated staff user."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception

    # Customer tokens must not unlock staff endpoints. Legacy tokens
    # (no token_type claim) default to staff for backward compatibility.
    if (payload.get("token_type") or "staff") != "staff":
        raise credentials_exception

    user_id: str = payload.get("sub")
    if user_id is None:
        raise credentials_exception

    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated"
        )

    return user


async def get_current_customer(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
):
    """Get the current authenticated customer account.

    Customer tokens carry token_type='customer' so they can't be used on
    staff endpoints, and staff tokens can't be used here. Returns the
    Customer row (not the User table) — customers live in `customers`.
    """
    from src.models.customer import Customer
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    if payload.get("token_type") != "customer":
        raise credentials_exception
    customer_id = payload.get("sub")
    if not customer_id:
        raise credentials_exception
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if customer is None or not customer.password_hash:
        raise credentials_exception
    return customer


async def get_current_active_user(
    current_user: User = Depends(get_current_user)
) -> User:
    """Get the current active user."""
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated"
        )
    return current_user


async def get_current_waiter_browser(
    request: Request,
    access_token: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
) -> User:
    """
    Auth dependency for browser-opened read-only endpoints (receipt.html,
    receipt.pdf, etc). Accepts the JWT from either:
      - Authorization: Bearer <token> header (regular API client), OR
      - ?access_token=<token> query param (window.open flow — the header
        can't ride along when a user clicks a link).
    Enforces the same role gate as require_restaurant_waiter.
    """
    token: Optional[str] = None
    auth = request.headers.get("authorization") or request.headers.get("Authorization")
    if auth and auth.lower().startswith("bearer "):
        token = auth.split(None, 1)[1].strip()
    if not token and access_token:
        token = access_token
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    payload = decode_access_token(token)
    if payload is None or (payload.get("token_type") or "staff") != "staff":
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    user = db.query(User).filter(User.id == user_id).first()
    if user is None or not user.is_active:
        raise HTTPException(status_code=401, detail="Could not validate credentials")
    if user.role not in ["super_admin", "tenant_admin", RESTAURANT_ROLE_WAITER]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires waiter, tenant_admin or super_admin role",
        )
    return user


def require_role(required_role: str):
    """Dependency to require a specific role."""
    async def role_checker(current_user: User = Depends(get_current_active_user)) -> User:
        if current_user.role != required_role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires {required_role} role"
            )
        return current_user
    return role_checker


def require_super_admin(current_user: User = Depends(get_current_active_user)) -> User:
    """Dependency to require super_admin role."""
    if current_user.role != "super_admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires super_admin role"
        )
    return current_user


def require_owner(current_user: User = Depends(require_super_admin)) -> User:
    """Dependency to restrict to the platform owner (single person).

    Gated by the `OWNER_EMAIL` env var. Returns 404 rather than 403 so
    the existence of owner-only routes isn't advertised to other
    super-admins. Fails closed: if `OWNER_EMAIL` is unset, no-one is the
    owner.
    """
    import os as _os
    owner_email = (_os.getenv("OWNER_EMAIL") or "").strip().lower()
    user_email = (current_user.email or "").strip().lower()
    if not owner_email or user_email != owner_email:
        raise HTTPException(status_code=404, detail="Not found")
    return current_user


def require_tenant_admin(current_user: User = Depends(get_current_active_user)) -> User:
    """Dependency to require tenant_admin role."""
    if current_user.role not in ["super_admin", "tenant_admin"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires tenant_admin or super_admin role"
        )
    return current_user


def require_housekeeper(current_user: User = Depends(get_current_active_user)) -> User:
    """Dependency to require housekeeper access — housekeepers themselves
    plus tenant admins (for debugging) plus super admins (for support)."""
    if current_user.role not in ["super_admin", "tenant_admin", "housekeeper"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires housekeeper, tenant_admin or super_admin role"
        )
    return current_user


# Restaurant staff roles — scoped so an ospătar can only touch POS
# flows and a bucătar only KDS. Tenant + super admin always allowed for
# support/debug.

RESTAURANT_ROLE_WAITER = "waiter"
RESTAURANT_ROLE_COOK = "cook"


def require_restaurant_waiter(current_user: User = Depends(get_current_active_user)) -> User:
    """POS / orders CRUD. Lets ospătari touch orders and payments but
    keeps them out of reports/inventory/fiscal/delivery settings."""
    if current_user.role not in ["super_admin", "tenant_admin", RESTAURANT_ROLE_WAITER]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires waiter, tenant_admin or super_admin role",
        )
    return current_user


# --- Sprint 10: POS desktop hybrid auth ----------------------------------
#
# POS desktop tokens carry token_type="pos_device" so the backend can tell
# them apart from staff tokens (no claim) and customer tokens
# ("customer"). To keep the existing /api/pos/* routes working from both
# the web admin (staff JWT) AND the desktop (pos_device JWT) we introduce a
# hybrid dependency that accepts EITHER, then chain a role gate.

TOKEN_TYPE_POS_DEVICE = "pos_device"


async def get_current_pos_or_staff_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """Resolve a JWT issued for either the web admin (staff) OR the POS
    desktop (pos_device). Customer tokens are explicitly rejected."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_access_token(token)
    if payload is None:
        raise credentials_exception
    token_type = payload.get("token_type") or "staff"
    if token_type not in ("staff", TOKEN_TYPE_POS_DEVICE):
        raise credentials_exception
    user_id: str = payload.get("sub")
    if not user_id:
        raise credentials_exception
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise credentials_exception
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is deactivated",
        )
    return user


# Roles allowed to operate the POS desktop. Cashier kept as opt-in for
# tenants that split waiter / cashier; falls back to waiter behaviour.
POS_DESKTOP_ALLOWED_ROLES = {
    "super_admin",
    "tenant_admin",
    "manager",
    RESTAURANT_ROLE_WAITER,
    "cashier",
}


def require_pos_restaurant_waiter(
    current_user: User = Depends(get_current_pos_or_staff_user),
) -> User:
    """POS routes: same role surface as require_restaurant_waiter but
    accepts pos_device tokens too. Web admin clients keep working
    unchanged because staff tokens still pass through."""
    if current_user.role not in POS_DESKTOP_ALLOWED_ROLES:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires POS-eligible role (waiter/cashier/manager/admin)",
        )
    return current_user


def require_pos_or_staff_admin(
    current_user: User = Depends(get_current_pos_or_staff_user),
) -> User:
    """Admin-only routes that must work from BOTH the web admin (staff
    JWT) AND a POS-desktop / web-POS shell (pos_device JWT). Use for
    settings an admin needs to fix without bouncing to a separate browser
    tab — kitchen-printer config, fiscal-bridge admin endpoints, etc.

    Sprint 11.10 — added because tenant admins logged into the POS
    couldn't save printer config: their token was pos_device and
    require_tenant_admin only accepts staff."""
    if current_user.role not in ("super_admin", "tenant_admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires tenant_admin or super_admin role",
        )
    return current_user


def require_restaurant_kitchen(current_user: User = Depends(get_current_active_user)) -> User:
    """KDS endpoints. Waiters can peek (so they see when food is ready)
    but cooks are the primary users."""
    if current_user.role not in [
        "super_admin",
        "tenant_admin",
        RESTAURANT_ROLE_WAITER,
        RESTAURANT_ROLE_COOK,
    ]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Requires kitchen staff, waiter, tenant_admin or super_admin role",
        )
    return current_user

