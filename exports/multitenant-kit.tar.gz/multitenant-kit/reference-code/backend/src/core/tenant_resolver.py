"""
Single place to resolve effective tenant identity for a request.
Used by tracing middleware so all logs have a consistent tenant_id / tenant_slug.
"""
from __future__ import annotations

from typing import Optional


def _tenant_from_host(host: Optional[str], main_domain: Optional[str]) -> Optional[str]:
    """
    Extract tenant slug from host when using subdomain-based tenancy.
    e.g. pine-hill.myapp.com with main_domain=myapp.com -> pine-hill.
    """
    if not host or not main_domain:
        return None
    host = host.strip().lower().split(":")[0]  # strip port
    main = main_domain.strip().lower()
    if not host or not main or host == main:
        return None
    if host.endswith("." + main):
        prefix = host[: -(len(main) + 1)]
        if prefix:
            return prefix  # e.g. "pine-hill" or "www.pine-hill"
    return None


def resolve_tenant_id(
    *,
    request_state_tenant: Optional[str] = None,
    x_tenant_id: Optional[str] = None,
    x_tenant: Optional[str] = None,
    host: Optional[str] = None,
    main_domain: Optional[str] = None,
    path: str = "",
    query_tenant_slug: Optional[str] = None,
    authorization: Optional[str] = None,
    secret_key: str = "",
    algorithm: str = "HS256",
) -> str:
    """
    Resolve effective tenant_id / tenant_slug for the current request.
    Order:
      1) request.state.tenant (if set by app)
      2) X-Tenant-Id or X-Tenant header
      3) path (/api/super-admin -> super_admin)
      4) JWT claims (tenant_id, or role=super_admin)
      5) query tenant_slug / domain
      6) host subdomain (e.g. pine-hill.myapp.com -> pine-hill)
    Returns: tenant slug/id, "super_admin", or "unknown".
    """
    # 1) request.state.tenant (e.g. set by auth dependency)
    if request_state_tenant and str(request_state_tenant).strip():
        return str(request_state_tenant).strip()

    # 2) Explicit headers (frontend or gateway)
    for h in (x_tenant_id, x_tenant):
        if h and str(h).strip():
            return str(h).strip()

    # 3) Path-based: super-admin routes
    if path.strip().startswith("/api/super-admin"):
        return "super_admin"

    # 4) JWT: decode without DB for logging context only
    if authorization and secret_key:
        try:
            token = None
            if isinstance(authorization, str) and authorization.lower().startswith("bearer "):
                token = authorization[7:].strip()
            if token:
                from jose import jwt, JWTError
                payload = jwt.decode(token, secret_key, algorithms=[algorithm])
                role = (payload.get("role") or "").strip()
                if role == "super_admin":
                    return "super_admin"
                tid = payload.get("tenant_id")
                if tid is not None and str(tid).strip():
                    return str(tid).strip()
        except Exception:
            pass

    # 5) Query param tenant_slug / domain (public API)
    if query_tenant_slug and str(query_tenant_slug).strip():
        return str(query_tenant_slug).strip()

    # 6) Host subdomain (e.g. pine-hill.myapp.com -> pine-hill)
    from_host = _tenant_from_host(host, main_domain)
    if from_host:
        return from_host

    return "unknown"
