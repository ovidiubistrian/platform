"""Per-tenant Stripe webhook for guest-booking payments.

Each tenant configures their own Stripe account in
`site_configs.stripe_config` and creates a webhook in their own Stripe
Dashboard pointing at:

    POST /api/webhooks/booking-stripe/{tenant_id}

The tenant_id in the URL path tells the backend which tenant's
webhookSecret to use for signature verification — this avoids the
chicken-and-egg of needing the secret to know who signed the body.
This endpoint is completely separate from the platform subscription
webhook (`/api/webhooks/stripe`) which lives in `webhooks.py` and uses
the global STRIPE_WEBHOOK_SECRET env var.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException, Request, status
from sqlalchemy.orm import Session

from src.db.session import get_db
from src.models.booking import Booking
from src.models.property import Property
from src.models.tenant import Tenant
from src.services.tenant_stripe import get_tenant_stripe_config
from src.services.meta_capi_service import (
    resolve_meta_config_for_tenant,
    send_purchase_for_booking,
)

try:
    import stripe

    STRIPE_AVAILABLE = True
except ImportError:  # pragma: no cover
    stripe = None
    STRIPE_AVAILABLE = False

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post("/booking-stripe/{tenant_id}")
async def booking_stripe_webhook(
    tenant_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
    stripe_signature: Optional[str] = Header(None, alias="stripe-signature"),
    db: Session = Depends(get_db),
):
    """Handle a Stripe webhook for a single tenant's booking payments.

    Returns 200 even on local processing errors so Stripe doesn't retry
    indefinitely; logs the failure for debugging instead.
    """
    body = await request.body()

    cfg = get_tenant_stripe_config(tenant_id, db)
    if not cfg:
        logger.warning("Booking webhook for tenant %s rejected: no stripe config", tenant_id)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant has no Stripe configuration",
        )

    if not STRIPE_AVAILABLE:
        logger.error("Stripe library not available; cannot verify booking webhook")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Stripe unavailable")

    try:
        event = stripe.Webhook.construct_event(  # type: ignore[union-attr]
            payload=body,
            sig_header=stripe_signature or "",
            secret=cfg["webhook_secret"],
        )
    except ValueError as exc:
        logger.warning("Booking webhook for tenant %s: bad payload: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid payload")
    except stripe.error.SignatureVerificationError as exc:  # type: ignore[union-attr]
        logger.warning("Booking webhook for tenant %s: signature verification failed: %s", tenant_id, exc)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid signature")

    event_type = event.get("type")
    obj = (event.get("data") or {}).get("object") or {}

    try:
        if event_type == "checkout.session.completed":
            _handle_checkout_completed(db, tenant_id, obj, background_tasks)
        elif event_type == "checkout.session.expired":
            _handle_checkout_expired(db, tenant_id, obj)
        elif event_type == "payment_intent.payment_failed":
            _handle_payment_failed(db, tenant_id, obj)
        else:
            logger.info("Booking webhook for tenant %s: ignoring event type %s", tenant_id, event_type)
    except Exception as exc:
        logger.exception("Booking webhook handler crashed for tenant %s: %s", tenant_id, exc)
        return {"received": True, "processed": False}

    return {"received": True}


def _handle_checkout_completed(
    db: Session,
    tenant_id: str,
    session_obj: dict,
    background_tasks: BackgroundTasks,
) -> None:
    """Mark the booking as paid when Stripe confirms the checkout session,
    then schedule the (deferred) invoice + confirmation email task. The
    task is the same one that runs immediately for bank-transfer bookings;
    it picks up the new advance_paid=True state from the DB and sends a
    "rezervare confirmată / plătit cu cardul" variant of the email.

    Idempotent: re-processing the same session detects the booking is
    already confirmed and skips re-scheduling the task.
    """
    metadata = session_obj.get("metadata") or {}
    # Route restaurant-order payments to their dedicated handler. Same
    # webhook endpoint, same per-tenant Stripe keys, different object.
    # Pay-at-the-table QR sessions carry a comma-separated list of IDs
    # (a single checkout can settle multiple open orders on the same
    # table); fall back to the singular key for online-delivery orders.
    restaurant_order_ids_raw = (metadata.get("restaurant_order_ids") or "").strip()
    if restaurant_order_ids_raw:
        for oid in [x.strip() for x in restaurant_order_ids_raw.split(",") if x.strip()]:
            _handle_restaurant_order_paid(db, tenant_id, session_obj, oid)
        return
    restaurant_order_id = (metadata.get("restaurant_order_id") or "").strip()
    if restaurant_order_id:
        _handle_restaurant_order_paid(db, tenant_id, session_obj, restaurant_order_id)
        return

    booking_id = (metadata.get("booking_id") or "").strip()
    session_id = (session_obj.get("id") or "").strip()
    payment_status = (session_obj.get("payment_status") or "").lower()

    if not booking_id:
        logger.warning("checkout.session.completed for tenant %s missing booking_id metadata", tenant_id)
        return
    if payment_status not in ("paid", "no_payment_required"):
        logger.info(
            "checkout.session.completed for booking %s ignored (payment_status=%s)",
            booking_id,
            payment_status,
        )
        return

    booking = (
        db.query(Booking)
        .filter(Booking.id == booking_id, Booking.tenant_id == tenant_id)
        .first()
    )
    if not booking:
        logger.warning("checkout.session.completed: booking %s not found for tenant %s", booking_id, tenant_id)
        return

    already_processed = booking.advance_paid and booking.status == "confirmed"
    booking.advance_paid = True
    booking.status = "confirmed"
    if session_id and not booking.stripe_checkout_session_id:
        booking.stripe_checkout_session_id = session_id
    pi_id = session_obj.get("payment_intent")
    if isinstance(pi_id, str) and pi_id:
        booking.stripe_payment_intent_id = pi_id
    booking.updated_at = datetime.utcnow()
    db.commit()
    logger.info("Booking %s marked as paid via Stripe Checkout session %s", booking_id, session_id)

    if not already_processed:
        # Defer invoice generation + confirmation/admin emails until now,
        # so the guest only ever receives the email after the card has
        # actually been charged.
        from src.api.public_bookings import create_invoice_and_send_booking_confirmation_task

        background_tasks.add_task(
            create_invoice_and_send_booking_confirmation_task,
            booking.id,
            tenant_id,
            float(booking.advance_required or 0),
        )
        logger.info("Booking %s: scheduled invoice+confirmation task after Stripe payment", booking_id)

        # Booking confirmation SMS — fire after Stripe payment confirms.
        async def _send_stripe_paid_sms(booking_id_local: str, tenant_id_local: str):
            from src.db.base import SessionLocal
            from src.services.sms_service import SMSService
            from src.models.booking import Booking as BookingModel
            sms = SMSService()
            db_local = SessionLocal()
            try:
                bk = db_local.query(BookingModel).filter(BookingModel.id == booking_id_local).first()
                if not bk:
                    return
                try:
                    await sms.send_booking_notification_to_tenant(tenant_id_local, bk, db_local)
                except Exception as e:
                    logger.warning("Booking %s: SMS admin failed: %s", booking_id_local, e)
                try:
                    await sms.send_booking_notification_to_client(tenant_id_local, bk, db_local)
                except Exception as e:
                    logger.warning("Booking %s: SMS client failed: %s", booking_id_local, e)
            finally:
                db_local.close()
        background_tasks.add_task(_send_stripe_paid_sms, booking.id, tenant_id)
        logger.info("Booking %s: scheduled booking_created SMS after Stripe payment", booking_id)

        # Meta Conversions API — server-side Purchase, enabled per-tenant
        # via admin → Tracking settings. Runs in a background task so
        # Stripe webhook latency is unaffected and a Meta outage cannot
        # delay the 200 OK back to Stripe.
        try:
            tenant_row = db.query(Tenant).filter(Tenant.id == tenant_id).first()
            meta_cfg = resolve_meta_config_for_tenant(tenant_row, db=db)
            if tenant_row and meta_cfg:
                if booking.property_id and not getattr(booking, "property", None):
                    booking.property = db.query(Property).filter(Property.id == booking.property_id).first()
                background_tasks.add_task(
                    send_purchase_for_booking,
                    booking,
                    config=meta_cfg,
                    tenant_slug=tenant_row.slug,
                    event_source_url=None,
                )
                logger.info("Booking %s: scheduled Meta CAPI Purchase event", booking_id)
        except Exception as exc:
            logger.exception("Booking %s: failed to schedule Meta CAPI Purchase: %s", booking_id, exc)


def _handle_checkout_expired(db: Session, tenant_id: str, session_obj: dict) -> None:
    """Soft-cancel the booking if the guest abandoned Stripe Checkout."""
    metadata = session_obj.get("metadata") or {}
    booking_id = (metadata.get("booking_id") or "").strip()
    if not booking_id:
        return

    booking = (
        db.query(Booking)
        .filter(Booking.id == booking_id, Booking.tenant_id == tenant_id)
        .first()
    )
    if not booking or booking.advance_paid:
        return
    if booking.status == "pending":
        booking.status = "cancelled"
        booking.updated_at = datetime.utcnow()
        db.commit()
        logger.info("Booking %s cancelled after Stripe checkout expired", booking_id)


def _handle_payment_failed(db: Session, tenant_id: str, intent_obj: dict) -> None:
    metadata = intent_obj.get("metadata") or {}
    booking_id = (metadata.get("booking_id") or "").strip()
    if booking_id:
        logger.warning("Payment intent failed for booking %s (tenant %s)", booking_id, tenant_id)


def _handle_restaurant_order_paid(
    db: Session,
    tenant_id: str,
    session_obj: dict,
    restaurant_order_id: str,
) -> None:
    """Stripe has confirmed payment for an online restaurant order. Mark
    it paid, record the payment row, and send the order to the kitchen
    (it was parked in draft during checkout so the cook wouldn't start
    cooking on an unpaid basket)."""
    from src.models.restaurant import Restaurant, RestaurantOrder
    from src.services import restaurant_order_service as order_service

    payment_status = (session_obj.get("payment_status") or "").lower()
    if payment_status not in ("paid", "no_payment_required"):
        logger.info(
            "restaurant_order %s: checkout ignored (payment_status=%s)",
            restaurant_order_id,
            payment_status,
        )
        return

    order = (
        db.query(RestaurantOrder)
        .filter(RestaurantOrder.id == restaurant_order_id, RestaurantOrder.tenant_id == tenant_id)
        .first()
    )
    if not order:
        logger.warning("restaurant_order %s not found for tenant %s", restaurant_order_id, tenant_id)
        return
    # Dedupe on webhook replay: the session id already recorded as a
    # payment means we've processed this one.
    session_id = (session_obj.get("id") or "").strip()
    if any(p.reference == session_id for p in order.payments):
        return

    amount_total = session_obj.get("amount_total")
    amount = float(amount_total) / 100.0 if amount_total is not None else float(order.total or 0)
    pi_id = session_obj.get("payment_intent")

    # The checkout creator stamps a "payment_method" on the session
    # metadata to tell reports apart (stripe vs stripe_online for the
    # QR-table-settle flow). Default to "stripe" for back-compat with
    # sessions created before this field existed.
    metadata = session_obj.get("metadata") or {}
    payment_method = (metadata.get("payment_method") or "stripe").strip() or "stripe"

    try:
        order_service.add_payment(
            db,
            order=order,
            method=payment_method,
            amount=amount,
            stripe_payment_intent_id=pi_id if isinstance(pi_id, str) else None,
            reference=session_id or None,
        )
        restaurant = db.query(Restaurant).filter(Restaurant.id == order.restaurant_id).first()
        if restaurant and order.status == "draft" and order.items:
            order_service.send_to_kitchen(db, order=order, restaurant=restaurant)
        # If this session was created via a payment-link the waiter
        # dispatched over SMS/email, stamp it paid on the audit row
        # so the POS delivery panel shows "plătit" instead of "sent".
        # Non-fatal — the source of truth is order.payments.
        try:
            from src.services import payment_link_service
            payment_link_service.mark_paid_by_session(db, session_id)
        except Exception as exc:  # pragma: no cover
            logger.warning("payment_link mark_paid failed: %s", exc)
        db.commit()
    except Exception as exc:
        logger.exception("Failed to finalise restaurant order %s: %s", restaurant_order_id, exc)
        db.rollback()
