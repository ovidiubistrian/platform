"""
Webhooks API routes.
Matches: app/api/webhooks/** endpoints
"""
from fastapi import APIRouter, Request, HTTPException, status, Header, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from datetime import datetime, timedelta
import json
import logging
import uuid

from src.db.session import get_db
from src.core.config import settings
from src.core.billing_secrets import decrypt_billing_secret
from src.models.tenant import Tenant
from src.models.user import User
from src.models.subscription_plan import SubscriptionPlan
from src.models.legal_entity import LegalEntity
from src.models.billing_integration import BillingInvoiceIdempotency
from src.providers.billing import OblioProvider

try:
    import stripe
    STRIPE_AVAILABLE = True
except ImportError:
    stripe = None
    STRIPE_AVAILABLE = False

router = APIRouter()
logger = logging.getLogger(__name__)

PLATFORM_OBLIO_CONFIG_KEY = "platform_oblio_config"


def _ensure_system_config_table(db: Session) -> None:
    db.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS system_configs (
                key VARCHAR PRIMARY KEY,
                value TEXT NULL,
                updated_at TIMESTAMP DEFAULT NOW() NOT NULL
            )
            """
        )
    )
    db.commit()


def _get_system_config_json(db: Session, key: str) -> dict:
    _ensure_system_config_table(db)
    row = db.execute(text("SELECT value FROM system_configs WHERE key = :key"), {"key": key}).first()
    if not row or not row[0]:
        return {}
    try:
        parsed = json.loads(row[0]) if isinstance(row[0], str) else row[0]
        return parsed if isinstance(parsed, dict) else {}
    except Exception:
        return {}


def _get_platform_oblio_config(db: Session) -> dict:
    raw = _get_system_config_json(db, PLATFORM_OBLIO_CONFIG_KEY)
    encrypted_secret = (raw.get("oblio_client_secret_encrypted") or "").strip()
    secret = ""
    if encrypted_secret:
        try:
            secret = decrypt_billing_secret(encrypted_secret)
        except Exception:
            secret = ""
    return {
        "status": (raw.get("status") or "disconnected").strip() or "disconnected",
        "oblio_client_id": (raw.get("oblio_client_id") or "").strip() or None,
        "oblio_client_secret": secret,
        "selected_company_cif": (raw.get("selected_company_cif") or "").strip() or None,
        "default_invoice_series": (raw.get("default_invoice_series") or "").strip() or None,
        "invoice_product_name": (raw.get("invoice_product_name") or "").strip() or None,
        "default_vat_percentage": (raw.get("default_vat_percentage") or "").strip() or None,
    }


def _vat_name(vat_percentage: int) -> str:
    if vat_percentage in (5, 9, 11):
        return "Redusa"
    if vat_percentage in (19, 21):
        return "Normala"
    return "Exempta"


async def _emit_platform_oblio_invoice(
    db: Session,
    tenant_id: str,
    plan: Optional[SubscriptionPlan],
    amount: float,
    interval: str,
    idempotency_key: str,
) -> Optional[dict]:
    """Shared helper: emit a platform Oblio invoice for a tenant subscription
    payment. Used for both first purchase (checkout.session.completed) and
    recurring renewals (invoice.payment_succeeded). Idempotent on
    idempotency_key."""
    if amount <= 0:
        logger.warning("Oblio invoice skipped: amount=0 for tenant %s", tenant_id)
        return None

    platform_cfg = _get_platform_oblio_config(db)
    if (
        platform_cfg.get("status") != "connected"
        or not platform_cfg.get("oblio_client_id")
        or not platform_cfg.get("oblio_client_secret")
        or not platform_cfg.get("selected_company_cif")
        or not platform_cfg.get("default_invoice_series")
    ):
        logger.warning("Oblio invoice skipped: platform Oblio not configured")
        return None

    existing = (
        db.query(BillingInvoiceIdempotency)
        .filter(
            BillingInvoiceIdempotency.tenant_id == tenant_id,
            BillingInvoiceIdempotency.provider == "platform_oblio_purchase",
            BillingInvoiceIdempotency.idempotency_key == idempotency_key,
        )
        .first()
    )
    if existing:
        return {
            "seriesName": existing.oblio_series_name,
            "number": existing.oblio_number,
            "deduped": True,
        }

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        return None
    legal = db.query(LegalEntity).filter(LegalEntity.tenant_id == tenant_id).first()
    admin_user = (
        db.query(User)
        .filter(
            User.tenant_id == tenant_id,
            User.role.in_(["admin", "tenant_admin"]),
        )
        .order_by(User.created_at.asc())
        .first()
    )

    try:
        vat_percentage = int(str(platform_cfg.get("default_vat_percentage") or "19"))
    except ValueError:
        vat_percentage = 19

    interval_ro = "lunar" if interval != "yearly" else "anual"
    plan_name = plan.name if plan else "360Booking"
    product_name = platform_cfg.get("invoice_product_name") or (
        f"Abonament 360Booking {plan_name} ({interval_ro})"
    )
    product_description = f"Abonament 360Booking {plan_name} - {interval_ro}"

    client_payload = {
        "name": (legal.name if legal else tenant.name) or "Tenant 360Booking",
        "email": (legal.email if legal else (admin_user.email if admin_user else None)),
        "phone": legal.phone if legal else None,
        "address": legal.address if legal else None,
        "city": legal.city if legal else None,
        "country": legal.country if legal else "Romania",
    }
    if legal and legal.cui:
        # Oblio uses `cif` for CUI/CIF (and CNP for individuals); `code`
        # is silently ignored, which leaves "CIF: -" on the rendered PDF.
        client_payload["cif"] = legal.cui
    client_payload = {k: v for k, v in client_payload.items() if v}

    payload = {
        "issueDate": datetime.utcnow().strftime("%Y-%m-%d"),
        "client": client_payload,
        # Tell Oblio to email the PDF straight to client.email after issuing.
        "sendEmail": 1,
        "products": [
            {
                "name": product_name,
                "description": product_description,
                "quantity": 1,
                "price": str(round(amount, 2)),
                "measuringUnit": "buc",
                "productType": "Serviciu",
                "vatName": _vat_name(vat_percentage),
                "vatPercentage": vat_percentage,
                "vatIncluded": True,
            }
        ],
    }

    provider = OblioProvider(tenant_id="platform")
    result = await provider.create_invoice(
        {
            "client_id": platform_cfg["oblio_client_id"],
            "client_secret": platform_cfg["oblio_client_secret"],
            "company_cif": platform_cfg["selected_company_cif"],
            "default_invoice_series": platform_cfg["default_invoice_series"],
        },
        payload,
        idempotency_key=idempotency_key,
    )
    db.add(
        BillingInvoiceIdempotency(
            id=str(uuid.uuid4()),
            tenant_id=tenant_id,
            provider="platform_oblio_purchase",
            idempotency_key=idempotency_key,
            oblio_series_name=result.get("seriesName"),
            oblio_number=result.get("number"),
        )
    )
    db.commit()
    return result


async def _handle_addon_checkout_completed(db: Session, session_obj: dict) -> None:
    """Handle checkout.session.completed for an add-on purchase. The session
    metadata carries tenant_id + addon_package_id. Idempotent via the
    (tenant_id, provider='stripe_addon', idempotency_key=session_id) row
    in billing_invoice_idempotency."""
    metadata = session_obj.get("metadata") or {}
    tenant_id = str(metadata.get("tenant_id") or session_obj.get("client_reference_id") or "").strip()
    addon_package_id = str(metadata.get("addon_package_id") or "").strip()
    checkout_session_id = str(session_obj.get("id") or "").strip()

    if not tenant_id or not addon_package_id:
        return

    payment_status = str(session_obj.get("payment_status") or "").lower()
    if payment_status not in ("paid", "no_payment_required"):
        return

    # Dedupe — don't grant twice on webhook replay.
    if checkout_session_id:
        dedupe = (
            db.query(BillingInvoiceIdempotency)
            .filter(
                BillingInvoiceIdempotency.tenant_id == tenant_id,
                BillingInvoiceIdempotency.provider == "stripe_addon",
                BillingInvoiceIdempotency.idempotency_key == checkout_session_id,
            )
            .first()
        )
        if dedupe:
            return

    from src.services import addon_service

    try:
        addon = addon_service.grant(
            db,
            tenant_id=tenant_id,
            addon_package_id=addon_package_id,
            notes=f"stripe_checkout_{checkout_session_id}",
        )
        db.add(
            BillingInvoiceIdempotency(
                id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                provider="stripe_addon",
                idempotency_key=checkout_session_id or f"addon_{addon.id}",
            )
        )
        db.commit()
    except Exception as e:
        logger.exception("Failed to grant add-on for session %s: %s", checkout_session_id, e)
        db.rollback()


async def _handle_addon_invoice_payment_succeeded(
    db: Session,
    invoice_obj: dict,
    sub_metadata: dict,
) -> None:
    """Recurring-renewal path for business_email subscriptions. Extends
    expires_at by 30 days on each paid invoice."""
    billing_reason = str(invoice_obj.get("billing_reason") or "").lower()
    # On subscription_create we already handled it via checkout.session.completed.
    if billing_reason == "subscription_create":
        return

    tenant_id = (sub_metadata.get("tenant_id") or "").strip()
    addon_package_id = (sub_metadata.get("addon_package_id") or "").strip()
    if not tenant_id or not addon_package_id:
        return

    stripe_invoice_id = str(invoice_obj.get("id") or "").strip()
    if stripe_invoice_id:
        dedupe = (
            db.query(BillingInvoiceIdempotency)
            .filter(
                BillingInvoiceIdempotency.tenant_id == tenant_id,
                BillingInvoiceIdempotency.provider == "stripe_addon_renew",
                BillingInvoiceIdempotency.idempotency_key == stripe_invoice_id,
            )
            .first()
        )
        if dedupe:
            return

    from src.services import addon_service

    try:
        addon_service.renew_business_email(db, tenant_id=tenant_id, addon_package_id=addon_package_id)
        db.add(
            BillingInvoiceIdempotency(
                id=str(uuid.uuid4()),
                tenant_id=tenant_id,
                provider="stripe_addon_renew",
                idempotency_key=stripe_invoice_id or f"renew_{addon_package_id}_{datetime.utcnow().isoformat()}",
            )
        )
        db.commit()
    except Exception as e:
        logger.exception("Failed to renew business_email for invoice %s: %s", stripe_invoice_id, e)
        db.rollback()


async def _handle_checkout_session_completed(db: Session, session_obj: dict) -> None:
    metadata = session_obj.get("metadata") or {}
    # Route add-on purchases to a separate handler.
    if (metadata.get("addon_package_id") or "").strip():
        await _handle_addon_checkout_completed(db, session_obj)
        return

    tenant_id = str(metadata.get("tenant_id") or session_obj.get("client_reference_id") or "").strip()
    plan_id = str(metadata.get("plan_id") or "").strip()
    interval = str(metadata.get("interval") or "monthly").strip().lower()
    checkout_session_id = str(session_obj.get("id") or "").strip()

    if not tenant_id:
        logger.warning("Stripe webhook checkout.session.completed without tenant_id")
        return

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        logger.warning("Stripe webhook tenant not found: %s", tenant_id)
        return

    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first() if plan_id else None
    if plan:
        tenant.subscription_plan = plan.name
    tenant.subscription_ends_at = datetime.utcnow() + timedelta(days=365 if interval == "yearly" else 30)
    # Successful payment — tenant is clean again. Reset the postpone
    # counter and close any pending extension request as approved-by-payment.
    try:
        from src.services.access_control import reset_post_expiry_counter
        from src.models.payment_extension_request import (
            PaymentExtensionRequest,
            EXTENSION_STATUS_PENDING,
            EXTENSION_STATUS_APPROVED,
        )
        reset_post_expiry_counter(db, tenant, reason="stripe_checkout_paid")
        if tenant.status == "suspended":
            tenant.status = "active"
        pending = (
            db.query(PaymentExtensionRequest)
            .filter(
                PaymentExtensionRequest.tenant_id == tenant.id,
                PaymentExtensionRequest.status == EXTENSION_STATUS_PENDING,
            )
            .first()
        )
        if pending:
            pending.status = EXTENSION_STATUS_APPROVED
            pending.reviewed_at = datetime.utcnow()
            pending.response_notes = "auto-approved by Stripe payment"
    except Exception as e:
        logger.warning("Failed post-payment cleanup for tenant %s: %s", tenant_id, e)
    db.commit()

    if not checkout_session_id:
        return
    payment_status = str(session_obj.get("payment_status") or "").lower()
    if payment_status not in ("paid", "no_payment_required"):
        return

    amount_total = session_obj.get("amount_total")
    amount = float(amount_total) / 100.0 if amount_total is not None else 0.0
    if amount <= 0 and plan:
        amount = float(plan.yearly_price if interval == "yearly" else plan.monthly_price)

    await _emit_platform_oblio_invoice(
        db=db,
        tenant_id=tenant_id,
        plan=plan,
        amount=amount,
        interval=interval,
        idempotency_key=f"stripe_checkout_{checkout_session_id}",
    )


async def _handle_invoice_payment_succeeded(db: Session, invoice_obj: dict) -> None:
    """Handle Stripe `invoice.payment_succeeded` — emitted on every successful
    payment for a subscription, including the first one and all automatic
    renewals. To avoid double-invoicing on first purchase (which is already
    handled by checkout.session.completed), we skip events where
    billing_reason == 'subscription_create'."""
    billing_reason = str(invoice_obj.get("billing_reason") or "").lower()
    if billing_reason == "subscription_create":
        # First invoice — checkout.session.completed is the source of truth
        return

    stripe_invoice_id = str(invoice_obj.get("id") or "").strip()
    subscription_id = str(invoice_obj.get("subscription") or "").strip()
    if not stripe_invoice_id or not subscription_id:
        return

    payment_status = str(invoice_obj.get("status") or "").lower()
    if payment_status != "paid":
        return

    if not STRIPE_AVAILABLE:
        logger.warning("Stripe library unavailable; cannot process invoice.payment_succeeded")
        return

    stripe_key = (settings.STRIPE_SECRET_KEY or "").strip()
    if not stripe_key:
        logger.warning("STRIPE_SECRET_KEY empty; cannot retrieve subscription metadata")
        return
    stripe.api_key = stripe_key

    # Pull subscription to get metadata (tenant_id, plan_id, interval). We
    # populate subscription metadata at checkout time in subscriptions.py.
    try:
        sub = stripe.Subscription.retrieve(subscription_id)
    except Exception as e:
        logger.warning("Failed to retrieve Stripe subscription %s: %s", subscription_id, e)
        return

    sub_metadata = dict(sub.get("metadata") or {}) if isinstance(sub, dict) else dict(getattr(sub, "metadata", {}) or {})
    # Add-on (business_email) renewals carry addon_package_id — route them
    # to the dedicated handler that extends expires_at instead of the
    # subscription-plan renewal logic below.
    if (sub_metadata.get("addon_package_id") or "").strip():
        await _handle_addon_invoice_payment_succeeded(db, invoice_obj, sub_metadata)
        return

    tenant_id = (sub_metadata.get("tenant_id") or "").strip()
    plan_id = (sub_metadata.get("plan_id") or "").strip()
    interval = (sub_metadata.get("interval") or "").strip().lower()

    # Fallback: infer interval from the Stripe price recurring.interval
    if not interval:
        try:
            items = sub["items"]["data"] if isinstance(sub, dict) else sub.items.data
            if items:
                recurring = items[0]["price"].get("recurring") if isinstance(items[0], dict) else items[0].price.recurring
                stripe_interval = (recurring or {}).get("interval") if isinstance(recurring, dict) else getattr(recurring, "interval", None)
                interval = "yearly" if stripe_interval == "year" else "monthly"
        except Exception:
            interval = "monthly"

    if not tenant_id:
        logger.warning("invoice.payment_succeeded: subscription %s has no tenant_id metadata", subscription_id)
        return

    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        logger.warning("invoice.payment_succeeded: tenant %s not found", tenant_id)
        return

    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first() if plan_id else None
    # Fallback: if no plan_id metadata, try to resolve by Stripe price id
    if not plan:
        try:
            items = sub["items"]["data"] if isinstance(sub, dict) else sub.items.data
            price_id = items[0]["price"]["id"] if isinstance(items[0], dict) else items[0].price.id
            plan = (
                db.query(SubscriptionPlan)
                .filter(
                    (SubscriptionPlan.stripe_monthly_price_id == price_id)
                    | (SubscriptionPlan.stripe_yearly_price_id == price_id)
                )
                .first()
            )
        except Exception:
            plan = None

    if plan:
        tenant.subscription_plan = plan.name
    tenant.subscription_ends_at = datetime.utcnow() + timedelta(days=365 if interval == "yearly" else 30)
    # Recurring renewal succeeded — reset the postpone counter.
    try:
        from src.services.access_control import reset_post_expiry_counter
        reset_post_expiry_counter(db, tenant, reason="stripe_invoice_paid")
        if tenant.status == "suspended":
            tenant.status = "active"
    except Exception as e:
        logger.warning("Failed post-renewal cleanup for tenant %s: %s", tenant_id, e)
    db.commit()

    amount_paid = invoice_obj.get("amount_paid")
    amount = float(amount_paid) / 100.0 if amount_paid is not None else 0.0
    if amount <= 0 and plan:
        amount = float(plan.yearly_price if interval == "yearly" else plan.monthly_price)

    await _emit_platform_oblio_invoice(
        db=db,
        tenant_id=tenant_id,
        plan=plan,
        amount=amount,
        interval=interval,
        idempotency_key=f"stripe_invoice_{stripe_invoice_id}",
    )


async def _handle_subscription_deleted(db: Session, sub_obj: dict) -> None:
    """Stripe `customer.subscription.deleted` — the subscription ended for
    good. We do NOT flip tenant.status to suspended here (that's too
    aggressive and can fire on legitimate downgrade/recreate flows). We
    only shorten subscription_ends_at to now so the access gate kicks in
    on next check and the tenant can re-subscribe. An admin who wants
    hard suspension can do so via the billing report."""
    metadata = dict(sub_obj.get("metadata") or {}) if isinstance(sub_obj, dict) else {}
    tenant_id = (metadata.get("tenant_id") or "").strip()
    # Skip add-on subscriptions — they have their own renewal path.
    if (metadata.get("addon_package_id") or "").strip():
        return
    if not tenant_id:
        return
    tenant = db.query(Tenant).filter(Tenant.id == tenant_id).first()
    if not tenant:
        return
    now = datetime.utcnow()
    if tenant.subscription_ends_at is None or tenant.subscription_ends_at > now:
        tenant.subscription_ends_at = now
    db.commit()


async def _handle_invoice_payment_failed(db: Session, invoice_obj: dict) -> None:
    """Stripe `invoice.payment_failed` — log for visibility. We do NOT
    suspend the tenant immediately; the access gate handles grace via
    post-expiry counter when subscription_ends_at eventually passes."""
    stripe_invoice_id = str(invoice_obj.get("id") or "").strip()
    subscription_id = str(invoice_obj.get("subscription") or "").strip()
    logger.warning(
        "Stripe invoice.payment_failed — invoice=%s subscription=%s",
        stripe_invoice_id,
        subscription_id,
    )


@router.post("/stripe")
async def stripe_webhook(
    request: Request,
    stripe_signature: Optional[str] = Header(None, alias="stripe-signature"),
    db: Session = Depends(get_db),
):
    """
    Handle Stripe webhooks.
    Matches: POST /api/webhooks/stripe
    """
    body = await request.body()
    try:
        event = None
        webhook_secret = (settings.STRIPE_WEBHOOK_SECRET or "").strip()
        if STRIPE_AVAILABLE and webhook_secret and stripe_signature:
            event = stripe.Webhook.construct_event(body, stripe_signature, webhook_secret)
        else:
            if webhook_secret and not stripe_signature:
                logger.warning("Stripe webhook signature missing while webhook secret is configured")
            event = json.loads(body.decode("utf-8") or "{}")

        event_type = event.get("type")
        event_data = (event.get("data") or {}).get("object") or {}

        if event_type == "checkout.session.completed":
            await _handle_checkout_session_completed(db, event_data)
        elif event_type in ("invoice.payment_succeeded", "invoice.paid"):
            await _handle_invoice_payment_succeeded(db, event_data)
        elif event_type == "customer.subscription.deleted":
            await _handle_subscription_deleted(db, event_data)
        elif event_type == "invoice.payment_failed":
            await _handle_invoice_payment_failed(db, event_data)
    except Exception as exc:
        logger.exception("Stripe webhook handling failed: %s", exc)
        # Do not return 500 to Stripe for non-critical local processing issues.
        return {"received": True, "processed": False}

    return {"received": True}


# Mailgun webhook handled by mailgun_webhooks.router (full implementation)


@router.post("/booking-com")
async def booking_com_webhook(
    request: Request,
    signature: Optional[str] = Header(None, alias="x-booking-signature")
):
    """
    Handle Booking.com webhooks.
    Matches: POST /api/webhooks/booking-com
    """
    # TODO: Implement Booking.com webhook signature verification
    body = await request.json()
    
    # For now, just acknowledge receipt
    return {"received": True}













