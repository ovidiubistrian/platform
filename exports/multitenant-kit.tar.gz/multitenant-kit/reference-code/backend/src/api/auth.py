"""
Authentication API routes.
Matches all endpoints from app/api/auth/** in Next.js
"""
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, Request, status, Query
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy.orm import Session
from typing import Optional

from src.db.session import get_db
from src.models.user import User
from src.schemas.user import (
    UserCreate, UserResponse, Token, RegisterRequest, RegisterResponse,
    ForgotPasswordRequest, ResetPasswordRequest, VerifyEmailRequest
)
from src.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    get_current_active_user,
)
from src.core.config import settings
from src.core.password_policy import check_password_strength, format_failures
from src.core.turnstile import verify_turnstile_token, extract_client_ip
from src.services.auth_service import AuthService

router = APIRouter()


@router.post("/register", response_model=RegisterResponse, status_code=status.HTTP_201_CREATED)
async def register(
    user_data: RegisterRequest,
    request: Request,
    db: Session = Depends(get_db)
):
    """
    Register a new user and create a tenant.
    Matches: POST /api/auth/register
    """
    if not verify_turnstile_token(user_data.turnstile_token, extract_client_ip(request)):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Verificarea anti-bot a eșuat. Reîncarcă pagina și încearcă din nou.",
        )
    password_check = check_password_strength(user_data.password)
    if not password_check.ok:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=format_failures(password_check),
        )
    try:
        user, tenant = await AuthService.register_user(
            db=db,
            name=user_data.name,
            email=user_data.email,
            password=user_data.password,
            business_name=user_data.business_name,
            business_type=user_data.business_type,
            rental_mode=user_data.rental_mode,
            sales_code=user_data.sales_code,
            product_type=user_data.product_type,
        )
        
        return RegisterResponse(
            message="Cont creat cu succes",
            user=UserResponse(
                id=user.id,
                email=user.email,
                name=user.name,
                role=user.role,
                tenant_id=user.tenant_id,
                is_active=user.is_active,
                email_verified=user.email_verified,
                created_at=user.created_at,
                updated_at=user.updated_at,
            ),
            tenant={
                "id": tenant.id,
                "name": tenant.name,
                "slug": tenant.slug,
            }
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"A apărut o eroare la crearea contului: {str(e)}"
        )


@router.post("/login")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    """
    Login endpoint. If user has 2FA enabled, returns requiresTwoFactor + sessionId instead of token.
    """
    from datetime import datetime
    try:
        normalized_email = (form_data.username or "").strip().lower()
        if not normalized_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email is required"
            )

        user = db.query(User).filter(User.email == normalized_email).first()

        if not user or not user.password:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )

        if not verify_password(form_data.password, user.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Account is deactivated"
            )

        # 2FA enabled: create session, send OTP, return redirect info (no token) — nu emitem token până la verificare cod
        two_factor_enabled = bool(getattr(user, "two_factor_enabled", False))
        if two_factor_enabled:
            try:
                session_id = await AuthService.create_two_factor_session(db, user)
            except Exception as e:
                import traceback
                traceback.print_exc()
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail="Trimiterea codului de verificare a eșuat. Verifică setările de email (Super Admin)."
                )
            return {
                "requiresTwoFactor": True,
                "sessionId": session_id,
                "message": "Cod de verificare trimis pe email",
            }

        # Normal login: create token
        user.last_login_at = datetime.utcnow()
        db.commit()

        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={
                "sub": user.id,
                "email": user.email,
                "role": user.role,
                "tenant_id": user.tenant_id or "",
            },
            expires_delta=access_token_expires
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user.id),
                "email": str(user.email),
                "name": user.name or "",
                "role": user.role or "tenant_admin",
                "tenant_id": user.tenant_id,
                "is_active": bool(user.is_active),
                "email_verified": bool(user.email_verified) if user.email_verified is not None else False,
                "two_factor_enabled": bool(getattr(user, "two_factor_enabled", False)),
                "must_change_password": bool(getattr(user, "must_change_password", False)),
                "created_at": user.created_at.isoformat() if user.created_at else None,
                "updated_at": user.updated_at.isoformat() if user.updated_at else None,
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


@router.post("/logout")
async def logout():
    """
    Logout endpoint (client-side token removal).
    Matches: POST /api/auth/logout
    """
    return {"message": "Logged out successfully"}


@router.post("/forgot-password")
async def forgot_password(
    request: ForgotPasswordRequest,
    db: Session = Depends(get_db)
):
    """
    Request password reset.
    Matches: POST /api/auth/forgot-password
    """
    try:
        await AuthService.forgot_password(db, request.email)
        # Always return success message (security - don't reveal if email exists)
        return {
            "message": "Dacă adresa de email există în sistem, vei primi un link de resetare a parolei"
        }
    except Exception as e:
        print(f"Error in forgot password: {e}")
        # Still return success for security
        return {
            "message": "Dacă adresa de email există în sistem, vei primi un link de resetare a parolei"
        }


@router.post("/reset-password")
async def reset_password(
    request: ResetPasswordRequest,
    db: Session = Depends(get_db)
):
    """
    Reset password with token.
    Matches: POST /api/auth/reset-password
    """
    password_check = check_password_strength(request.password)
    if not password_check.ok:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=format_failures(password_check),
        )
    try:
        user = AuthService.reset_password(db, request.token, request.password)
        return {
            "message": "Parola a fost resetată cu succes"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        print(f"Error in reset password: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Eroare internă"
        )


@router.post("/verify-email")
async def verify_email_post(
    request: VerifyEmailRequest,
    db: Session = Depends(get_db)
):
    """
    Verify email with token (POST).
    Matches: POST /api/auth/verify-email
    """
    try:
        user = AuthService.verify_email(db, request.token)
        return {
            "message": "Email verified successfully"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        print(f"Error verifying email: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@router.get("/verify-email")
async def verify_email_get(
    token: str = Query(..., description="Verification token"),
    db: Session = Depends(get_db)
):
    """
    Verify email with token (GET).
    Matches: GET /api/auth/verify-email?token=...
    """
    try:
        user = AuthService.verify_email(db, token)
        return {
            "message": "Email verified successfully"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        print(f"Error verifying email: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error"
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get current user information.
    Matches: GET /api/users/me or /api/auth/me
    """
    return UserResponse(
        id=current_user.id,
        email=current_user.email,
        name=current_user.name,
        role=current_user.role,
        tenant_id=current_user.tenant_id,
        is_active=current_user.is_active,
        email_verified=current_user.email_verified,
        two_factor_enabled=bool(getattr(current_user, "two_factor_enabled", False)),
        must_change_password=bool(getattr(current_user, "must_change_password", False)),
        created_at=current_user.created_at,
        updated_at=current_user.updated_at,
    )


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


@router.post("/change-password")
async def change_password(
    body: ChangePasswordRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Authenticated password change. Verifies the current password, sets the new
    one, and clears `must_change_password` (used by the forced first-login flow
    after a demo→client conversion)."""
    if not verify_password(body.current_password, current_user.password):
        raise HTTPException(status_code=400, detail="Parola actuală este greșită.")
    new_password = (body.new_password or "").strip()
    if len(new_password) < 8:
        raise HTTPException(status_code=400, detail="Parola nouă trebuie să aibă minim 8 caractere.")
    current_user.password = get_password_hash(new_password)
    current_user.must_change_password = False
    current_user.updated_at = datetime.utcnow()
    db.commit()
    return {"ok": True}


@router.post("/logout")
async def logout():
    """
    Logout endpoint (client-side token removal).
    Matches: POST /api/auth/logout
    """
    return {"message": "Logged out successfully"}


@router.get("/two-factor-session")
async def two_factor_session(
    sessionId: str = Query(..., description="2FA session ID"),
    db: Session = Depends(get_db),
):
    """Get pending 2FA session info (email for display)."""
    data = AuthService.get_two_factor_session(sessionId)
    if not data:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Sesiune invalidă sau expirată")
    return {"email": data["email"]}


@router.post("/verify-two-factor")
async def verify_two_factor(
    request: dict,  # { sessionId, verificationCode }
    db: Session = Depends(get_db),
):
    """Verify 2FA OTP and return token. Matches: POST /api/auth/verify-two-factor"""
    session_id = request.get("sessionId") or request.get("session_id")
    code = request.get("verificationCode") or request.get("verification_code") or ""
    if not session_id or not code:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="sessionId și codul sunt obligatorii")
    user = AuthService.verify_two_factor_and_consume(session_id, code, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cod invalid sau expirat")
    from datetime import datetime
    user.last_login_at = datetime.utcnow()
    db.commit()
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.id, "email": user.email, "role": user.role, "tenant_id": user.tenant_id or ""},
        expires_delta=access_token_expires,
    )
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": {
            "id": str(user.id),
            "email": str(user.email),
            "name": user.name or "",
            "role": user.role or "tenant_admin",
            "tenant_id": user.tenant_id,
            "is_active": bool(user.is_active),
            "email_verified": bool(user.email_verified) if user.email_verified is not None else False,
            "two_factor_enabled": bool(getattr(user, "two_factor_enabled", False)),
            "created_at": user.created_at.isoformat() if user.created_at else None,
            "updated_at": user.updated_at.isoformat() if user.updated_at else None,
        }
    }


@router.post("/send-verification")
async def send_verification(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """
    Send verification email to current user.
    Matches: POST /api/auth/send-verification
    """
    try:
        await AuthService.send_verification_email(db, current_user.id)
        return {
            "message": "Email de verificare trimis"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except Exception as e:
        print(f"Error sending verification email: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="A apărut o eroare la trimiterea email-ului de verificare"
        )

