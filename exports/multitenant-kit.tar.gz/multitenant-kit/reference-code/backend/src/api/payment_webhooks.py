"""Unified payment webhook entrypoint for Netopia + BT iPay + any future
redirect-style provider.

URL: POST /api/webhooks/payment/{provider}/{tenant_id}

The provider layer normalises the payload into:
    {type, session_id, order_ref, paid_amount_minor, currency, raw}

From `order_ref` we recover (kind, entity_id) — one of:
    restaurant_order, restaurant_table, booking

… and forward to the same handlers the existing Stripe webhook uses
(`_handle_restaurant_order_paid` / booking update flow), so we don't
fork the "mark paid + send kitchen / confirm booking / fire Meta CAPI"
business logic. Stripe keeps its dedicated webhook at
/api/webhooks/booking-stripe/{tenant_id} — simpler to leave that route
alone than to move a working integration.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
from sqlalchemy.orm import Session

from src.db.session import get_db
from src.services.payment_orchestrator import parse_order_ref
from src.services.payment_providers import get_provider, PaymentProviderError


logger = logging.getLogger(__name__)

router = APIRouter()


SIGNATURE_HEADER_CANDIDATES = (
    "Verification-Token",
    "Verification",
    "X-Signature",
    "Signature",
    "P-Sign",
)


def _extract_signature(request: Request) -> str:
    for name in SIGNATURE_HEADER_CANDIDATES:
        v = request.headers.get(name)
        if v:
            return v
    return ""


@router.post("/{provider}/{tenant_id}")
async def payment_webhook(
    provider: str,
    tenant_id: str,
    request: Request,
    background_tasks: BackgroundTasks,
):
    from fastapi import Depends
    from sqlalchemy.orm import Session as _Session

    db: _Session = next(get_db())
    try:
        body = await request.body()
        signature = _extract_signature(request)

        provider_obj = get_provider(tenant_id, provider, db)
        if not provider_obj:
            raise HTTPException(status_code=404, detail="Provider not configured for tenant")

        try:
            event = provider_obj.verify_webhook(body, signature)
        except PaymentProviderError as exc:
            logger.warning(
                "Webhook verification failed tenant=%s provider=%s: %s",
                tenant_id, provider, exc,
            )
            raise HTTPException(status_code=400, detail=str(exc))

        event_type = event.get("type") or ""
        order_ref = event.get("order_ref") or event.get("session_id") or ""
        kind, entity_id = parse_order_ref(order_ref)

        if event_type == "checkout.completed":
            if kind in ("restaurant_order", "restaurant_table"):
                _complete_restaurant_order(db, tenant_id, entity_id, event)
            elif kind == "booking":
                _complete_booking(db, tenant_id, entity_id, event, background_tasks)
            elif kind == "facility_booking":
                _complete_facility_booking(db, tenant_id, entity_id, event, background_tasks)
            else:
                logger.warning("Unknown kind %r in order_ref %r", kind, order_ref)
        elif event_type == "checkout.expired":
            if kind == "booking":
                _expire_booking(db, tenant_id, entity_id)
            elif kind == "facility_booking":
                _expire_facility_booking(db, tenant_id, entity_id)
            # restaurant orders stay in draft; waiter can close manually.
        elif event_type == "checkout.failed":
            logger.info("Payment failed: tenant=%s kind=%s entity=%s", tenant_id, kind, entity_id)

        return {"received": True, "processed": True}
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Webhook handler crashed tenant=%s provider=%s: %s", tenant_id, provider, exc)
        return {"received": True, "processed": False}
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Handlers — thin wrappers that reuse restaurant_order_service and the
# booking confirmation task.

def _complete_restaurant_order(
    db: Session, tenant_id: str, order_id: str, event: dict
) -> None:
    from src.models.restaurant import RestaurantOrder, Restaurant
    from src.services import restaurant_order_service as order_service

    order = (
        db.query(RestaurantOrder)
        .filter(RestaurantOrder.id == order_id, RestaurantOrder.tenant_id == tenant_id)
        .first()
    )
    if not order:
        logger.warning("restaurant_order %s not found for tenant %s", order_id, tenant_id)
        return

    session_id = event.get("session_id") or ""
    if session_id and any(p.reference == session_id for p in order.payments):
        return  # dedupe replay

    paid = (event.get("paid_amount_minor") or 0) / 100.0
    if paid <= 0:
        paid = float(order.total or 0)

    restaurant = (
        db.query(Restaurant).filter(Restaurant.id == order.restaurant_id).first()
    )
    try:
        order_service.add_payment(
            db,
            order=order,
            method="stripe",  # generic 'online card'; provider captured in reference
            amount=paid,
            reference=session_id or None,
            restaurant=restaurant,
        )
        # Send online orders to kitchen on successful payment (matches
        # existing Stripe flow in booking_stripe_webhook).
        if order.source in ("online",) and not order.sent_to_kitchen_at:
            try:
                order_service.send_to_kitchen(db, order=order)
            except Exception as exc:
                logger.warning("send_to_kitchen after payment failed for %s: %s", order.id, exc)
        db.commit()
    except order_service.OrderServiceError as exc:
        logger.warning("add_payment failed for %s: %s", order.id, exc)
        db.rollback()


def _complete_booking(
    db: Session,
    tenant_id: str,
    booking_id: str,
    event: dict,
    background_tasks: BackgroundTasks,
) -> None:
    from datetime import datetime
    from src.models.booking import Booking

    booking = (
        db.query(Booking)
        .filter(Booking.id == booking_id, Booking.tenant_id == tenant_id)
        .first()
    )
    if not booking:
        logger.warning("booking %s not found for tenant %s", booking_id, tenant_id)
        return

    already = booking.advance_paid and booking.status == "confirmed"
    booking.advance_paid = True
    booking.status = "confirmed"
    booking.updated_at = datetime.utcnow()
    db.commit()

    if not already:
        from src.api.public_bookings import create_invoice_and_send_booking_confirmation_task

        background_tasks.add_task(
            create_invoice_and_send_booking_confirmation_task,
            booking.id,
            tenant_id,
            float(booking.advance_required or 0),
        )


def _expire_booking(db: Session, tenant_id: str, booking_id: str) -> None:
    from datetime import datetime
    from src.models.booking import Booking

    booking = (
        db.query(Booking)
        .filter(Booking.id == booking_id, Booking.tenant_id == tenant_id)
        .first()
    )
    if not booking or booking.advance_paid:
        return
    if booking.status == "pending":
        booking.status = "cancelled"
        booking.updated_at = datetime.utcnow()
        db.commit()


def _complete_facility_booking(
    db: Session,
    tenant_id: str,
    fb_id: str,
    event: dict,
    background_tasks: BackgroundTasks,
) -> None:
    from datetime import datetime
    from src.models.facility_booking import FacilityBooking

    fb = (
        db.query(FacilityBooking)
        .filter(FacilityBooking.id == fb_id, FacilityBooking.tenant_id == tenant_id)
        .first()
    )
    if not fb:
        logger.warning("facility_booking %s not found for tenant %s", fb_id, tenant_id)
        return
    if fb.status == "confirmed":
        return  # dedupe webhook replay
    fb.status = "confirmed"
    fb.updated_at = datetime.utcnow()
    db.commit()
    # Fire confirmation email with QR
    if fb.guest_email:
        from src.api.facility_bookings import _send_facility_confirmation_email
        background_tasks.add_task(_send_facility_confirmation_email, fb.id, tenant_id)


def _expire_facility_booking(db: Session, tenant_id: str, fb_id: str) -> None:
    from datetime import datetime
    from src.models.facility_booking import FacilityBooking

    fb = (
        db.query(FacilityBooking)
        .filter(FacilityBooking.id == fb_id, FacilityBooking.tenant_id == tenant_id)
        .first()
    )
    if not fb or fb.status != "pending":
        return
    fb.status = "expired"
    fb.updated_at = datetime.utcnow()
    db.commit()
