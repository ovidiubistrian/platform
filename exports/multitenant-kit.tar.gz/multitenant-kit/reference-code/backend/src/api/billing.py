"""
Billing API routes: providers list, Oblio connect/test/disconnect, companies, series, invoices.
All routes are tenant-scoped (tenant_id from auth). No tenant_id in body/query.
"""
import logging
import json
import uuid
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.orm import Session

from src.core.security import get_current_active_user, require_tenant_admin
from src.db.session import get_db
from src.models.billing_integration import BillingIntegration, BillingInvoiceIdempotency
from src.models.site_config import SiteConfig
from src.models.user import User
from src.core.billing_secrets import encrypt_billing_secret, decrypt_billing_secret
from src.providers.billing import OblioProvider, SmartBillProvider
from src.schemas.billing import (
    BillingProviderInfo,
    OblioConnectBody,
    OblioStatusResponse,
    GenericInvoicePayload,
    OblioInvoiceCreateResponse,
    SmartBillConnectBody,
    SmartBillStatusResponse,
    SmartBillInvoiceCreateResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def _oblio_credentials_from_integration(integration: BillingIntegration) -> Dict[str, Any]:
    """Build credentials dict for OblioProvider (include decrypted secret)."""
    secret = ""
    if integration.oblio_client_secret_encrypted:
        secret = decrypt_billing_secret(integration.oblio_client_secret_encrypted)
    return {
        "client_id": integration.oblio_client_id,
        "client_secret": secret,
        "email": integration.oblio_client_id,
        "secret": secret,
        "company_cif": integration.selected_company_cif,
        "default_invoice_series": integration.default_invoice_series,
        "workStation": integration.work_station,
        "management": integration.management,
        "currency": integration.currency,
        "vatIncluded": integration.vat_included,
        "invoice_product_name": integration.invoice_product_name,
        "default_vat_percentage": integration.default_vat_percentage,
    }


def _get_oblio_integration(db: Session, tenant_id: str) -> Optional[BillingIntegration]:
    return (
        db.query(BillingIntegration)
        .filter(
            BillingIntegration.tenant_id == tenant_id,
            BillingIntegration.provider == "oblio",
        )
        .first()
    )


def _get_or_create_oblio_integration(db: Session, tenant_id: str) -> BillingIntegration:
    integration = _get_oblio_integration(db, tenant_id)
    if integration:
        return integration
    integration = BillingIntegration(
        id=str(uuid.uuid4()),
        tenant_id=tenant_id,
        provider="oblio",
        status="disconnected",
    )
    db.add(integration)
    db.commit()
    db.refresh(integration)
    return integration


def _smartbill_credentials_from_integration(integration: BillingIntegration) -> Dict[str, Any]:
    token = ""
    if integration.smartbill_token_encrypted:
        token = decrypt_billing_secret(integration.smartbill_token_encrypted)
    return {
        "email": integration.smartbill_email,
        "token": token,
        "username": integration.smartbill_email,
        "company_cif": integration.selected_company_cif,
        "companyCUI": integration.selected_company_cif,
        "default_invoice_series": integration.default_invoice_series,
        "default_currency": integration.currency,
        "default_language": integration.default_language,
        "default_is_tax_payer": integration.default_is_tax_payer,
        "default_payment_method": integration.default_payment_method,
        "default_notes": integration.default_notes,
        "invoice_product_name": integration.invoice_product_name,
        "default_vat_percentage": integration.default_vat_percentage,
        "vat_included": integration.vat_included,
    }


def _get_smartbill_integration(db: Session, tenant_id: str) -> Optional[BillingIntegration]:
    return (
        db.query(BillingIntegration)
        .filter(
            BillingIntegration.tenant_id == tenant_id,
            BillingIntegration.provider == "smartbill",
        )
        .first()
    )


def _get_or_create_smartbill_integration(db: Session, tenant_id: str) -> BillingIntegration:
    integration = _get_smartbill_integration(db, tenant_id)
    if integration:
        return integration
    integration = BillingIntegration(
        id=str(uuid.uuid4()),
        tenant_id=tenant_id,
        provider="smartbill",
        status="disconnected",
    )
    db.add(integration)
    db.commit()
    db.refresh(integration)
    return integration


# ---- GET /billing/providers ----
@router.get("/providers", response_model=List[BillingProviderInfo])
async def list_billing_providers(
    current_user: User = Depends(require_tenant_admin),
):
    """List available billing providers and capabilities."""
    return [
        BillingProviderInfo(
            id="oblio",
            name="Oblio",
            capabilities=["invoices", "companies", "series", "test_connection", "create_invoice", "list_invoices", "cancel", "restore", "collect", "delete"],
        ),
        BillingProviderInfo(
            id="smartbill",
            name="SmartBill",
            capabilities=["invoices", "series", "vat_rates", "test_connection", "create_invoice", "list_invoices", "cancel", "restore", "delete", "payment"],
        ),
        BillingProviderInfo(
            id="fgo",
            name="FGO",
            capabilities=["invoices", "test_connection", "create_invoice", "cancel", "storno_ready", "print_ready", "payment_ready"],
        ),
    ]


# ---- GET /billing/effective-provider ----
@router.get("/effective-provider")
async def get_effective_billing_provider(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Returnează providerul efectiv de facturare (pentru afișare în UI). Folosit la încărcarea tab-ului Facturare&Plata."""
    if not current_user.tenant_id:
        return {"provider": "proforma"}
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == current_user.tenant_id).first()
    from src.services.invoice_service import get_effective_billing_system
    effective = get_effective_billing_system(current_user.tenant_id, db, site_config)
    return {"provider": effective or "proforma"}


# ---- PUT /billing/active-provider ----
class ActiveProviderBody(BaseModel):
    """Provider folosit la generarea facturilor: oblio | smartbill | fgo | proforma."""
    provider: str  # "oblio" | "smartbill" | "fgo" | "proforma"


@router.put("/active-provider")
async def set_active_billing_provider(
    body: ActiveProviderBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Setează providerul folosit la facturare (când ai mai multe conectate)."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    provider = (body.provider or "").strip().lower()
    if provider not in ("oblio", "smartbill", "fgo", "proforma"):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="provider trebuie să fie oblio, smartbill, fgo sau proforma")
    if provider in ("oblio", "smartbill", "fgo"):
        from src.services.invoice_service import _is_provider_connected
        if not _is_provider_connected(provider, tenant_id, db):
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Conectează mai întâi {provider.capitalize()}")
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if not site_config:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Configurare site inexistentă")
    site_config.billing_system = provider
    db.commit()
    return {"ok": True, "message": f"Facturare setată pe {provider.capitalize()}", "provider": provider}


# ---- GET /billing/oblio/status ----
@router.get("/oblio/status", response_model=OblioStatusResponse)
async def oblio_status(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Get Oblio integration status for current tenant (no secret)."""
    try:
        if not current_user.tenant_id:
            return OblioStatusResponse(status="disconnected")
        integration = _get_oblio_integration(db, current_user.tenant_id)
        if not integration:
            return OblioStatusResponse(status="disconnected")
        return OblioStatusResponse(
            provider="oblio",
            status=integration.status or "disconnected",
            oblio_client_id=integration.oblio_client_id,
            selected_company_cif=integration.selected_company_cif,
            default_invoice_series=integration.default_invoice_series,
            invoice_product_name=integration.invoice_product_name,
            default_vat_percentage=integration.default_vat_percentage,
            last_test_at=integration.last_test_at,
            last_error=integration.last_error,
        )
    except Exception as e:
        logger.exception("oblio/status failed: %s", e)
        return OblioStatusResponse(status="disconnected")


# ---- POST /billing/oblio/connect ----
@router.post("/oblio/connect")
async def oblio_connect(
    body: OblioConnectBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Connect Oblio: validate token, fetch companies/series, save encrypted credentials.
    If clientSecret is omitted but integration already exists, only update companyCif and defaultInvoiceSeries.
    """
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    client_id = (body.clientId or "").strip() or None
    client_secret = (body.clientSecret or "").strip() or None
    company_cif = (body.companyCif or "").strip() or None
    default_invoice_series = (body.defaultInvoiceSeries or "").strip() or None

    integration = _get_oblio_integration(db, tenant_id)
    if integration and integration.oblio_client_secret_encrypted and not client_secret:
        # Update only company/series without re-sending secret
        credentials = _oblio_credentials_from_integration(integration)
        if client_id:
            credentials["client_id"] = client_id
        if not company_cif:
            company_cif = integration.selected_company_cif
        if not company_cif:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Selectează o companie (CIF)")
        provider = OblioProvider(tenant_id=tenant_id)
        ok, err = await provider.test_connection(credentials)
        if not ok:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Conexiune eșuată")
        integration.selected_company_cif = company_cif
        if default_invoice_series:
            integration.default_invoice_series = default_invoice_series
        if body.invoiceProductName is not None:
            integration.invoice_product_name = (body.invoiceProductName or "").strip() or None
        if body.defaultVatPercentage is not None:
            integration.default_vat_percentage = (body.defaultVatPercentage or "").strip() or None
        if client_id:
            integration.oblio_client_id = client_id
        integration.status = "connected"
        integration.last_error = None
        from datetime import datetime, timezone
        integration.last_test_at = datetime.now(timezone.utc)
        db.commit()
        db.refresh(integration)
        return {"ok": True, "message": "Setări Oblio actualizate"}

    if not client_id or not client_secret:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="clientId (email) și clientSecret sunt obligatorii")

    provider = OblioProvider(tenant_id=tenant_id)
    credentials = {"client_id": client_id, "client_secret": client_secret}

    ok, err = await provider.test_connection(credentials)
    if not ok:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Conexiune eșuată")

    companies = await provider.get_companies(credentials)
    if not companies:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Nu ai companii asociate în contul Oblio")

    cifs = [c.get("cif") or c.get("id") for c in companies if c.get("cif") or c.get("id")]
    if not company_cif and cifs:
        company_cif = cifs[0]
    if not company_cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Selectează o companie (CIF)")

    series_list = await provider.get_series(credentials, company_cif)
    series_names = [s.get("name") or s.get("seriesName") for s in series_list if s.get("name") or s.get("seriesName")]
    default_series = default_invoice_series or (series_names[0] if series_names else None)

    integration = _get_or_create_oblio_integration(db, tenant_id)
    integration.oblio_client_id = client_id
    integration.oblio_client_secret_encrypted = encrypt_billing_secret(client_secret)
    integration.selected_company_cif = company_cif
    integration.default_invoice_series = default_series
    invoice_name = (body.invoiceProductName or "").strip() or None
    vat_pct = (body.defaultVatPercentage or "").strip() or None
    if invoice_name is not None:
        integration.invoice_product_name = invoice_name
    if vat_pct is not None:
        integration.default_vat_percentage = vat_pct
    integration.status = "connected"
    integration.last_error = None
    from datetime import datetime, timezone
    integration.last_test_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(integration)
    # Activează Oblio pentru facturare la rezervări: site_config.billing_system = 'oblio'
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if site_config:
        site_config.billing_system = "oblio"
        db.commit()
    logger.info("Oblio connected for tenant", extra={"tenant_id": tenant_id, "provider": "oblio"})
    return {"ok": True, "message": "Oblio conectat cu succes"}


# ---- POST /billing/oblio/test ----
class OblioTestBody(BaseModel):
    """Body: frontend trimite JSON cu clientId/clientSecret; către Oblio merg client_id/client_secret."""
    model_config = ConfigDict(populate_by_name=True)
    clientId: Optional[str] = Field(None, alias="clientId")
    clientSecret: Optional[str] = Field(None, alias="clientSecret")


@router.post("/oblio/test")
async def oblio_test(
    body: OblioTestBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Test Oblio credentials (optional body) or saved integration."""
    tenant_id = current_user.tenant_id
    if not tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")

    if body.clientId and body.clientSecret:
        credentials = {
            "client_id": (body.clientId or "").strip(),
            "client_secret": (body.clientSecret or "").strip(),
        }
    else:
        integration = _get_oblio_integration(db, tenant_id)
        if not integration or not integration.oblio_client_secret_encrypted:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Introdu Email și API Secret sau conectează mai întâi Oblio")
        credentials = _oblio_credentials_from_integration(integration)

    provider = OblioProvider(tenant_id=tenant_id)
    ok, err = await provider.test_connection(credentials)
    if not ok:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Test eșuat")

    from datetime import datetime, timezone

    # După test reușit cu credentiale din body: salvez credențialele (fără companie/serie) ca GET /oblio/companies și /oblio/series să funcționeze
    if body.clientId and body.clientSecret:
        client_id = (body.clientId or "").strip()
        client_secret = (body.clientSecret or "").strip()
        if client_id and client_secret:
            integration = _get_or_create_oblio_integration(db, tenant_id)
            integration.oblio_client_id = client_id
            integration.oblio_client_secret_encrypted = encrypt_billing_secret(client_secret)
            integration.last_test_at = datetime.now(timezone.utc)
            integration.last_error = None
            # status rămâne disconnected până la Salvează/Conectează cu companie și serie
            db.commit()
            db.refresh(integration)

    # Actualizez last_test_at și pe integrarea existentă dacă nu am salvat acum
    integration = _get_oblio_integration(db, tenant_id)
    if integration:
        integration.last_test_at = datetime.now(timezone.utc)
        integration.last_error = None
        db.commit()

    # Returnăm și lista de companii ca UI să poată alege și apoi Salvează/Conectează
    if body.clientId and body.clientSecret:
        try:
            companies = await provider.get_companies(credentials)
            return {"ok": True, "message": "Conexiune reușită", "companies": companies}
        except Exception as e:
            logger.warning("oblio/test: could not fetch companies after test: %s", e)
    return {"ok": True, "message": "Conexiune reușită"}


# ---- POST /billing/oblio/disconnect ----
@router.post("/oblio/disconnect")
async def oblio_disconnect(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Disconnect Oblio: clear secret, set status=disconnected; dezactivează facturare Oblio la rezervări."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    integration = _get_oblio_integration(db, tenant_id)
    if integration:
        integration.oblio_client_secret_encrypted = None
        integration.status = "disconnected"
        integration.last_error = None
        db.commit()
    # Revenire la proforma pentru facturare la rezervări dacă Oblio era folosit
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if site_config and site_config.billing_system == "oblio":
        site_config.billing_system = "proforma"
        db.commit()
    return {"ok": True, "message": "Oblio deconectat"}


# ---- GET /billing/oblio/companies ----
@router.get("/oblio/companies")
async def oblio_companies(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Get Oblio companies (cached 5 min is optional; here we call API each time)."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    companies = await provider.get_companies(credentials)
    return {"companies": companies}


# ---- GET /billing/oblio/series (când ești deja conectat) ----
@router.get("/oblio/series")
async def oblio_series(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    companyCif: Optional[str] = Query(None, alias="companyCif"),
):
    """Get Oblio series for saved company or query param. Necesită integrare salvată."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    cif = companyCif or integration.selected_company_cif
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    series_list = await provider.get_series(credentials, cif)
    return {"series": series_list}


# ---- GET /billing/oblio/products ----
@router.get("/oblio/products")
async def oblio_products(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    companyCif: Optional[str] = Query(None, alias="companyCif"),
):
    """Returnează lista de produse/servicii din Oblio pentru selectare la facturare."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    cif = companyCif or integration.selected_company_cif
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Selectează o companie (CIF)")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    products = await provider.get_products(credentials, cif)
    return {"products": products}


# ---- POST /billing/oblio/series (înainte de conectare: trimite credentiale în body) ----
class OblioSeriesBody(BaseModel):
    """Pentru a încărca seriile înainte de Salvează/Conectează."""
    model_config = ConfigDict(populate_by_name=True)
    companyCif: str
    clientId: Optional[str] = Field(None, alias="clientId")
    clientSecret: Optional[str] = Field(None, alias="clientSecret")


@router.post("/oblio/series")
async def oblio_series_post(
    body: OblioSeriesBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    """Încarcă seriile pentru o companie: cu clientId/clientSecret (înainte de connect) sau fără (folosește integrarea salvată)."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    cif = (body.companyCif or "").strip()
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    if body.clientId and body.clientSecret:
        credentials = {
            "client_id": (body.clientId or "").strip(),
            "client_secret": (body.clientSecret or "").strip(),
        }
    else:
        integration = _get_oblio_integration(db, tenant_id)
        if not integration or not integration.oblio_client_secret_encrypted:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio sau trimite clientId și clientSecret")
        credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=tenant_id)
    series_list = await provider.get_series(credentials, cif)
    return {"series": series_list}


# ---- POST /billing/oblio/invoices ----
@router.post("/oblio/invoices", response_model=OblioInvoiceCreateResponse)
async def oblio_create_invoice(
    body: GenericInvoicePayload,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    idempotencyKey: Optional[str] = Query(None, alias="idempotencyKey"),
):
    """Create Oblio invoice. Uses idempotency key to avoid duplicates."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or integration.status != "connected" or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează Oblio și selectează compania/seria")
    credentials = _oblio_credentials_from_integration(integration)
    key = idempotencyKey or str(uuid.uuid4())

    # Check idempotency: return existing if already created
    existing = (
        db.query(BillingInvoiceIdempotency)
        .filter(
            BillingInvoiceIdempotency.tenant_id == current_user.tenant_id,
            BillingInvoiceIdempotency.provider == "oblio",
            BillingInvoiceIdempotency.idempotency_key == key,
        )
        .first()
    )
    if existing and existing.oblio_series_name and existing.oblio_number:
        link = f"https://www.oblio.eu/invoice/{existing.oblio_series_name}/{existing.oblio_number}"
        return OblioInvoiceCreateResponse(
            seriesName=existing.oblio_series_name,
            number=existing.oblio_number,
            link=link,
        )

    payload = body.model_dump(exclude_none=True)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    result = await provider.create_invoice(credentials, payload, idempotency_key=key)

    # Persist idempotency mapping
    rec = BillingInvoiceIdempotency(
        id=str(uuid.uuid4()),
        tenant_id=current_user.tenant_id,
        provider="oblio",
        idempotency_key=key,
        oblio_series_name=result.get("seriesName"),
        oblio_number=result.get("number"),
    )
    db.add(rec)
    db.commit()
    return OblioInvoiceCreateResponse(
        seriesName=result.get("seriesName", ""),
        number=result.get("number", ""),
        link=result.get("link", ""),
    )


# ---- GET /billing/oblio/invoices ----
@router.get("/oblio/invoices")
async def oblio_list_invoices(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    cif: Optional[str] = Query(None),
):
    """List Oblio invoices (delegates to Oblio list)."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    company_cif = cif or integration.selected_company_cif
    if not company_cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    filters = {}
    invoices = await provider.list_invoices(credentials, company_cif, filters)
    return {"invoices": invoices}


# ---- GET /billing/oblio/invoices/{seriesName}/{number} ----
@router.get("/oblio/invoices/{series_name}/{number}")
async def oblio_get_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    doc = await provider.get_invoice(
        credentials,
        integration.selected_company_cif,
        series_name,
        number,
    )
    return doc


# ---- PUT /billing/oblio/invoices/{seriesName}/{number}/cancel ----
@router.put("/oblio/invoices/{series_name}/{number}/cancel")
async def oblio_cancel_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    result = await provider.cancel_invoice(
        credentials, integration.selected_company_cif, series_name, number
    )
    return result


# ---- PUT restore / collect ----
@router.put("/oblio/invoices/{series_name}/{number}/restore")
async def oblio_restore_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    return await provider.restore_invoice(
        credentials, integration.selected_company_cif, series_name, number
    )


@router.put("/oblio/invoices/{series_name}/{number}/collect")
async def oblio_collect_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    return await provider.collect_invoice(
        credentials, integration.selected_company_cif, series_name, number
    )


# ---- DELETE /billing/oblio/invoices/{seriesName}/{number} ----
@router.delete("/oblio/invoices/{series_name}/{number}")
async def oblio_delete_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    idempotencyKey: Optional[str] = Query(None, alias="idempotencyKey"),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_oblio_integration(db, current_user.tenant_id)
    if not integration or not integration.oblio_client_secret_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi Oblio")
    credentials = _oblio_credentials_from_integration(integration)
    provider = OblioProvider(tenant_id=current_user.tenant_id)
    return await provider.delete_invoice(
        credentials,
        integration.selected_company_cif,
        series_name,
        number,
        idempotency_key=idempotencyKey,
    )


# ============== SmartBill ==============

@router.get("/smartbill/status", response_model=SmartBillStatusResponse)
async def smartbill_status(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    try:
        if not current_user.tenant_id:
            return SmartBillStatusResponse(status="disconnected")
        integration = _get_smartbill_integration(db, current_user.tenant_id)
        if not integration:
            return SmartBillStatusResponse(status="disconnected")
        return SmartBillStatusResponse(
            provider="smartbill",
            status=integration.status or "disconnected",
            smartbill_email=integration.smartbill_email,
            enabled=integration.enabled,
            selected_company_cif=integration.selected_company_cif,
            default_invoice_series=integration.default_invoice_series,
            default_currency=integration.currency,
            default_language=integration.default_language,
            default_is_tax_payer=integration.default_is_tax_payer,
            default_payment_method=integration.default_payment_method,
            default_notes=integration.default_notes,
            invoice_settings=(
                json.loads(integration.invoice_settings_json)
                if integration.invoice_settings_json
                else None
            ),
            created_by=integration.created_by,
            updated_by=integration.updated_by,
            last_connection_check_at=integration.last_connection_check_at,
            last_connection_status=integration.last_connection_status,
            last_test_at=integration.last_test_at,
            last_error=integration.last_error,
        )
    except Exception as e:
        logger.exception("smartbill/status failed: %s", e)
        return SmartBillStatusResponse(status="disconnected")


@router.post("/smartbill/connect")
async def smartbill_connect(
    body: SmartBillConnectBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    email = body.email
    token = body.token
    company_cif = body.companyCif
    default_series = body.defaultSeries
    default_currency = (body.defaultCurrency or "").strip().upper() or None
    default_language = (body.defaultLanguage or "").strip().upper() or None
    default_payment_method = (body.defaultPaymentMethod or "").strip() or None
    default_notes = (body.defaultNotes or "").strip() or None
    enabled = body.enabled
    invoice_settings_json = json.dumps(body.invoiceSettings) if body.invoiceSettings is not None else None
    integration = _get_smartbill_integration(db, tenant_id)
    if integration and integration.smartbill_token_encrypted and not token:
        # Update only company/series (no new token)
        credentials = _smartbill_credentials_from_integration(integration)
        if email:
            credentials["email"] = email
        company_cif = company_cif or integration.selected_company_cif
        if not company_cif:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="CIF-ul companiei este obligatoriu")
        provider = SmartBillProvider(tenant_id=tenant_id)
        ok, err = await provider.test_connection(credentials)
        if not ok:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Conexiune eșuată")
        integration.selected_company_cif = company_cif
        if default_series:
            integration.default_invoice_series = default_series
        if default_currency is not None:
            integration.currency = default_currency
        if default_language is not None:
            integration.default_language = default_language
        if body.defaultIsTaxPayer is not None:
            integration.default_is_tax_payer = bool(body.defaultIsTaxPayer)
        if default_payment_method is not None:
            integration.default_payment_method = default_payment_method
        if default_notes is not None:
            integration.default_notes = default_notes
        if invoice_settings_json is not None:
            integration.invoice_settings_json = invoice_settings_json
        integration.enabled = bool(enabled) if enabled is not None else True
        if email:
            integration.smartbill_email = email
        integration.status = "connected"
        integration.last_error = None
        from datetime import datetime, timezone
        integration.last_test_at = datetime.now(timezone.utc)
        integration.last_connection_check_at = integration.last_test_at
        integration.last_connection_status = "ok"
        integration.updated_by = current_user.id
        db.commit()
        db.refresh(integration)
        return {"ok": True, "message": "Setări SmartBill actualizate"}
    if not email or not token:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email și Token sunt obligatorii")
    if not company_cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="CIF-ul companiei este obligatoriu")
    credentials = {"email": email, "token": token, "company_cif": company_cif}
    provider = SmartBillProvider(tenant_id=tenant_id)
    ok, err = await provider.test_connection(credentials)
    if not ok:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Conexiune eșuată")
    series_list = await provider.get_series(credentials, company_cif)
    series_names = [s.get("name") or s.get("seriesName") for s in series_list if s.get("name") or s.get("seriesName")]
    if not default_series and series_names:
        default_series = series_names[0]
    integration = _get_or_create_smartbill_integration(db, tenant_id)
    integration.smartbill_email = email
    integration.smartbill_token_encrypted = encrypt_billing_secret(token)
    integration.selected_company_cif = company_cif
    integration.default_invoice_series = default_series
    integration.currency = default_currency or integration.currency
    integration.default_language = default_language or integration.default_language
    if body.defaultIsTaxPayer is not None:
        integration.default_is_tax_payer = bool(body.defaultIsTaxPayer)
    integration.default_payment_method = default_payment_method
    integration.default_notes = default_notes
    if invoice_settings_json is not None:
        integration.invoice_settings_json = invoice_settings_json
    integration.enabled = bool(enabled) if enabled is not None else True
    integration.status = "connected"
    integration.last_error = None
    from datetime import datetime, timezone
    integration.last_test_at = datetime.now(timezone.utc)
    integration.last_connection_check_at = integration.last_test_at
    integration.last_connection_status = "ok"
    if not integration.created_by:
        integration.created_by = current_user.id
    integration.updated_by = current_user.id
    db.commit()
    db.refresh(integration)
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if site_config:
        site_config.billing_system = "smartbill"
        db.commit()
    logger.info("SmartBill connected for tenant", extra={"tenant_id": tenant_id, "provider": "smartbill"})
    return {"ok": True, "message": "SmartBill conectat cu succes"}


class SmartBillTestBody(BaseModel):
    email: Optional[str] = None
    token: Optional[str] = None
    companyCif: Optional[str] = None


@router.post("/smartbill/test")
async def smartbill_test(
    body: SmartBillTestBody,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    if body.email and body.token and body.companyCif:
        credentials = {"email": body.email, "token": body.token, "company_cif": body.companyCif}
    else:
        integration = _get_smartbill_integration(db, tenant_id)
        if not integration or not integration.smartbill_token_encrypted:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează SmartBill sau trimite email, token și companyCif")
        credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=tenant_id)
    ok, err = await provider.test_connection(credentials)
    if not ok:
        integration = _get_smartbill_integration(db, tenant_id)
        if integration:
            from datetime import datetime, timezone
            integration.last_connection_check_at = datetime.now(timezone.utc)
            integration.last_connection_status = "error"
            integration.last_error = err or "Test eșuat"
            integration.updated_by = current_user.id
            db.commit()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err or "Test eșuat")
    integration = _get_smartbill_integration(db, tenant_id)
    if integration:
        from datetime import datetime, timezone
        integration.last_test_at = datetime.now(timezone.utc)
        integration.last_connection_check_at = integration.last_test_at
        integration.last_connection_status = "ok"
        integration.last_error = None
        integration.updated_by = current_user.id
        db.commit()
    return {"ok": True, "message": "Conexiune reușită"}


@router.post("/smartbill/disconnect")
async def smartbill_disconnect(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    tenant_id = current_user.tenant_id
    integration = _get_smartbill_integration(db, tenant_id)
    if integration:
        from datetime import datetime, timezone
        integration.smartbill_token_encrypted = None
        integration.status = "disconnected"
        integration.enabled = False
        integration.last_connection_check_at = datetime.now(timezone.utc)
        integration.last_connection_status = "disconnected"
        integration.last_error = None
        integration.updated_by = current_user.id
        db.commit()
    site_config = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if site_config and site_config.billing_system == "smartbill":
        site_config.billing_system = "proforma"
        db.commit()
    return {"ok": True, "message": "SmartBill deconectat"}


@router.get("/smartbill/series")
async def smartbill_series(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    companyCif: Optional[str] = Query(None, alias="companyCif"),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    cif = companyCif or integration.selected_company_cif
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    series_list = await provider.get_series(credentials, cif)
    return {"series": series_list}


@router.get("/smartbill/vat-rates")
async def smartbill_vat_rates(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    companyCif: Optional[str] = Query(None, alias="companyCif"),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    cif = companyCif or integration.selected_company_cif
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    rates = await provider.get_vat_rates(credentials, cif)
    return {"vatRates": rates}


@router.post("/smartbill/invoices", response_model=SmartBillInvoiceCreateResponse)
async def smartbill_create_invoice(
    body: GenericInvoicePayload,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    idempotencyKey: Optional[str] = Query(None, alias="idempotencyKey"),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or integration.status != "connected" or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează SmartBill și setează compania/seria")
    credentials = _smartbill_credentials_from_integration(integration)
    key = idempotencyKey or str(uuid.uuid4())
    existing = (
        db.query(BillingInvoiceIdempotency)
        .filter(
            BillingInvoiceIdempotency.tenant_id == current_user.tenant_id,
            BillingInvoiceIdempotency.provider == "smartbill",
            BillingInvoiceIdempotency.idempotency_key == key,
        )
        .first()
    )
    if existing and existing.smartbill_series_name and existing.smartbill_number:
        from src.core.config import settings
        base = (settings.SMARTBILL_BASE_URL or "https://ws.smartbill.ro/SBORO/api").rstrip("/")
        link = f"{base}/invoice/pdf/{existing.smartbill_number}"
        return SmartBillInvoiceCreateResponse(
            seriesName=existing.smartbill_series_name,
            number=existing.smartbill_number,
            link=link,
        )
    payload = body.model_dump(exclude_none=True)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    result = await provider.create_invoice(credentials, payload, idempotency_key=key)
    rec = BillingInvoiceIdempotency(
        id=str(uuid.uuid4()),
        tenant_id=current_user.tenant_id,
        provider="smartbill",
        idempotency_key=key,
        smartbill_series_name=result.get("seriesName"),
        smartbill_number=result.get("number"),
    )
    db.add(rec)
    db.commit()
    return SmartBillInvoiceCreateResponse(
        seriesName=result.get("seriesName", ""),
        number=result.get("number", ""),
        link=result.get("link", ""),
    )


@router.get("/smartbill/invoices")
async def smartbill_list_invoices(
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
    companyCif: Optional[str] = Query(None),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    cif = companyCif or integration.selected_company_cif
    if not cif:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="companyCif lipsește")
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    invoices = await provider.list_invoices(credentials, cif, {})
    return {"invoices": invoices}


@router.get("/smartbill/invoices/{series_name}/{number}")
async def smartbill_get_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    return await provider.get_invoice(credentials, integration.selected_company_cif, series_name, number)


@router.put("/smartbill/invoices/{series_name}/{number}/cancel")
async def smartbill_cancel_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    return await provider.cancel_invoice(credentials, integration.selected_company_cif, series_name, number)


@router.put("/smartbill/invoices/{series_name}/{number}/restore")
async def smartbill_restore_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    return await provider.restore_invoice(credentials, integration.selected_company_cif, series_name, number)


@router.delete("/smartbill/invoices/{series_name}/{number}")
async def smartbill_delete_invoice(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    return await provider.delete_invoice(credentials, integration.selected_company_cif, series_name, number)


@router.post("/smartbill/invoices/{series_name}/{number}/payment")
async def smartbill_invoice_payment(
    series_name: str,
    number: str,
    current_user: User = Depends(require_tenant_admin),
    db: Session = Depends(get_db),
):
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no tenant")
    integration = _get_smartbill_integration(db, current_user.tenant_id)
    if not integration or not integration.smartbill_token_encrypted:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Conectează mai întâi SmartBill")
    credentials = _smartbill_credentials_from_integration(integration)
    provider = SmartBillProvider(tenant_id=current_user.tenant_id)
    return await provider.collect_invoice(credentials, integration.selected_company_cif, series_name, number)
