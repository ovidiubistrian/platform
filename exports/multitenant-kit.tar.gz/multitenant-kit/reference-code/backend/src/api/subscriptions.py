"""
Subscriptions API routes.
Matches: app/api/subscriptions/** endpoints
- GET/POST /api/subscriptions for tenant admin (current subscription, create checkout).
- Stripe test keys (sk_test_...) in dev do not affect your live Stripe account.
"""
from fastapi import APIRouter, Body, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel
import uuid
import json
import os

from src.db.session import get_db
from src.models.subscription_plan import SubscriptionPlan
from src.models.tenant import Tenant
from src.models.user import User
from src.core.security import get_current_active_user, require_super_admin
from src.core.config import settings

router = APIRouter()


class SubscribeBody(BaseModel):
    planId: str
    billingInterval: str  # "monthly" | "yearly"


class CancelBody(BaseModel):
    pass


class UpdateSubscriptionBody(BaseModel):
    planId: Optional[str] = None


def _plan_to_camel(plan: SubscriptionPlan) -> dict:
    """Serialize SubscriptionPlan to camelCase for frontend (admin + homepage)."""
    return {
        "id": plan.id,
        "name": plan.name,
        "description": plan.description,
        "monthlyPrice": float(plan.monthly_price),
        "yearlyPrice": float(plan.yearly_price),
        "currency": plan.currency or "RON",
        "maxProperties": plan.max_properties,
        "maxUnits": plan.max_units,
        "maxBookings": plan.max_bookings,
        "features": plan.features,
        "benefits": plan.benefits,
        "isActive": plan.is_active,
        "includesOnsiteOnboard": plan.includes_onsite_onboard or False,
        "includes24hSupport": plan.includes_24h_support or False,
        "trialMonths": plan.trial_months or 0,
        "stripeMonthlyPriceId": plan.stripe_monthly_price_id,
        "stripeYearlyPriceId": plan.stripe_yearly_price_id,
        "createdAt": plan.created_at.isoformat() if plan.created_at else None,
        "updatedAt": plan.updated_at.isoformat() if plan.updated_at else None,
    }


def _frontend_base_url() -> str:
    """Base URL for redirects (Stripe success/cancel). Use FRONTEND_URL in dev."""
    return os.getenv("FRONTEND_URL", getattr(settings, "APP_BASE_URL", "https://app.booking360.ro")).rstrip("/")


@router.get("")
async def get_current_subscription(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """
    GET /api/subscriptions — current subscription for the tenant.
    Tenant admin only (uses current_user.tenant_id).
    Returns shape compatible with frontend CurrentSubscription (id, status, plan, currentPeriodEnd).
    """
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    plan_name = (tenant.subscription_plan or "").strip()
    ends_at = tenant.subscription_ends_at
    status = (tenant.status or "active").lower()
    if not plan_name:
        return None
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.name == plan_name).first()
    if not plan:
        # Minimal plan so frontend can show plan name
        plan_payload = {
            "id": "",
            "name": plan_name,
            "description": None,
            "monthlyPrice": 0,
            "yearlyPrice": 0,
            "currency": "RON",
            "maxProperties": 0,
            "maxUnits": 0,
            "maxBookings": 0,
            "features": None,
            "benefits": None,
            "isActive": True,
            "includesOnsiteOnboard": False,
            "includes24hSupport": False,
            "trialMonths": 0,
            "stripeMonthlyPriceId": None,
            "stripeYearlyPriceId": None,
            "createdAt": None,
            "updatedAt": None,
        }
    else:
        plan_payload = _plan_to_camel(plan)
    return {
        "id": str(tenant.id),
        "status": status,
        "plan": plan_payload,
        "currentPeriodEnd": ends_at.isoformat() if ends_at else None,
        "trialEnd": None,
        # Signals to the frontend that Free plan is already used up and
        # should be disabled / hidden in the plan picker.
        "freePlanUsedAt": tenant.free_plan_used_at.isoformat() if tenant.free_plan_used_at else None,
    }


@router.post("")
async def subscribe(
    body: SubscribeBody,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """
    POST /api/subscriptions — start subscription (Stripe Checkout or dev assign).
    Use STRIPE_SECRET_KEY=sk_test_... in dev so live account is not affected.
    """
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    # Resolve plan: the frontend now sends plan_catalog ids (new source of
    # truth). Fall back to the legacy SubscriptionPlan table for any client
    # still on the old ids.
    from src.models.plan_catalog import PlanCatalog
    catalog_plan = db.query(PlanCatalog).filter(PlanCatalog.id == body.planId).first()
    plan = None
    if catalog_plan and catalog_plan.is_active:
        # Wrap as duck-typed object with the legacy fields the rest of this
        # endpoint reads (name, stripe_*_price_id).
        class _PlanShim:
            id = catalog_plan.id
            name = catalog_plan.name
            is_active = catalog_plan.is_active
            stripe_monthly_price_id = catalog_plan.stripe_monthly_price_id
            stripe_yearly_price_id = catalog_plan.stripe_yearly_price_id
        plan = _PlanShim()
        # Stamp the catalog id on the tenant so limits resolve correctly.
        tenant.plan_catalog_id = catalog_plan.id
    else:
        plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == body.planId).first()
    if not plan or not plan.is_active:
        raise HTTPException(status_code=400, detail="Plan not found or inactive")

    # Free plan is one-time only. Once a tenant has ever been on Free (the
    # free_plan_used_at stamp is set, or they're currently still on it),
    # they can never go back to Free — they must pick a paid plan.
    if (plan.name or "").strip().lower() == "free":
        if tenant.free_plan_used_at is not None:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    "Planul Free poate fi folosit o singură dată per tenant. "
                    "Alege un plan plătit (Premium sau PRO)."
                ),
            )

    interval = (body.billingInterval or "monthly").lower()
    price_id = plan.stripe_yearly_price_id if interval == "yearly" else plan.stripe_monthly_price_id
    secret = settings.STRIPE_SECRET_KEY
    base_url = _frontend_base_url()
    success_url = f"{base_url}/admin/subscription?success=1&session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{base_url}/admin/subscription?cancel=1"
    if secret and price_id:
        try:
            import stripe
            stripe.api_key = secret
            session_metadata = {
                "tenant_id": str(tenant.id),
                "plan_id": str(plan.id),
                "interval": interval,
            }
            session = stripe.checkout.Session.create(
                mode="subscription",
                line_items=[{"price": price_id, "quantity": 1}],
                success_url=success_url,
                cancel_url=cancel_url,
                client_reference_id=str(tenant.id),
                metadata=session_metadata,
                # Propagate the same metadata onto the Subscription object
                # itself so that later invoice.payment_succeeded webhooks
                # (for automatic renewals) can look up the tenant without
                # having to revisit the original checkout session.
                subscription_data={"metadata": session_metadata},
            )
            return {"url": session.url}
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Stripe error: {str(e)}")
    # Stripe configured but this plan has no price_id — never silently
    # "succeed". Catalog plans don't carry stripe price ids yet, so surface
    # the gap to the tenant with a clear message.
    if secret and not price_id:
        raise HTTPException(
            status_code=503,
            detail=(
                "Plata online prin Stripe nu este încă activată pentru acest plan. "
                "Contactează echipa 360booking pentru activare manuală."
            ),
        )
    # Dev / no Stripe at all: assign plan directly so the Subscribe button
    # works during local development against a test backend.
    from datetime import timedelta
    tenant.subscription_plan = plan.name
    if (plan.name or "").strip().lower() == "free":
        tenant.free_plan_used_at = datetime.utcnow()
        tenant.subscription_ends_at = tenant.free_plan_used_at + timedelta(days=30)
    else:
        tenant.subscription_ends_at = datetime.utcnow() + timedelta(days=365 if interval == "yearly" else 30)
    db.commit()
    return {"url": None}


@router.post("/cancel")
async def cancel_subscription(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """POST /api/subscriptions/cancel — cancel at period end (stub or Stripe)."""
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    # Stub: clear plan and set ends_at to now (or keep period end for “cancel at end”)
    tenant.subscription_plan = None
    tenant.subscription_ends_at = datetime.utcnow()
    db.commit()
    return {"ok": True}


@router.patch("")
async def update_subscription(
    body: UpdateSubscriptionBody,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """PATCH /api/subscriptions — change plan (stub)."""
    if not body.planId:
        raise HTTPException(status_code=400, detail="planId required")
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == body.planId).first()
    if not plan or not plan.is_active:
        raise HTTPException(status_code=400, detail="Plan not found or inactive")
    tenant.subscription_plan = plan.name
    from datetime import timedelta
    tenant.subscription_ends_at = datetime.utcnow() + timedelta(days=30)
    db.commit()
    return {"ok": True}


@router.get("/plans")
async def get_subscription_plans(
    db: Session = Depends(get_db)
):
    """
    Get all active subscription plans.
    Matches: GET /api/subscriptions/plans
    Public endpoint - no authentication required.
    Returns camelCase for frontend (admin subscription page + homepage pricing).
    """
    plans = db.query(SubscriptionPlan).filter(
        SubscriptionPlan.is_active == True
    ).order_by(SubscriptionPlan.monthly_price.asc()).all()
    return [_plan_to_camel(p) for p in plans]


# Note: Super admin endpoints are in super_admin.py router
# These endpoints below are kept for backward compatibility but should be moved
async def get_all_plans_admin(
    current_user: User = Depends(require_super_admin),
    db: Session = Depends(get_db)
):
    """
    Get all subscription plans (super admin only).
    Matches: GET /api/super-admin/pricing
    """
    plans = db.query(SubscriptionPlan).order_by(SubscriptionPlan.monthly_price.asc()).all()
    return plans


@router.post("/super-admin/plans")
async def create_plan(
    plan_data: dict,
    current_user: User = Depends(require_super_admin),
    db: Session = Depends(get_db)
):
    """
    Create a new subscription plan (super admin only).
    Matches: POST /api/super-admin/subscription-plans
    """
    name = plan_data.get("name", "").strip()
    if not name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Numele planului este obligatoriu"
        )
    
    # Check if plan with same name exists
    existing = db.query(SubscriptionPlan).filter(SubscriptionPlan.name == name).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Există deja un plan cu acest nume"
        )
    
    # Parse features if provided as string
    features = plan_data.get("features")
    if isinstance(features, str):
        try:
            # If it's already JSON, parse it
            json.loads(features)
            features_value = features
        except:
            # If it's a text string, convert to JSON array
            features_list = [f.strip() for f in features.split('\n') if f.strip()]
            features_value = json.dumps(features_list) if features_list else None
    elif isinstance(features, list):
        features_value = json.dumps(features)
    else:
        features_value = None
    
    plan = SubscriptionPlan(
        id=str(uuid.uuid4()),
        name=name,
        description=plan_data.get("description") or None,
        monthly_price=float(plan_data.get("monthlyPrice", 0)),
        yearly_price=float(plan_data.get("yearlyPrice", 0)),
        currency=plan_data.get("currency", "RON"),
        max_properties=int(plan_data.get("maxProperties", 1)),
        max_units=int(plan_data.get("maxUnits", 5)),
        max_bookings=int(plan_data.get("maxBookings", 100)),
        features=features_value,
        benefits=plan_data.get("benefits") or None,
        is_active=plan_data.get("isActive", True),
        includes_onsite_onboard=plan_data.get("includesOnsiteOnboard", False),
        includes_24h_support=plan_data.get("includes24hSupport", False),
        trial_months=int(plan_data.get("trialMonths", 0)),
        stripe_monthly_price_id=plan_data.get("stripeMonthlyPriceId") or None,
        stripe_yearly_price_id=plan_data.get("stripeYearlyPriceId") or None,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow()
    )
    
    db.add(plan)
    db.commit()
    db.refresh(plan)
    
    return plan


@router.put("/super-admin/plans/{plan_id}")
async def update_plan(
    plan_id: str,
    plan_data: dict,
    current_user: User = Depends(require_super_admin),
    db: Session = Depends(get_db)
):
    """
    Update a subscription plan (super admin only).
    Matches: PUT /api/super-admin/subscription-plans/{id}
    """
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    # Update fields
    if "name" in plan_data:
        name = plan_data["name"].strip()
        if name != plan.name:
            existing = db.query(SubscriptionPlan).filter(SubscriptionPlan.name == name, SubscriptionPlan.id != plan_id).first()
            if existing:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail="Există deja un plan cu acest nume"
                )
        plan.name = name
    
    if "description" in plan_data:
        plan.description = plan_data["description"] or None
    if "monthlyPrice" in plan_data:
        plan.monthly_price = float(plan_data["monthlyPrice"])
    if "yearlyPrice" in plan_data:
        plan.yearly_price = float(plan_data["yearlyPrice"])
    if "currency" in plan_data:
        plan.currency = plan_data["currency"]
    if "maxProperties" in plan_data:
        plan.max_properties = int(plan_data["maxProperties"])
    if "maxUnits" in plan_data:
        plan.max_units = int(plan_data["maxUnits"])
    if "maxBookings" in plan_data:
        plan.max_bookings = int(plan_data["maxBookings"])
    if "isActive" in plan_data:
        plan.is_active = bool(plan_data["isActive"])
    if "includesOnsiteOnboard" in plan_data:
        plan.includes_onsite_onboard = bool(plan_data["includesOnsiteOnboard"])
    if "includes24hSupport" in plan_data:
        plan.includes_24h_support = bool(plan_data["includes24hSupport"])
    if "trialMonths" in plan_data:
        plan.trial_months = int(plan_data["trialMonths"])
    if "features" in plan_data:
        features = plan_data["features"]
        if isinstance(features, str):
            try:
                json.loads(features)
                plan.features = features
            except:
                features_list = [f.strip() for f in features.split('\n') if f.strip()]
                plan.features = json.dumps(features_list) if features_list else None
        elif isinstance(features, list):
            plan.features = json.dumps(features)
        else:
            plan.features = None
    if "benefits" in plan_data:
        plan.benefits = plan_data["benefits"] or None
    
    plan.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(plan)
    
    return plan


@router.delete("/super-admin/plans/{plan_id}")
async def delete_plan(
    plan_id: str,
    current_user: User = Depends(require_super_admin),
    db: Session = Depends(get_db)
):
    """
    Delete a subscription plan (super admin only).
    Matches: DELETE /api/super-admin/subscription-plans/{id}
    """
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found"
        )
    
    # TODO: Check if plan is in use by tenants before deleting
    # For now, allow deletion
    
    db.delete(plan)
    db.commit()

    return {"message": "Plan deleted successfully"}


# ---------------------------------------------------------------------------
# Billing access gate — tenant-facing endpoints used by the admin UI to
# learn its own subscription state, postpone payment (up to N times) or
# request a one-month extension from the super-admin. These do NOT gate
# anything themselves; gating is done via a FastAPI dependency elsewhere.

@router.get("/access-status")
async def get_access_status(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Returns the current billing-access snapshot for the tenant. Always
    available regardless of enforcement — the frontend uses this to render
    banners/gates."""
    from src.services.access_control import evaluate

    if not current_user.tenant_id:
        raise HTTPException(status_code=400, detail="No tenant context")
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    return evaluate(db, tenant).to_dict()


@router.post("/postpone")
async def postpone_payment(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Tenant admin pressed 'Amână'. Increments the post-expiry counter.
    Only valid when subscription is actually expired."""
    from src.services.access_control import increment_postpone

    if not current_user.tenant_id:
        raise HTTPException(status_code=400, detail="No tenant context")
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    try:
        snap = increment_postpone(db, tenant)
    except ValueError as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    db.commit()
    return snap.to_dict()


@router.post("/extension-request")
async def request_extension(
    payload: dict = Body(default_factory=dict),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Tenant admin asks the super-admin for one more month. Only one
    pending request at a time (enforced by a DB partial unique index)."""
    from src.models.payment_extension_request import (
        PaymentExtensionRequest,
        EXTENSION_STATUS_PENDING,
    )
    from src.services.access_control import get_billing_settings

    if not current_user.tenant_id:
        raise HTTPException(status_code=400, detail="No tenant context")
    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    existing = (
        db.query(PaymentExtensionRequest)
        .filter(
            PaymentExtensionRequest.tenant_id == tenant.id,
            PaymentExtensionRequest.status == EXTENSION_STATUS_PENDING,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=409,
            detail="Ai deja o cerere de amânare în așteptare.",
        )

    settings = get_billing_settings(db)
    req = PaymentExtensionRequest(
        id=str(uuid.uuid4()),
        tenant_id=tenant.id,
        status=EXTENSION_STATUS_PENDING,
        requested_days=int(settings.get("extension_days") or 30),
        reason=(payload.get("reason") or "").strip() or None,
    )
    db.add(req)
    db.commit()
    db.refresh(req)
    return {
        "id": req.id,
        "status": req.status,
        "requestedDays": req.requested_days,
        "reason": req.reason,
        "requestedAt": req.requested_at.isoformat() if req.requested_at else None,
    }


# ---------------------------------------------------------------------------
# Tenant-facing add-on catalog + own assignments. Mirrors the super-admin
# view but filtered to packages where is_active=True and scoped to the
# authenticated tenant for assignments.

@router.get("/addons")
async def list_active_addon_packages(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """List all active add-on packages (SMS, email, business email) the
    tenant can see in the Abonamente page."""
    from src.models.addon_package import AddOnPackage

    packages = (
        db.query(AddOnPackage)
        .filter(AddOnPackage.is_active == True)  # noqa: E712
        .order_by(AddOnPackage.type.asc(), AddOnPackage.sort_order.asc(), AddOnPackage.price.asc())
        .all()
    )
    return [
        {
            "id": p.id,
            "type": p.type,
            "name": p.name,
            "description": p.description,
            "price": float(p.price or 0),
            "currency": p.currency,
            "billingCycle": p.billing_cycle,
            "quantity": p.quantity,
            "sortOrder": p.sort_order,
        }
        for p in packages
    ]


@router.post("/addons/checkout")
async def checkout_addon_package(
    payload: dict,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """Start checkout for an add-on package. If the package has a Stripe
    price_id and STRIPE_SECRET_KEY is configured, returns a Stripe Checkout
    session URL. Otherwise the add-on is assigned directly (dev path)."""
    from src.models.addon_package import AddOnPackage
    from src.services import addon_service

    if not current_user.tenant_id:
        raise HTTPException(status_code=400, detail="No tenant context")

    addon_package_id = (payload.get("addonPackageId") or "").strip()
    if not addon_package_id:
        raise HTTPException(status_code=400, detail="addonPackageId required")

    pkg = db.query(AddOnPackage).filter(AddOnPackage.id == addon_package_id).first()
    if not pkg or not pkg.is_active:
        raise HTTPException(status_code=400, detail="Pachet indisponibil")

    tenant = db.query(Tenant).filter(Tenant.id == current_user.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    secret = settings.STRIPE_SECRET_KEY
    price_id = pkg.stripe_price_id
    base_url = _frontend_base_url()
    success_url = f"{base_url}/admin/subscription?addon_success=1&session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{base_url}/admin/subscription?addon_cancel=1"

    if secret and price_id:
        try:
            import stripe
            stripe.api_key = secret
            session_metadata = {
                "tenant_id": str(tenant.id),
                "addon_package_id": str(pkg.id),
                "addon_type": str(pkg.type),
            }
            mode = "subscription" if pkg.type == "business_email" else "payment"
            kwargs = {
                "mode": mode,
                "line_items": [{"price": price_id, "quantity": 1}],
                "success_url": success_url,
                "cancel_url": cancel_url,
                "client_reference_id": str(tenant.id),
                "metadata": session_metadata,
            }
            if mode == "subscription":
                kwargs["subscription_data"] = {"metadata": session_metadata}
            session = stripe.checkout.Session.create(**kwargs)
            return {"url": session.url}
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"Stripe error: {str(e)}")

    # Dev / Stripe not configured: grant the add-on directly.
    addon = addon_service.grant(
        db,
        tenant_id=tenant.id,
        addon_package_id=pkg.id,
        notes="dev: no Stripe price_id",
    )
    db.commit()
    db.refresh(addon)
    return {"url": None, "addonId": addon.id}


@router.get("/addons/mine")
async def list_my_addon_assignments(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    """List the tenant's own add-on assignments (all types)."""
    if not current_user.tenant_id:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No tenant context")

    from src.models.addon_package import AddOnPackage, TenantAddOn

    rows = (
        db.query(TenantAddOn, AddOnPackage)
        .join(AddOnPackage, AddOnPackage.id == TenantAddOn.addon_package_id)
        .filter(TenantAddOn.tenant_id == current_user.tenant_id)
        .order_by(TenantAddOn.created_at.desc())
        .all()
    )
    return [
        {
            "id": addon.id,
            "addonPackageId": addon.addon_package_id,
            "packageName": pkg.name,
            "packageType": pkg.type,
            "packageQuantity": pkg.quantity,
            "price": float(pkg.price or 0),
            "currency": pkg.currency,
            "billingCycle": pkg.billing_cycle,
            "status": addon.status,
            "smsRemaining": addon.sms_remaining,
            "emailRemaining": addon.email_remaining,
            "activatedAt": addon.activated_at.isoformat() if addon.activated_at else None,
            "expiresAt": addon.expires_at.isoformat() if addon.expires_at else None,
            "createdAt": addon.created_at.isoformat() if addon.created_at else None,
        }
        for addon, pkg in rows
    ]

