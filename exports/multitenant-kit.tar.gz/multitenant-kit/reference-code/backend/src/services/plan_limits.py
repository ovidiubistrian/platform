"""Plan limit enforcement.

Single helper that returns a `LimitVerdict` for any (tenant, metric) pair.
Reads:
  * `plan_catalog.limits` for the tenant's `plan_catalog_id`
  * `tenants.plan_overrides` (per-tenant overrides, win over the catalog)
  * `tenant_usage_counters` for monthly metrics (orders, growth_posts, sms)
  * direct count queries for static metrics (units, properties, tables, ...)

Two enforcement modes:
  * **soft**  — count limits (units, properties, admin users, tables, menu_products).
                The caller may still create when at cap; helper returns `at_cap=True`
                so UI can show an upsell modal.
  * **hard**  — periodic counters (sms, orders_per_month, growth_posts_per_month).
                Caller MUST stop on `at_cap=True` (raise 402 / business error).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Optional

from sqlalchemy.orm import Session

from src.models.tenant import Tenant
from src.models.plan_catalog import PlanCatalog


# Map metric name -> (limits-key in plan_catalog.limits, mode).
# `limits-key` may be None for derived metrics (e.g. SMS uses sms_monthly_free_override).
METRICS: dict[str, tuple[Optional[str], str]] = {
    "units":                   ("maxUnits", "soft"),
    "properties":              ("includedProperties", "soft"),
    "admin_users":             ("adminUsers", "soft"),
    "tables":                  ("maxTables", "soft"),
    "menu_products":           ("maxMenuProducts", "soft"),
    "orders_per_month":        ("maxOrdersPerMonth", "hard"),
    "growth_posts_per_month":  ("growthCenterPostsPerMonth", "hard"),
    "sms_per_month":           ("includedSmsPerMonth", "hard"),
}


@dataclass
class LimitVerdict:
    metric: str
    used: int
    cap: Optional[int]   # None = unlimited
    at_cap: bool
    mode: str            # "soft" | "hard"
    plan_slug: Optional[str]
    plan_name: Optional[str]
    upgrade_url: str = "/admin/subscription"

    @property
    def remaining(self) -> Optional[int]:
        if self.cap is None:
            return None
        return max(0, self.cap - self.used)

    def to_dict(self) -> dict:
        return {
            "metric": self.metric,
            "used": self.used,
            "cap": self.cap,
            "remaining": self.remaining,
            "at_cap": self.at_cap,
            "mode": self.mode,
            "plan_slug": self.plan_slug,
            "plan_name": self.plan_name,
            "upgrade_url": self.upgrade_url,
        }


def _resolve_cap(tenant: Tenant, plan: Optional[PlanCatalog], limits_key: Optional[str]) -> Optional[int]:
    """Return the numeric cap for `limits_key`, applying tenant overrides.

    Returns None for unlimited (unset or sentinel string like "unlimited").
    """
    if limits_key is None:
        return None
    overrides = tenant.plan_overrides or {}
    raw = overrides.get(limits_key)
    if raw is None and plan is not None:
        raw = (plan.limits or {}).get(limits_key)
    if raw is None:
        return None
    if isinstance(raw, str):
        if raw.lower() in ("unlimited", "nelimitat"):
            return None
        try:
            return int(raw)
        except ValueError:
            return None
    if isinstance(raw, (int, float)):
        return int(raw)
    return None


def _count_static(db: Session, tenant: Tenant, metric: str) -> int:
    """Count current usage for static metrics (no period)."""
    if metric == "units":
        from src.models.unit import Unit
        return db.query(Unit).filter(Unit.tenant_id == tenant.id).count()
    if metric == "properties":
        from src.models.property import Property
        return db.query(Property).filter(Property.tenant_id == tenant.id).count()
    if metric == "admin_users":
        from src.models.user import User
        return db.query(User).filter(
            User.tenant_id == tenant.id,
            User.role.in_(("admin", "owner", "superadmin")),
        ).count()
    if metric == "tables":
        try:
            from src.models.restaurant import RestaurantTable
            return db.query(RestaurantTable).filter(RestaurantTable.tenant_id == tenant.id).count()
        except Exception:
            return 0
    if metric == "menu_products":
        try:
            from src.models.restaurant import MenuItem
            return db.query(MenuItem).filter(MenuItem.tenant_id == tenant.id).count()
        except Exception:
            return 0
    return 0


def _count_period(db: Session, tenant: Tenant, metric: str) -> int:
    """Read current-month usage from tenant_usage_counters / SMS counter on tenant."""
    if metric == "sms_per_month":
        return int(tenant.sms_monthly_used or 0)
    today = date.today()
    period_start = today.replace(day=1)
    from sqlalchemy import text
    row = db.execute(
        text("""SELECT used FROM tenant_usage_counters
                WHERE tenant_id = :tid AND metric = :m AND period_start = :p"""),
        {"tid": tenant.id, "m": metric, "p": period_start},
    ).first()
    return int(row[0]) if row else 0


def evaluate(db: Session, tenant: Tenant, metric: str) -> LimitVerdict:
    if metric not in METRICS:
        raise ValueError(f"Unknown metric: {metric}")
    limits_key, mode = METRICS[metric]

    plan: Optional[PlanCatalog] = None
    if tenant.plan_catalog_id:
        plan = db.query(PlanCatalog).filter(PlanCatalog.id == tenant.plan_catalog_id).first()

    cap = _resolve_cap(tenant, plan, limits_key)
    if mode == "hard" and metric in ("orders_per_month", "growth_posts_per_month", "sms_per_month"):
        used = _count_period(db, tenant, metric)
    else:
        used = _count_static(db, tenant, metric)

    at_cap = cap is not None and used >= cap

    return LimitVerdict(
        metric=metric,
        used=used,
        cap=cap,
        at_cap=at_cap,
        mode=mode,
        plan_slug=plan.slug if plan else None,
        plan_name=plan.name if plan else None,
    )


def increment_period(db: Session, tenant_id: str, metric: str, by: int = 1) -> None:
    """Bump `tenant_usage_counters` for the current calendar month. Idempotent on row creation."""
    today = date.today()
    period_start = today.replace(day=1)
    from sqlalchemy import text
    db.execute(
        text("""
            INSERT INTO tenant_usage_counters (tenant_id, metric, period_start, used)
            VALUES (:tid, :m, :p, :by)
            ON CONFLICT (tenant_id, metric, period_start)
            DO UPDATE SET used = tenant_usage_counters.used + :by, updated_at = NOW()
        """),
        {"tid": tenant_id, "m": metric, "p": period_start, "by": by},
    )
    db.commit()
