"""Abstract payment-provider interface. Mirrors the shape of
`services/fiscal/base.py` so the same plugin/registry pattern works for
both integrations.

A concrete provider holds per-tenant credentials in its constructor and
exposes a narrow surface:

  - `create_checkout_session(...)` → redirect URL for the guest
  - `verify_webhook(...)` → canonicalised event dict the HTTP handler
    can act on
  - `get_session_status(...)` → poll when we don't trust the webhook
  - `refund(...)` → optional, raise PaymentProviderError if not supported

All amounts are in `amount_minor` (cents/bani) to avoid float math at
the provider boundary. Currency is the three-letter ISO code (RON, EUR).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any


class PaymentProviderError(Exception):
    """Raised when the provider layer can't satisfy a request (bad
    credentials, network failure, unsupported operation). Callers
    should catch + surface a user-friendly message."""


@dataclass
class CheckoutSession:
    session_id: str
    url: str
    expires_at: int | None = None  # unix seconds, provider-reported
    raw: dict[str, Any] | None = None


@dataclass
class SessionStatus:
    # 'pending' (not yet attempted), 'completed' (paid),
    # 'expired' (lapsed without payment), 'failed' (explicit failure).
    status: str
    paid_amount_minor: int = 0
    currency: str = "RON"
    raw: dict[str, Any] | None = None


class PaymentProvider(ABC):
    """One instance per (tenant, provider). Construct from the parsed
    config dict; missing / malformed credentials raise PaymentProviderError."""

    key: str = "base"
    display_name: str = "Payment Provider"

    @abstractmethod
    def create_checkout_session(
        self,
        *,
        order_ref: str,
        amount_minor: int,
        currency: str,
        success_url: str,
        cancel_url: str,
        metadata: dict[str, str] | None = None,
        customer_email: str | None = None,
    ) -> CheckoutSession:
        """Create a hosted-checkout session and return the URL the guest
        must be redirected to."""

    @abstractmethod
    def verify_webhook(self, payload: bytes, signature: str) -> dict[str, Any]:
        """Validate the webhook signature and return a normalised event
        dict: {"type": "checkout.completed|failed|expired", "session_id": ...,
               "paid_amount_minor": ..., "currency": ..., "raw": ...}.
        Raise PaymentProviderError on signature mismatch."""

    @abstractmethod
    def get_session_status(self, session_id: str) -> SessionStatus:
        """Poll the provider for the current state of a checkout session.
        Used as a fallback when the webhook is late or lost."""

    def refund(self, payment_ref: str, amount_minor: int) -> dict[str, Any]:
        """Optional. Default implementation raises — providers that
        support refunds override."""
        raise PaymentProviderError(
            f"{self.display_name} does not yet support refunds from the app."
        )
