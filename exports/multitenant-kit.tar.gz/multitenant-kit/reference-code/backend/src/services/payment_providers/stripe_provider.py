"""Stripe wrapper. Keeps the existing inline Stripe calls intact — this
class is a thin adapter so the registry can dispatch uniformly. The real
Stripe import stays lazy (import stripe is heavy) and localised here."""
from __future__ import annotations

from typing import Any

from .base import CheckoutSession, PaymentProvider, PaymentProviderError, SessionStatus


class StripeProvider(PaymentProvider):
    key = "stripe"
    display_name = "Stripe"

    def __init__(self, *, publishable_key: str, secret_key: str, webhook_secret: str):
        if not (publishable_key.startswith("pk_") and secret_key.startswith("sk_") and webhook_secret.startswith("whsec_")):
            raise PaymentProviderError("Stripe keys malformed.")
        self.publishable_key = publishable_key
        self.secret_key = secret_key
        self.webhook_secret = webhook_secret

    def create_checkout_session(
        self,
        *,
        order_ref: str,
        amount_minor: int,
        currency: str,
        success_url: str,
        cancel_url: str,
        metadata: dict[str, str] | None = None,
        customer_email: str | None = None,
    ) -> CheckoutSession:
        import stripe  # lazy
        stripe.api_key = self.secret_key
        session = stripe.checkout.Session.create(
            mode="payment",
            success_url=success_url,
            cancel_url=cancel_url,
            customer_email=customer_email,
            line_items=[{
                "quantity": 1,
                "price_data": {
                    "currency": currency.lower(),
                    "unit_amount": int(amount_minor),
                    "product_data": {"name": f"Plată comandă {order_ref}"},
                },
            }],
            metadata=metadata or {},
        )
        return CheckoutSession(
            session_id=session.id,
            url=session.url,
            expires_at=getattr(session, "expires_at", None),
            raw=session.to_dict() if hasattr(session, "to_dict") else None,
        )

    def verify_webhook(self, payload: bytes, signature: str) -> dict[str, Any]:
        import stripe
        try:
            event = stripe.Webhook.construct_event(
                payload, signature, self.webhook_secret,
            )
        except Exception as exc:
            raise PaymentProviderError(f"Stripe signature verification failed: {exc}")

        t = event.get("type") if isinstance(event, dict) else event["type"]
        data = (event.get("data") if isinstance(event, dict) else event["data"]) or {}
        obj = data.get("object") or {}
        session_id = obj.get("id") or ""
        amount = int(obj.get("amount_total") or obj.get("amount_received") or 0)
        currency = (obj.get("currency") or "ron").upper()
        if t == "checkout.session.completed":
            normalized = "checkout.completed"
        elif t == "checkout.session.expired":
            normalized = "checkout.expired"
        elif t == "payment_intent.payment_failed":
            normalized = "checkout.failed"
        else:
            normalized = t
        return {
            "type": normalized,
            "session_id": session_id,
            "paid_amount_minor": amount,
            "currency": currency,
            "raw": event if isinstance(event, dict) else event.to_dict(),
        }

    def get_session_status(self, session_id: str) -> SessionStatus:
        import stripe
        stripe.api_key = self.secret_key
        s = stripe.checkout.Session.retrieve(session_id)
        paid = s.get("payment_status") == "paid"
        status = "completed" if paid else ("expired" if s.get("status") == "expired" else "pending")
        return SessionStatus(
            status=status,
            paid_amount_minor=int(s.get("amount_total") or 0),
            currency=(s.get("currency") or "ron").upper(),
            raw=s.to_dict() if hasattr(s, "to_dict") else None,
        )

    def refund(self, payment_ref: str, amount_minor: int) -> dict[str, Any]:
        import stripe
        stripe.api_key = self.secret_key
        r = stripe.Refund.create(payment_intent=payment_ref, amount=int(amount_minor))
        return r.to_dict() if hasattr(r, "to_dict") else dict(r)
