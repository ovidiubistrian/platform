"""Per-tenant provider dispatch + "is configured" helpers.

The registry reads per-tenant credentials from SiteConfig's JSON columns
and instantiates the matching PaymentProvider. Callers ask for a
provider by key (`'stripe' | 'netopia' | 'btipay'`) and get back either
a ready-to-use instance or None when the tenant hasn't configured it.

`is_any_provider_configured(tenant_id)` is the single source of truth
the frontend uses to enable / disable the "Card online" button surface.
"""
from __future__ import annotations

import json
import logging
from typing import Optional

from sqlalchemy.orm import Session

from src.models.site_config import SiteConfig
from .base import PaymentProvider, PaymentProviderError
from .btipay import BtIpayProvider
from .netopia import NetopiaProvider
from .stripe_provider import StripeProvider


logger = logging.getLogger(__name__)

PROVIDER_KEYS = ("stripe", "netopia", "btipay")


def _load_json(raw: str | None) -> dict:
    if not raw:
        return {}
    try:
        v = json.loads(raw)
        return v if isinstance(v, dict) else {}
    except (TypeError, ValueError):
        return {}


def _site_config(tenant_id: str, db: Session) -> Optional[SiteConfig]:
    return db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()


def _stripe_ready(sc: SiteConfig) -> bool:
    cfg = _load_json(sc.stripe_config)
    pk = (cfg.get("publishableKey") or cfg.get("publishable_key") or "").strip()
    sk = (cfg.get("secretKey") or cfg.get("secret_key") or "").strip()
    wh = (cfg.get("webhookSecret") or cfg.get("webhook_secret") or "").strip()
    return pk.startswith("pk_") and sk.startswith("sk_") and wh.startswith("whsec_")


def _netopia_ready(sc: SiteConfig) -> bool:
    cfg = _load_json(sc.netopia_config)
    has_sig = bool(cfg.get("signature"))
    has_key = bool(cfg.get("api_key") or cfg.get("apiKey"))
    has_pub = bool(cfg.get("public_key") or cfg.get("publicKey"))
    # public_key is mandatory — without it every webhook fails signature
    # verification, leaving bookings permanently pending.
    return has_sig and has_key and has_pub


def _btipay_ready(sc: SiteConfig) -> bool:
    cfg = _load_json(getattr(sc, "btipay_config", None))
    # New iPay REST model: Basic auth with user_name + password. Keep
    # back-compat with the old form-redirect fields (merchant_id +
    # signature_key) in case anyone saved them before the rewrite.
    has_rest = bool(cfg.get("user_name") or cfg.get("userName")) and bool(
        cfg.get("password")
    )
    has_legacy = bool(cfg.get("merchant_id") or cfg.get("merchantId")) and bool(
        cfg.get("signature_key") or cfg.get("signatureKey")
    )
    return has_rest or has_legacy


def get_configured_provider_keys(tenant_id: str, db: Session) -> list[str]:
    sc = _site_config(tenant_id, db)
    if not sc:
        return []
    out: list[str] = []
    if _stripe_ready(sc):
        out.append("stripe")
    if _netopia_ready(sc):
        out.append("netopia")
    if _btipay_ready(sc):
        out.append("btipay")
    return out


def is_any_provider_configured(tenant_id: str, db: Session) -> bool:
    return len(get_configured_provider_keys(tenant_id, db)) > 0


def get_provider(
    tenant_id: str, key: str, db: Session
) -> Optional[PaymentProvider]:
    """Instantiate the named provider with this tenant's credentials.
    Returns None (and logs) when not configured so the checkout endpoint
    can fall through to "metoda de plată indisponibilă"."""
    sc = _site_config(tenant_id, db)
    if not sc:
        return None
    k = (key or "").strip().lower()
    try:
        if k == "stripe":
            cfg = _load_json(sc.stripe_config)
            return StripeProvider(
                publishable_key=(cfg.get("publishableKey") or cfg.get("publishable_key") or "").strip(),
                secret_key=(cfg.get("secretKey") or cfg.get("secret_key") or "").strip(),
                webhook_secret=(cfg.get("webhookSecret") or cfg.get("webhook_secret") or "").strip(),
            )
        if k == "netopia":
            cfg = _load_json(sc.netopia_config)
            return NetopiaProvider(
                signature=cfg.get("signature", ""),
                api_key=cfg.get("api_key") or cfg.get("apiKey") or "",
                public_key=cfg.get("public_key") or cfg.get("publicKey"),
                sandbox=bool(cfg.get("sandbox", False)),
                api_url=cfg.get("api_url") or cfg.get("apiUrl"),
                tenant_id=tenant_id,
            )
        if k == "btipay":
            cfg = _load_json(getattr(sc, "btipay_config", None))
            return BtIpayProvider(
                user_name=(cfg.get("user_name") or cfg.get("userName") or "").strip(),
                password=(cfg.get("password") or "").strip(),
                sandbox=bool(cfg.get("sandbox", True)),
                child_id=(cfg.get("child_id") or cfg.get("childId")) or None,
            )
    except PaymentProviderError as exc:
        logger.warning("Tenant %s provider %s unusable: %s", tenant_id, k, exc)
        return None
    logger.warning("Unknown payment provider key: %r", key)
    return None
