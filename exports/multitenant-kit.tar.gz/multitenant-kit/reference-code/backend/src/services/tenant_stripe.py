"""Per-tenant Stripe configuration access.

Each tenant configures their own Stripe account in
`site_configs.stripe_config` (JSON string with publishableKey, secretKey,
webhookSecret). This module is the single point of access — both the
checkout-session endpoint and the booking-stripe webhook read credentials
through here so the parsing/validation logic stays in one place.
"""
from __future__ import annotations

import json
import logging
from typing import Optional, TypedDict

from sqlalchemy.orm import Session

from src.models.site_config import SiteConfig

logger = logging.getLogger(__name__)


class TenantStripeConfig(TypedDict):
    publishable_key: str
    secret_key: str
    webhook_secret: str


def get_tenant_stripe_config(tenant_id: str, db: Session) -> Optional[TenantStripeConfig]:
    """Load and validate per-tenant Stripe credentials.

    Returns None (and logs a warning) when the tenant has no stripe_config
    or when the JSON is missing the required fields. Callers must treat
    None as "this tenant cannot accept card payments yet" and surface a
    clean error to the user.
    """
    site_config = (
        db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    )
    if not site_config or not site_config.stripe_config:
        logger.warning("Tenant %s has no stripe_config", tenant_id)
        return None

    try:
        raw = json.loads(site_config.stripe_config)
    except (TypeError, ValueError) as exc:
        logger.warning("Tenant %s stripe_config is not valid JSON: %s", tenant_id, exc)
        return None

    publishable = (raw.get("publishableKey") or raw.get("publishable_key") or "").strip()
    secret = (raw.get("secretKey") or raw.get("secret_key") or "").strip()
    webhook = (raw.get("webhookSecret") or raw.get("webhook_secret") or "").strip()

    if not (publishable.startswith("pk_") and secret.startswith("sk_") and webhook.startswith("whsec_")):
        logger.warning(
            "Tenant %s stripe_config has malformed values "
            "(publishable starts with %r, secret starts with %r, webhook starts with %r)",
            tenant_id,
            publishable[:3],
            secret[:3],
            webhook[:6],
        )
        return None

    return TenantStripeConfig(
        publishable_key=publishable,
        secret_key=secret,
        webhook_secret=webhook,
    )
