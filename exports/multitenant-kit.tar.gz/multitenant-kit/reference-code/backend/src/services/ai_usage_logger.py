"""Shared OpenAI usage logger — used by every AI endpoint that needs to
land a row in growth_ai_generation_usage.

Pricing tables are kept here so all AI features (Growth Center, Îmbunătățește
cu AI pe descrieri, Traduce cu AI, etc.) compute cost the same way.
"""
from __future__ import annotations

import datetime as dt
import uuid
from typing import Dict, Optional

from sqlalchemy.orm import Session

from src.models import AIGenerationUsage
from src.services.cost_pricing import compute_openai_cost_cents


def compute_cost_cents(usage: Dict[str, int], model: str, db: Session) -> int:
    """Cost in bani (RON cents) from an OpenAI usage dict — uses live config."""
    return compute_openai_cost_cents(usage, model, db)


def log_ai_usage(
    db: Session,
    *,
    tenant_id: Optional[str],
    user_id: Optional[str],
    model: str,
    usage: Dict[str, int],
    kind: str = "text",
    related_kind: Optional[str] = None,
    related_id: Optional[str] = None,
    commit: bool = True,
) -> Optional[AIGenerationUsage]:
    """Insert one row in growth_ai_generation_usage. Returns the row.

    `tenant_id` is required by the table schema, so callers without a
    tenant context (e.g. a super-admin acting on the platform) skip the
    log; the function silently returns None in that case.
    """
    if not tenant_id:
        return None
    now = dt.datetime.utcnow()
    row = AIGenerationUsage(
        id=uuid.uuid4().hex,
        tenant_id=tenant_id,
        kind=kind,
        provider="openai",
        model=model,
        tokens_input=int(usage.get("prompt_tokens", 0) or 0) or None,
        tokens_output=int(usage.get("completion_tokens", 0) or 0) or None,
        image_count=None,
        cost_cents=compute_cost_cents(usage, model, db),
        plan_at_time=None,
        period_year=now.year,
        period_month=now.month,
        related_kind=related_kind,
        related_id=related_id,
        request_user_id=user_id,
    )
    db.add(row)
    if commit:
        db.commit()
    return row
