"""Sync plan_catalog rows -> Stripe Products + Prices.

Stripe Prices are immutable on amount/currency/interval. To "change" a
price we create a new one and deactivate the old. The Product itself is
updateable (name, description) so we keep one Product per catalog row
across price changes.

Idempotent: re-running the sync on an already-up-to-date plan only
issues a Product retrieve + 2 Price retrieves (no new resources created).
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from sqlalchemy.orm import Session

from src.core.config import settings
from src.models.plan_catalog import PlanCatalog


class StripeSyncError(Exception):
    pass


def _stripe():
    secret = settings.STRIPE_SECRET_KEY
    if not secret:
        raise StripeSyncError("STRIPE_SECRET_KEY not configured")
    import stripe
    stripe.api_key = secret
    return stripe


def _ron_minor_units(amount) -> int:
    """Convert decimal RON (e.g. 199.00) to bani (19900) for Stripe."""
    return int(round(float(amount) * 100))


def _ensure_product(stripe, plan: PlanCatalog) -> str:
    """Create or update the Stripe Product for this plan. Returns product id."""
    metadata = {
        "plan_catalog_id": plan.id,
        "plan_catalog_slug": plan.slug,
    }
    if plan.stripe_product_id:
        try:
            stripe.Product.modify(
                plan.stripe_product_id,
                name=plan.name,
                description=(plan.short_description or "")[:500] or None,
                metadata=metadata,
                active=bool(plan.is_active),
            )
            return plan.stripe_product_id
        except Exception:
            # Product may have been deleted on the Stripe side; recreate.
            plan.stripe_product_id = None
    product = stripe.Product.create(
        name=plan.name,
        description=(plan.short_description or "")[:500] or None,
        metadata=metadata,
        active=bool(plan.is_active),
    )
    return product.id


def _ensure_price(stripe, product_id: str, plan: PlanCatalog,
                  interval: str, amount, current_price_id: Optional[str]) -> Optional[str]:
    """Ensure a recurring Price exists for `amount` at `interval`. Returns id or None for amount==0."""
    if not amount or float(amount) <= 0:
        # If a price was previously assigned but now the catalog row has 0,
        # deactivate the old price so it can't be picked at checkout.
        if current_price_id:
            try:
                stripe.Price.modify(current_price_id, active=False)
            except Exception:
                pass
        return None

    minor = _ron_minor_units(amount)
    currency = (plan.currency or "RON").lower()

    # Verify the linked price still matches; otherwise deactivate + recreate.
    if current_price_id:
        try:
            existing = stripe.Price.retrieve(current_price_id)
            same_amount = int(existing.unit_amount or 0) == minor
            same_currency = (existing.currency or "").lower() == currency
            same_interval = (existing.recurring or {}).get("interval") == ("year" if interval == "yearly" else "month")
            same_active = bool(existing.active)
            if same_amount and same_currency and same_interval and same_active:
                return current_price_id
            # Out of sync — deactivate the old price.
            stripe.Price.modify(current_price_id, active=False)
        except Exception:
            pass  # Price disappeared — fall through and create a new one.

    new_price = stripe.Price.create(
        product=product_id,
        unit_amount=minor,
        currency=currency,
        recurring={"interval": "year" if interval == "yearly" else "month"},
        nickname=f"{plan.slug}-{interval}",
        metadata={"plan_catalog_id": plan.id, "interval": interval},
    )
    return new_price.id


def sync_plan(db: Session, plan: PlanCatalog) -> dict:
    """Sync one catalog row to Stripe. Returns a small status dict."""
    stripe = _stripe()
    product_id = _ensure_product(stripe, plan)
    monthly_id = _ensure_price(stripe, product_id, plan, "monthly",
                               plan.monthly_price, plan.stripe_monthly_price_id)
    yearly_id = _ensure_price(stripe, product_id, plan, "yearly",
                              plan.annual_price, plan.stripe_yearly_price_id)

    plan.stripe_product_id = product_id
    plan.stripe_monthly_price_id = monthly_id
    plan.stripe_yearly_price_id = yearly_id
    plan.stripe_synced_at = datetime.utcnow()
    db.commit()
    db.refresh(plan)

    return {
        "plan_id": plan.id,
        "slug": plan.slug,
        "stripe_product_id": product_id,
        "stripe_monthly_price_id": monthly_id,
        "stripe_yearly_price_id": yearly_id,
        "synced_at": plan.stripe_synced_at.isoformat(),
    }


def sync_all(db: Session) -> list[dict]:
    """Sync every active catalog row. Continues on per-plan errors."""
    rows = db.query(PlanCatalog).filter(PlanCatalog.is_active.is_(True)).all()
    results: list[dict] = []
    for r in rows:
        try:
            results.append(sync_plan(db, r))
        except Exception as e:
            results.append({"plan_id": r.id, "slug": r.slug, "error": str(e)})
    return results
