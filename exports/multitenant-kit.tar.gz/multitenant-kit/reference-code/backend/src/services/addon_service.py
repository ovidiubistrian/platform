"""
Generic add-on fulfilment + consumption.

Grants a TenantAddOn row from a package id, covering the three supported
types:
    - sms_pack      → sets sms_remaining from package.quantity (one-shot)
    - email_pack    → sets email_remaining from package.quantity (one-shot)
    - business_email → monthly subscription, expires_at = activated_at + 30d

Also provides consume_email_credits() used by the campaign send path to
decrement email_pack credits FIFO by created_at.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from src.models.addon_package import (
    AddOnPackage,
    TenantAddOn,
    ADDON_TYPE_SMS_PACK,
    ADDON_TYPE_EMAIL_PACK,
    ADDON_TYPE_BUSINESS_EMAIL,
    TENANT_ADDON_STATUS_ACTIVE,
)


class InsufficientEmailCreditsError(Exception):
    def __init__(self, tenant_id: str, required: int, available: int):
        self.tenant_id = tenant_id
        self.required = required
        self.available = available
        super().__init__(
            f"Tenant {tenant_id} has {available} email credits, needs {required}"
        )


def grant(
    db: Session,
    tenant_id: str,
    addon_package_id: str,
    *,
    notes: Optional[str] = None,
) -> TenantAddOn:
    """Grant an add-on package to a tenant. Type-aware: sets the right
    credit counters and expiration for each of the three supported types."""
    pkg = db.query(AddOnPackage).filter(AddOnPackage.id == addon_package_id).first()
    if not pkg:
        raise ValueError(f"Add-on package {addon_package_id} not found")

    now = datetime.utcnow()
    addon = TenantAddOn(
        id=str(uuid.uuid4()),
        tenant_id=tenant_id,
        addon_package_id=pkg.id,
        status=TENANT_ADDON_STATUS_ACTIVE,
        activated_at=now,
        notes=notes,
    )

    if pkg.type == ADDON_TYPE_SMS_PACK:
        if not pkg.quantity:
            raise ValueError("SMS pack must have a quantity")
        addon.sms_remaining = int(pkg.quantity)
    elif pkg.type == ADDON_TYPE_EMAIL_PACK:
        if not pkg.quantity:
            raise ValueError("Email pack must have a quantity")
        addon.email_remaining = int(pkg.quantity)
    elif pkg.type == ADDON_TYPE_BUSINESS_EMAIL:
        # Monthly subscription — expires in 30 days, renewed by Stripe
        # invoice.payment_succeeded webhook.
        addon.expires_at = now + timedelta(days=30)
    else:
        raise ValueError(f"Unsupported add-on type: {pkg.type}")

    db.add(addon)
    db.flush()
    return addon


def renew_business_email(db: Session, tenant_id: str, addon_package_id: str) -> TenantAddOn:
    """Extend the tenant's active business_email subscription by 30 days, or
    create one if none exists. Used by the invoice.payment_succeeded webhook
    on recurring renewals."""
    now = datetime.utcnow()
    addon = (
        db.query(TenantAddOn)
        .filter(
            TenantAddOn.tenant_id == tenant_id,
            TenantAddOn.addon_package_id == addon_package_id,
            TenantAddOn.status == TENANT_ADDON_STATUS_ACTIVE,
        )
        .order_by(TenantAddOn.created_at.desc())
        .first()
    )
    if addon is None:
        return grant(db, tenant_id, addon_package_id, notes="auto-renew")

    # Extend from whichever is later: now or current expires_at.
    base = addon.expires_at if addon.expires_at and addon.expires_at > now else now
    addon.expires_at = base + timedelta(days=30)
    db.flush()
    return addon


def _sum_email_remaining(db: Session, tenant_id: str) -> int:
    rows = (
        db.query(TenantAddOn.email_remaining)
        .join(AddOnPackage, AddOnPackage.id == TenantAddOn.addon_package_id)
        .filter(
            TenantAddOn.tenant_id == tenant_id,
            TenantAddOn.status == TENANT_ADDON_STATUS_ACTIVE,
            AddOnPackage.type == ADDON_TYPE_EMAIL_PACK,
        )
        .all()
    )
    return sum(int(r[0] or 0) for r in rows)


def get_email_balance(db: Session, tenant_id: str) -> dict:
    """Return current email credit snapshot for display."""
    return {"addon_remaining": _sum_email_remaining(db, tenant_id)}


def consume_email_credits(db: Session, tenant_id: str, count: int) -> None:
    """Decrement `count` credits from active email_pack rows, FIFO by
    created_at. Raises InsufficientEmailCreditsError if total across active
    packs is less than `count`. Caller commits."""
    if count <= 0:
        return
    available = _sum_email_remaining(db, tenant_id)
    if available < count:
        raise InsufficientEmailCreditsError(tenant_id, required=count, available=available)

    remaining = count
    packs = (
        db.query(TenantAddOn)
        .join(AddOnPackage, AddOnPackage.id == TenantAddOn.addon_package_id)
        .filter(
            TenantAddOn.tenant_id == tenant_id,
            TenantAddOn.status == TENANT_ADDON_STATUS_ACTIVE,
            AddOnPackage.type == ADDON_TYPE_EMAIL_PACK,
            TenantAddOn.email_remaining > 0,
        )
        .order_by(TenantAddOn.created_at.asc())
        .with_for_update()
        .all()
    )
    for pack in packs:
        if remaining <= 0:
            break
        take = min(int(pack.email_remaining or 0), remaining)
        pack.email_remaining = int(pack.email_remaining or 0) - take
        remaining -= take
    if remaining > 0:
        # Should not happen given the pre-check, but guard just in case.
        raise InsufficientEmailCreditsError(tenant_id, required=count, available=count - remaining)


def has_active_business_email(db: Session, tenant_id: str) -> bool:
    now = datetime.utcnow()
    row = (
        db.query(TenantAddOn)
        .join(AddOnPackage, AddOnPackage.id == TenantAddOn.addon_package_id)
        .filter(
            TenantAddOn.tenant_id == tenant_id,
            TenantAddOn.status == TENANT_ADDON_STATUS_ACTIVE,
            AddOnPackage.type == ADDON_TYPE_BUSINESS_EMAIL,
        )
        .first()
    )
    if row is None:
        return False
    if row.expires_at is not None and row.expires_at < now:
        return False
    return True
