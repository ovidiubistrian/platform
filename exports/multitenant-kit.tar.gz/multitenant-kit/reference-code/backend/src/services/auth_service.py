"""
Authentication service - Business logic for authentication.
"""
import json
import secrets
import uuid
from datetime import datetime, timedelta
from typing import Optional, Tuple, Dict, Any
from sqlalchemy.orm import Session
from sqlalchemy import and_, inspect, text

from src.models.user import User

# In-memory store for pending 2FA sessions: session_id -> { user_id, otp_code, email, expires }
# Pentru producție multi-worker, folosește Redis
_two_factor_sessions: Dict[str, Dict[str, Any]] = {}
from src.models.tenant import Tenant
from src.models.property import Property
from src.core.security import get_password_hash, verify_password
from src.services.email_service import EmailService


class AuthService:
    """Service for authentication business logic."""

    @staticmethod
    def _table_columns(db: Session, table_name: str) -> set[str]:
        """Return existing DB columns for a table (runtime compatibility)."""
        try:
            inspector = inspect(db.bind)
            cols = inspector.get_columns(table_name)
            return {str(c.get("name")) for c in cols if c.get("name")}
        except Exception:
            return set()
    
    @staticmethod
    def generate_slug(business_name: str) -> str:
        """Generate a URL-friendly slug from business name."""
        import re
        slug = business_name.lower()
        slug = re.sub(r'[^a-z0-9\s-]', '', slug)
        slug = re.sub(r'\s+', '-', slug)
        slug = re.sub(r'-+', '-', slug)
        return slug.strip()
    
    @staticmethod
    def ensure_unique_slug(db: Session, base_slug: str) -> str:
        """Ensure slug is unique by appending counter if needed."""
        final_slug = base_slug
        counter = 1
        while db.query(Tenant).filter(Tenant.slug == final_slug).first():
            final_slug = f"{base_slug}-{counter}"
            counter += 1
        return final_slug
    
    @staticmethod
    def generate_verification_token() -> Tuple[str, datetime]:
        """Generate email verification token."""
        token = secrets.token_urlsafe(32)
        expires = datetime.utcnow() + timedelta(hours=24)
        return token, expires
    
    @staticmethod
    def generate_reset_token() -> Tuple[str, datetime]:
        """Generate password reset token."""
        token = secrets.token_urlsafe(32)
        expires = datetime.utcnow() + timedelta(hours=1)
        return token, expires
    
    @staticmethod
    async def register_user(
        db: Session,
        name: str,
        email: str,
        password: str,
        business_name: str,
        business_type: Optional[str] = None,
        rental_mode: Optional[str] = None,
        sales_code: Optional[str] = None,
        product_type: Optional[str] = None,
    ) -> Tuple[User, Tenant]:
        # Product type drives which sidebar/public sections appear.
        # Default keeps backwards-compatible behavior: everyone who
        # signed up before this feature gets "accommodation".
        allowed_product_types = {"accommodation", "restaurant", "both"}
        normalized_product_type = (product_type or "accommodation").strip().lower()
        if normalized_product_type not in allowed_product_types:
            raise ValueError(
                "product_type invalid. Valori permise: accommodation, restaurant, both"
            )

        allowed_property_types = {"villa", "hotel", "pension", "resort", "apartment", "camping"}
        # Restaurant-only signups don't pick a property type, but the legacy
        # tenant settings blob still expects one. Stamp "pension" as a harmless
        # default so the rest of the pipeline keeps working.
        default_property_type = "pension" if normalized_product_type != "restaurant" else "pension"
        normalized_property_type = (business_type or default_property_type).strip().lower()
        if normalized_property_type == "pensiune":
            normalized_property_type = "pension"
        if normalized_property_type == "guesthouse":
            normalized_property_type = "pension"
        if normalized_property_type in ("vila", "vilă"):
            normalized_property_type = "villa"
        if normalized_property_type not in allowed_property_types:
            raise ValueError(
                "Tip proprietate invalid. Valorile acceptate: villa, hotel, pension, resort, apartment, camping"
            )

        if normalized_property_type == "pension" and normalized_product_type != "restaurant":
            normalized_rental_mode = (rental_mode or "by_room").strip().lower()
            if normalized_rental_mode not in {"by_room", "whole_property"}:
                raise ValueError("Pentru pension, rental_mode trebuie să fie by_room sau whole_property")
        else:
            normalized_rental_mode = "standard"

        """
        Register a new user and create tenant.
        Matches logic from app/api/auth/register/route.ts
        """
        # Normalize email
        normalized_email = email.lower().strip()
        
        # Check if user exists
        existing_user = db.query(User).filter(User.email == normalized_email).first()
        if existing_user:
            raise ValueError("Un cont cu acest email există deja")
        
        # Hash password
        hashed_password = get_password_hash(password)
        
        # Generate slug
        base_slug = AuthService.generate_slug(business_name)
        final_slug = AuthService.ensure_unique_slug(db, base_slug)
        
        # Generate verification token
        verification_token, verification_expires = AuthService.generate_verification_token()
        
        # Trial duration: prefer the chosen plan_catalog row's trial_days,
        # then platform billing settings, then 14. The plan slug is set during
        # onboarding step "Pachet"; at raw signup we default to booking-basic.
        from src.models.plan_catalog import PlanCatalog
        default_plan = db.query(PlanCatalog).filter(
            PlanCatalog.slug == "booking-basic", PlanCatalog.is_active.is_(True)
        ).first()
        trial_days = None
        if default_plan and default_plan.trial_days:
            trial_days = int(default_plan.trial_days)
        if trial_days is None:
            try:
                from src.services.access_control import get_billing_settings
                trial_days = int(get_billing_settings(db).get("trial_days") or 14)
            except Exception:
                trial_days = 14
        trial_end = datetime.utcnow() + timedelta(days=trial_days)
        tenant = Tenant(
            id=str(uuid.uuid4()),
            name=business_name,
            slug=final_slug,
            status="trial",
            subscription_plan="free",
            plan_catalog_id=default_plan.id if default_plan else None,
            subscription_ends_at=trial_end,
            max_properties=1,
            max_units=5,
            max_bookings=100,
            is_active=True,
            onboarding_completed=False,
            product_type=normalized_product_type,
            settings=json.dumps({
                "businessType": normalized_property_type,
                "rentalMode": normalized_rental_mode,
                "theme": "pine-hill",
                "currency": "RON",
                "language": "ro"
            }),
        )
        db.add(tenant)
        db.flush()  # Get tenant.id

        # Cod promoțional opțional — dacă nu există sau nu e valid, mergem înainte
        # fără eroare. Niciodată nu bloca signup-ul dacă codul lipsește sau e greșit.
        if sales_code and sales_code.strip():
            try:
                from src.models.sales_code import SalesCode as _SalesCode
                code_str = sales_code.strip().upper()
                sc = db.query(_SalesCode).filter(
                    _SalesCode.code == code_str,
                    _SalesCode.is_active == True,  # noqa: E712
                ).first()
                if sc:
                    tenant.referral_sales_code = sc.code
                    tenant.referral_sales_user_id = sc.sales_user_id
                    db.flush()
                else:
                    import logging
                    logging.getLogger(__name__).info(
                        "signup: sales_code='%s' not found or inactive — ignored", code_str
                    )
            except Exception:
                import logging
                logging.getLogger(__name__).exception("signup: sales_code lookup failed — ignoring")

        settings_currency = "RON"
        try:
            parsed = json.loads(tenant.settings) if tenant.settings else {}
            if isinstance(parsed, dict) and parsed.get("currency"):
                settings_currency = str(parsed["currency"])
        except Exception:
            pass

        # Create one default property per tenant (one tenant = one client = one property business).
        # Runtime-safe insert: works even if DB has not yet received newest columns.
        property_columns = AuthService._table_columns(db, "properties")
        property_values: Dict[str, Any] = {
            "id": str(uuid.uuid4()),
            "tenant_id": tenant.id,
            "name": business_name,
            "description": None,
            "address": None,
            "phone": None,
            "email": None,
            "property_type": normalized_property_type,
            "rental_mode": normalized_rental_mode,
            "timezone": None,
            "currency": settings_currency,
            "check_in_time": "14:00",
            "check_out_time": "12:00",
            "google_calendar_id": None,
            "active": True,
        }
        if property_columns:
            insert_columns = [c for c in property_values.keys() if c in property_columns]
            if insert_columns:
                sql = (
                    f"INSERT INTO properties ({', '.join(insert_columns)}) "
                    f"VALUES ({', '.join(f':{c}' for c in insert_columns)})"
                )
                db.execute(text(sql), {c: property_values[c] for c in insert_columns})
        else:
            # Fallback to ORM path when column introspection is unavailable.
            default_property = Property(
                id=property_values["id"],
                tenant_id=property_values["tenant_id"],
                name=property_values["name"],
                description=property_values["description"],
                check_in_time=property_values["check_in_time"],
                check_out_time=property_values["check_out_time"],
                active=property_values["active"],
            )
            db.add(default_property)
            db.flush()
        
        # Create user
        user = User(
            id=str(uuid.uuid4()),
            name=name,
            email=normalized_email,
            password=hashed_password,
            role="tenant_admin",
            tenant_id=tenant.id,
            is_active=True,
            email_verified=True,  # Allow immediate login
            email_verification_token=verification_token,
            email_verification_expires=verification_expires,
        )
        db.add(user)
        db.flush()

        # Restaurant-first tenants land on a published restaurant page
        # immediately — no extra "click Publică" step after signup.
        if normalized_product_type in ("restaurant", "both"):
            try:
                from src.models.restaurant import Restaurant as _Restaurant
                existing_restaurant = db.query(_Restaurant).filter(
                    _Restaurant.tenant_id == tenant.id
                ).first()
                if not existing_restaurant:
                    restaurant_id = str(uuid.uuid4())
                    db.add(_Restaurant(
                        id=restaurant_id,
                        tenant_id=tenant.id,
                        name=business_name or "Restaurant",
                        reservation_type="in_house",
                        reservations_enabled=True,
                        seat_management_enabled=True,
                        allow_walk_ins=True,
                        orders_enabled=True,
                        online_ordering_enabled=True,
                        is_published=True,
                        publish_status="published",
                        active=True,
                        created_at=datetime.utcnow(),
                        updated_at=datetime.utcnow(),
                    ))
                    db.flush()

                    # Seed default menu categories atomically here so the
                    # parallel requests from the first admin page-load can't
                    # race `ensure_default_categories` and each insert its
                    # own duplicate set.
                    from src.api.restaurant import DEFAULT_MENU_CATEGORIES, to_slug
                    from src.models.restaurant import RestaurantMenuCategory as _Cat
                    for index, category in enumerate(DEFAULT_MENU_CATEGORIES):
                        db.add(_Cat(
                            id=str(uuid.uuid4()),
                            tenant_id=tenant.id,
                            restaurant_id=restaurant_id,
                            name=category["name"],
                            description=category["description"],
                            slug=to_slug(category["name"]),
                            display_order=index,
                            is_visible=True,
                            created_at=datetime.utcnow(),
                            updated_at=datetime.utcnow(),
                        ))
                    db.flush()
            except Exception:
                import logging
                logging.getLogger(__name__).exception("signup: failed to auto-create restaurant row")

        # TODO: Create default SiteConfig (when SiteConfig model is created)
        # TODO: Create default Property (when Property model is created)
        
        # Send verification email (platform: uses SuperAdminMailgunConfig 360booking.ro)
        email_service = EmailService()
        verification_url = f"{email_service.get_base_url()}/auth/verify-email?token={verification_token}"
        await email_service.send_verification_email(
            email=normalized_email,
            name=name,
            verification_url=verification_url,
            db=db,
        )

        # Notificare Super Admin: nou tenant înregistrat
        try:
            subject = f"[360booking] Nou tenant: {business_name}"
            html = f"<p>Tenant nou: <strong>{business_name}</strong> (slug: {final_slug}), email: {normalized_email}</p>"
            await email_service.send_notification_to_super_admin(subject=subject, html=html, db=db)
        except Exception:
            pass  # Don't fail registration if notification fails

        # In-app + per-user email pentru fiecare super-admin cu preferința activă
        try:
            from src.services.notification_service import emit_new_tenant
            emit_new_tenant(db, tenant_id=tenant.id, tenant_name=business_name, tenant_slug=final_slug)
        except Exception:
            pass

        db.commit()
        db.refresh(user)
        db.refresh(tenant)
        
        return user, tenant
    
    
    @staticmethod
    async def forgot_password(db: Session, email: str) -> None:
        """Send password reset email."""
        normalized_email = email.lower().strip()
        
        user = db.query(User).filter(User.email == normalized_email).first()
        
        # Don't reveal if user exists (security)
        if not user:
            return
        
        # Generate reset token
        reset_token, reset_expires = AuthService.generate_reset_token()
        
        user.reset_password_token = reset_token
        user.reset_password_expires = reset_expires
        db.commit()
        
        # Send reset email (platform: uses SuperAdminMailgunConfig 360booking.ro)
        email_service = EmailService()
        reset_url = f"{email_service.get_base_url()}/auth/reset-password?token={reset_token}"
        await email_service.send_password_reset_email(
            email=normalized_email,
            name=user.name or "Utilizator",
            reset_url=reset_url,
            db=db,
        )
    
    @staticmethod
    def reset_password(db: Session, token: str, new_password: str) -> User:
        """Reset password with token."""
        if len(new_password) < 8:
            raise ValueError("Parola trebuie să aibă cel puțin 8 caractere")
        
        user = db.query(User).filter(
            and_(
                User.reset_password_token == token,
                User.reset_password_expires > datetime.utcnow()
            )
        ).first()
        
        if not user:
            raise ValueError("Token invalid sau expirat")
        
        # Hash new password
        user.password = get_password_hash(new_password)
        user.reset_password_token = None
        user.reset_password_expires = None
        
        db.commit()
        db.refresh(user)
        
        return user

    @staticmethod
    async def send_two_factor_enabled_email(db: Session, user_id: str) -> None:
        """Trimite email de confirmare când utilizatorul activează 2FA."""
        user = db.query(User).filter(User.id == user_id).first()
        if not user or not user.email:
            raise ValueError("User not found")
        email_service = EmailService()
        await email_service.send_two_factor_enabled_email(
            email=user.email,
            name=user.name or "Utilizator",
            tenant_id=user.tenant_id,
            db=db,
        )
    
    @staticmethod
    async def send_verification_email(db: Session, user_id: str) -> None:
        """Send verification email to user."""
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise ValueError("User not found")
        
        if user.email_verified:
            raise ValueError("Email already verified")
        
        # Generate new token
        verification_token, verification_expires = AuthService.generate_verification_token()
        
        user.email_verification_token = verification_token
        user.email_verification_expires = verification_expires
        db.commit()
        
        # Send email (platform: uses SuperAdminMailgunConfig 360booking.ro)
        email_service = EmailService()
        verification_url = f"{email_service.get_base_url()}/auth/verify-email?token={verification_token}"
        await email_service.send_verification_email(
            email=user.email,
            name=user.name or "Utilizator",
            verification_url=verification_url,
            db=db,
        )
    
    @staticmethod
    def verify_email(db: Session, token: str) -> User:
        """Verify user email with token."""
        user = db.query(User).filter(
            and_(
                User.email_verification_token == token,
                User.email_verification_expires > datetime.utcnow()
            )
        ).first()
        
        if not user:
            raise ValueError("Token invalid sau expirat")
        
        user.email_verified = True
        user.email_verification_token = None
        user.email_verification_expires = None
        
        db.commit()
        db.refresh(user)
        
        # Send confirmation email (platform: uses SuperAdminMailgunConfig 360booking.ro)
        email_service = EmailService()
        try:
            import asyncio
            loop = asyncio.get_event_loop()
            loop.create_task(
                email_service.send_confirmation_email(user.email, user.name or "Utilizator", db=db)
            )
        except:
            # If no event loop, just log
            pass
        
        return user

    @staticmethod
    def _clean_expired_2fa_sessions() -> None:
        """Remove expired 2FA sessions from store."""
        now = datetime.utcnow()
        expired = [sid for sid, data in _two_factor_sessions.items() if data["expires"] < now]
        for sid in expired:
            del _two_factor_sessions[sid]

    @staticmethod
    async def create_two_factor_session(db: Session, user: User) -> str:
        """Create pending 2FA session, send OTP email, return session_id."""
        AuthService._clean_expired_2fa_sessions()
        otp_code = "".join(secrets.choice("0123456789") for _ in range(6))
        session_id = secrets.token_urlsafe(32)
        expires = datetime.utcnow() + timedelta(minutes=10)
        _two_factor_sessions[session_id] = {
            "user_id": user.id,
            "otp_code": otp_code,
            "email": user.email,
            "expires": expires,
        }
        email_service = EmailService()
        # Platform config (360booking.ro) pentru OTP la login
        await email_service.send_otp_email(
            email=user.email,
            name=user.name or "Utilizator",
            otp_code=otp_code,
            tenant_id=user.tenant_id,
            db=db,
        )
        return session_id

    @staticmethod
    def get_two_factor_session(session_id: str) -> Optional[Dict[str, Any]]:
        """Get pending 2FA session (email for display). Returns None if invalid/expired."""
        AuthService._clean_expired_2fa_sessions()
        data = _two_factor_sessions.get(session_id)
        if not data or data["expires"] < datetime.utcnow():
            return None
        return {"email": data["email"], "user_id": data["user_id"]}

    @staticmethod
    def verify_two_factor_and_consume(session_id: str, verification_code: str, db: Session) -> Optional[User]:
        """Verify OTP and consume session. Returns User if valid, None otherwise."""
        AuthService._clean_expired_2fa_sessions()
        data = _two_factor_sessions.get(session_id)
        if not data or data["expires"] < datetime.utcnow():
            return None
        if data["otp_code"] != verification_code.strip():
            return None
        user_id = data["user_id"]
        del _two_factor_sessions[session_id]
        user = db.query(User).filter(User.id == user_id).first()
        return user

