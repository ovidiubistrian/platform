"""
Thin OpenAI HTTP wrapper shared by all AI features (chat support,
translations, text improvement, generation).

Uses the key from `ai_config.get_openai_api_key()` which reads the
super-admin-saved config first, then the OPENAI_API_KEY env var.

Why raw httpx and not the openai SDK? Keeps dependencies light and
matches the pattern already in api/ai.py + api/translations.py.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx

from src.core.ai_config import get_openai_api_key


DEFAULT_CHAT_MODEL = "gpt-4o-mini"
DEFAULT_EMBED_MODEL = "text-embedding-3-small"  # 1536 dims, cheap, good enough
_OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
_OPENAI_EMBED_URL = "https://api.openai.com/v1/embeddings"


class AIClientError(Exception):
    """Raised when OpenAI call fails or is misconfigured."""


async def chat_completion(
    messages: List[Dict[str, Any]],
    *,
    model: str = DEFAULT_CHAT_MODEL,
    max_tokens: int = 600,
    temperature: float = 0.4,
    response_format: Optional[Dict[str, Any]] = None,
    tools: Optional[List[Dict[str, Any]]] = None,
    tool_choice: Optional[Any] = None,
    timeout_s: float = 30.0,
) -> Dict[str, Any]:
    """
    Call OpenAI chat completions. Returns the full decoded JSON body so
    callers can read both content + usage + tool_calls.
    """
    key = get_openai_api_key()
    if not key:
        raise AIClientError("OpenAI API key not configured")

    payload: Dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
    }
    if response_format:
        payload["response_format"] = response_format
    if tools:
        payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            _OPENAI_CHAT_URL,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=timeout_s,
        )
    if resp.status_code != 200:
        raise AIClientError(
            f"OpenAI returned {resp.status_code}: {resp.text[:300]}"
        )
    return resp.json()


async def embed_texts(
    texts: List[str],
    *,
    model: str = DEFAULT_EMBED_MODEL,
    timeout_s: float = 30.0,
) -> List[List[float]]:
    """
    Embed a batch of texts. Returns parallel list of vectors.
    Batches up to ~100 per call which comfortably fits OpenAI's limit.
    """
    key = get_openai_api_key()
    if not key:
        raise AIClientError("OpenAI API key not configured")
    if not texts:
        return []

    async with httpx.AsyncClient() as client:
        resp = await client.post(
            _OPENAI_EMBED_URL,
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
            },
            json={"model": model, "input": texts},
            timeout=timeout_s,
        )
    if resp.status_code != 200:
        raise AIClientError(
            f"OpenAI embeddings returned {resp.status_code}: {resp.text[:300]}"
        )
    data = resp.json()
    # Sort by index to be safe, even though the API preserves order.
    items = sorted(data.get("data", []), key=lambda d: d.get("index", 0))
    return [item.get("embedding", []) for item in items]


def extract_text(completion: Dict[str, Any]) -> str:
    """Pull the first-choice assistant message content out of a completion."""
    try:
        return (
            completion.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
            or ""
        ).strip()
    except Exception:
        return ""
