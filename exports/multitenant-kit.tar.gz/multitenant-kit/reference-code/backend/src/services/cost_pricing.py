"""Cost pricing config — single source of truth for the per-unit costs
used everywhere in the cost dashboard.

Stored as a JSON blob in system_configs row `cost_pricing`. Super admins
edit it from `/super-admin/cost-dashboard` (Faza 2/3 endpoint). All
prices are kept as **bani RON** (cents) per natural unit so we never
mix USD ↔ RON conversion at call sites.
"""
from __future__ import annotations

import json
import math
from typing import Any, Dict

from sqlalchemy import text
from sqlalchemy.orm import Session


CONFIG_KEY = "cost_pricing"


# Defaults seeded on first read. Values reflect public OpenAI/Mailgun/SMSLink
# prices as of January 2026. Super admin can override any value from the UI.
DEFAULT_PRICING: Dict[str, Any] = {
    "currency": "RON",
    "usd_to_ron": 5.0,
    # OpenAI per 1M tokens, in USD. Multiply by usd_to_ron at call site.
    "openai_models": {
        "gpt-4o-mini":   {"input_usd_per_1m": 0.150, "output_usd_per_1m": 0.600},
        "gpt-4o":        {"input_usd_per_1m": 5.0,   "output_usd_per_1m": 20.0},
        "gpt-3.5-turbo": {"input_usd_per_1m": 0.50,  "output_usd_per_1m": 1.50},
        "gpt-4-turbo":   {"input_usd_per_1m": 10.0,  "output_usd_per_1m": 30.0},
    },
    # Per-unit prices in BANI (RON cents). Edit-friendly.
    "sms_cost_cents_per_message": 25,        # 0.25 RON
    "email_cost_cents_per_message": 1,       # 0.01 RON (Mailgun ~$0.0008)
    "maps_load_cost_cents_per_load": 4,      # 0.04 RON (~$7/1000 loads * 5 RON/USD)
    "google_places_cost_cents_per_call": 5,  # 0.05 RON (~$10/1000 ~Place Details)
}


def get_pricing(db: Session) -> Dict[str, Any]:
    """Return the active pricing config, seeded with defaults if missing.

    Reads from system_configs(key='cost_pricing'). Missing keys fall back
    to defaults so old rows stay valid after we add a new metric.
    """
    row = db.execute(
        text("SELECT value FROM system_configs WHERE key = :key"),
        {"key": CONFIG_KEY},
    ).first()
    raw: Dict[str, Any] = {}
    if row and row[0]:
        try:
            raw = json.loads(row[0]) if isinstance(row[0], str) else dict(row[0])
        except Exception:
            raw = {}
    merged: Dict[str, Any] = {**DEFAULT_PRICING, **raw}
    # Deep-merge openai_models so a partial override doesn't drop other models.
    merged["openai_models"] = {
        **DEFAULT_PRICING["openai_models"],
        **(raw.get("openai_models") or {}),
    }
    return merged


def set_pricing(db: Session, payload: Dict[str, Any]) -> Dict[str, Any]:
    """Upsert the pricing config. Returns the merged result."""
    current = get_pricing(db)
    next_value = {**current, **(payload or {})}
    if "openai_models" in (payload or {}):
        next_value["openai_models"] = {
            **current["openai_models"],
            **(payload.get("openai_models") or {}),
        }
    db.execute(
        text("""
            INSERT INTO system_configs (key, value)
            VALUES (:key, :value)
            ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
        """),
        {"key": CONFIG_KEY, "value": json.dumps(next_value, ensure_ascii=False)},
    )
    db.commit()
    return next_value


def compute_openai_cost_cents(usage: Dict[str, int], model: str, db: Session) -> int:
    """Cost in bani for one OpenAI completion, using current pricing."""
    pricing = get_pricing(db)
    models = pricing.get("openai_models") or {}
    p = models.get(model) or models.get("gpt-4o-mini") or DEFAULT_PRICING["openai_models"]["gpt-4o-mini"]
    rate = float(pricing.get("usd_to_ron") or DEFAULT_PRICING["usd_to_ron"])
    prompt_tokens = int(usage.get("prompt_tokens", 0) or 0)
    completion_tokens = int(usage.get("completion_tokens", 0) or 0)
    cost_usd = (
        prompt_tokens * (float(p["input_usd_per_1m"]) / 1_000_000.0)
        + completion_tokens * (float(p["output_usd_per_1m"]) / 1_000_000.0)
    )
    cost_ron = cost_usd * rate
    return max(1, math.ceil(cost_ron * 100))


def per_unit_cents(metric: str, db: Session) -> int:
    """Per-unit cost in bani for SMS / email / maps / google_places."""
    p = get_pricing(db)
    if metric == "sms":
        return int(p.get("sms_cost_cents_per_message") or 0)
    if metric == "email":
        return int(p.get("email_cost_cents_per_message") or 0)
    if metric == "maps":
        return int(p.get("maps_load_cost_cents_per_load") or 0)
    if metric == "google_places":
        return int(p.get("google_places_cost_cents_per_call") or 0)
    return 0
