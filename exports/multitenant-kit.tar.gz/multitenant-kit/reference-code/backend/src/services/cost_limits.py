"""Cost limit gate — checks current monthly usage against the per-tenant
limit (from tenant_cost_limits) and the platform default. Hard-blocks
with HTTP 402 when a metric would go over.

Metrics:
  - ai             : limit in cents (cumulative cost from growth_ai_generation_usage)
  - sms            : limit in count  (rows in outbound_sms in current month)
  - email          : limit in count  (sent_accepted from email_usage_monthly)
  - maps           : limit in count  (loads from maps_usage_counters)
  - google_places  : limit in cents  (cost_cents from gbp_usage_counters)

Super admins (is_super_admin=True) bypass every gate.
"""
from __future__ import annotations

import datetime as dt
import json
import uuid
from typing import Optional, Tuple

from fastapi import HTTPException, status
from sqlalchemy import text
from sqlalchemy.orm import Session


# Defaults agreed with super-admin 2026-05-03. Stored in system_configs row
# `cost_limit_defaults` so they are editable without redeploy.
DEFAULT_LIMITS = {
    "ai":            {"unit": "cents", "monthly_limit": 1000},   # 10 RON
    "sms":           {"unit": "count", "monthly_limit": 50},
    "email":         {"unit": "count", "monthly_limit": 200},
    "maps":          {"unit": "count", "monthly_limit": 1000},
    "google_places": {"unit": "cents", "monthly_limit": 1000},   # 10 RON
}

DEFAULTS_CONFIG_KEY = "cost_limit_defaults"


def _yyyymm() -> Tuple[int, int, str, int]:
    now = dt.datetime.utcnow()
    return now.year, now.month, f"{now.year:04d}-{now.month:02d}", now.year * 100 + now.month


def get_default_limits(db: Session) -> dict:
    row = db.execute(
        text("SELECT value FROM system_configs WHERE key = :key"),
        {"key": DEFAULTS_CONFIG_KEY},
    ).first()
    raw = {}
    if row and row[0]:
        try:
            raw = json.loads(row[0]) if isinstance(row[0], str) else dict(row[0])
        except Exception:
            raw = {}
    out = {**DEFAULT_LIMITS}
    for k, v in raw.items():
        if k in out and isinstance(v, dict):
            out[k] = {**out[k], **v}
    return out


def set_default_limits(db: Session, payload: dict) -> dict:
    current = get_default_limits(db)
    for k, v in (payload or {}).items():
        if k in current and isinstance(v, dict):
            current[k] = {**current[k], **v}
    db.execute(
        text("""
            INSERT INTO system_configs (key, value)
            VALUES (:key, :value)
            ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
        """),
        {"key": DEFAULTS_CONFIG_KEY, "value": json.dumps(current, ensure_ascii=False)},
    )
    db.commit()
    return current


def get_tenant_limit(db: Session, tenant_id: str, metric: str) -> Tuple[int, str, bool]:
    """(limit, unit, is_override). Falls back to defaults if no row."""
    defaults = get_default_limits(db)
    default = defaults.get(metric, {"unit": "count", "monthly_limit": 0})
    unit = default["unit"]
    row = db.execute(
        text("""
            SELECT monthly_limit_cents, monthly_limit_count
            FROM tenant_cost_limits
            WHERE tenant_id = :t AND metric = :m
        """),
        {"t": tenant_id, "m": metric},
    ).first()
    if row:
        cents, count = row
        if unit == "cents" and cents is not None:
            return int(cents), unit, True
        if unit == "count" and count is not None:
            return int(count), unit, True
    return int(default["monthly_limit"]), unit, False


def set_tenant_limit(db: Session, tenant_id: str, metric: str, value: Optional[int]) -> None:
    """Upsert. value=None deletes the override (back to default)."""
    if value is None:
        db.execute(
            text("DELETE FROM tenant_cost_limits WHERE tenant_id = :t AND metric = :m"),
            {"t": tenant_id, "m": metric},
        )
        db.commit()
        return
    defaults = get_default_limits(db)
    unit = (defaults.get(metric) or {}).get("unit", "count")
    cents = int(value) if unit == "cents" else None
    count = int(value) if unit == "count" else None
    db.execute(
        text("""
            INSERT INTO tenant_cost_limits (id, tenant_id, metric, monthly_limit_cents, monthly_limit_count, created_at, updated_at)
            VALUES (:id, :t, :m, :cents, :count, NOW(), NOW())
            ON CONFLICT (tenant_id, metric) DO UPDATE SET
                monthly_limit_cents = EXCLUDED.monthly_limit_cents,
                monthly_limit_count = EXCLUDED.monthly_limit_count,
                updated_at = NOW()
        """),
        {"id": uuid.uuid4().hex, "t": tenant_id, "m": metric, "cents": cents, "count": count},
    )
    db.commit()


def get_current_usage(db: Session, tenant_id: str, metric: str) -> int:
    year, month, ym_str, ym_int = _yyyymm()
    if metric == "ai":
        r = db.execute(text("""
            SELECT COALESCE(SUM(cost_cents), 0)
            FROM growth_ai_generation_usage
            WHERE tenant_id = :t AND period_year = :y AND period_month = :m
        """), {"t": tenant_id, "y": year, "m": month}).scalar()
        return int(r or 0)
    if metric == "sms":
        start = dt.date(year, month, 1)
        end = dt.date(year + (1 if month == 12 else 0), (month % 12) + 1, 1)
        r = db.execute(text("""
            SELECT COUNT(*) FROM outbound_sms
            WHERE tenant_id = :t AND created_at >= :s AND created_at < :e
        """), {"t": tenant_id, "s": start, "e": end}).scalar()
        return int(r or 0)
    if metric == "email":
        r = db.execute(text("""
            SELECT COALESCE(SUM(sent_accepted), 0)
            FROM email_usage_monthly
            WHERE tenant_id = :t AND yyyymm = :ym
        """), {"t": tenant_id, "ym": ym_int}).scalar()
        return int(r or 0)
    if metric == "maps":
        r = db.execute(text("""
            SELECT COALESCE(loads, 0) FROM maps_usage_counters
            WHERE tenant_id = :t AND year_month = :ym
        """), {"t": tenant_id, "ym": ym_str}).scalar()
        return int(r or 0)
    if metric == "google_places":
        r = db.execute(text("""
            SELECT COALESCE(cost_cents, 0) FROM gbp_usage_counters
            WHERE tenant_id = :t AND year_month = :ym
        """), {"t": tenant_id, "ym": ym_str}).scalar()
        return int(r or 0)
    return 0


def enforce_limit(
    db: Session,
    *,
    tenant_id: Optional[str],
    metric: str,
    is_super_admin: bool = False,
    increment: int = 1,
) -> None:
    """Raise 402 if applying `increment` (in metric's unit) would exceed
    the tenant's monthly limit. Super-admins bypass."""
    if is_super_admin or not tenant_id:
        return
    limit, unit, _ = get_tenant_limit(db, tenant_id, metric)
    if limit <= 0:
        return  # 0 limit means unlimited (e.g. before defaults migrate)
    used = get_current_usage(db, tenant_id, metric)
    if used + max(0, increment) > limit:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail={
                "error": "cost_limit_reached",
                "metric": metric,
                "unit": unit,
                "used": used,
                "limit": limit,
                "message": (
                    f"Limita lunară pentru {metric} a fost atinsă "
                    f"({used}/{limit} {unit}). Contactează super-admin pentru extindere."
                ),
            },
        )


def increment_maps_load(db: Session, tenant_id: str) -> None:
    """One Maps JS load happened — bump the counter and store cost snapshot."""
    from src.services.cost_pricing import per_unit_cents
    cost_cents = per_unit_cents("maps", db)
    _, _, ym_str, _ = _yyyymm()
    db.execute(text("""
        INSERT INTO maps_usage_counters (id, tenant_id, year_month, loads, cost_cents, created_at, updated_at)
        VALUES (:id, :t, :ym, 1, :cost, NOW(), NOW())
        ON CONFLICT (tenant_id, year_month) DO UPDATE SET
            loads = maps_usage_counters.loads + 1,
            cost_cents = maps_usage_counters.cost_cents + :cost,
            updated_at = NOW()
    """), {"id": uuid.uuid4().hex, "t": tenant_id, "ym": ym_str, "cost": cost_cents})
    db.commit()
