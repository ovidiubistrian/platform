"""
Billing access control.

Central place that decides whether a tenant admin can use the admin UI.
Returns a structured snapshot the frontend can display, and a boolean
gate that the sensitive admin endpoints can enforce.

The feature is wired behind a feature flag stored in the existing
`system_configs` table under key `billing_settings` so we can ship the
code and keep it inert until super-admin flips it on:

    {
        "trial_days": 14,
        "enforce_access_gate": false,
        "max_postpones": 3,
        "extension_days": 30
    }

Rules (only applied when `enforce_access_gate=true`):
  - tenant.status == "suspended"                → blocked (reason: suspended)
  - subscription_ends_at in the past AND
      login_post_expiry_count >= max_postpones  → blocked (too many amânări)
  - subscription_ends_at in the past            → payment_required
  - otherwise                                   → allowed

A valid tenant subscription covers both "trial active" and "paid active":
the difference is only in `tenant.status` ("trial" vs "active"), not in
access — both get `allowed` while `subscription_ends_at` is in the future.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from sqlalchemy import text
from sqlalchemy.orm import Session

from src.models.payment_extension_request import (
    PaymentExtensionRequest,
    EXTENSION_STATUS_PENDING,
)
from src.models.tenant import Tenant


ACCESS_ALLOWED = "allowed"
ACCESS_PAYMENT_REQUIRED = "payment_required"
ACCESS_BLOCKED = "blocked"


BILLING_SETTINGS_KEY = "billing_settings"

DEFAULT_BILLING_SETTINGS = {
    "trial_days": 14,
    "enforce_access_gate": False,  # OFF by default — opt in after verification
    "max_postpones": 3,
    "extension_days": 30,
}


def _ensure_system_config_table(db: Session) -> None:
    db.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS system_configs (
                key VARCHAR PRIMARY KEY,
                value TEXT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
            )
            """
        )
    )
    db.commit()


def get_billing_settings(db: Session) -> dict:
    """Read billing settings from system_configs with defaults. Always
    returns the full schema so callers can rely on keys existing."""
    _ensure_system_config_table(db)
    row = db.execute(
        text("SELECT value FROM system_configs WHERE key = :k"),
        {"k": BILLING_SETTINGS_KEY},
    ).first()
    parsed: dict = {}
    if row and row[0]:
        try:
            parsed = json.loads(row[0]) if isinstance(row[0], str) else row[0]
            if not isinstance(parsed, dict):
                parsed = {}
        except Exception:
            parsed = {}
    out = dict(DEFAULT_BILLING_SETTINGS)
    out.update(parsed)
    # Coerce types so bad values don't explode downstream arithmetic.
    try:
        out["trial_days"] = int(out.get("trial_days", 14))
    except (TypeError, ValueError):
        out["trial_days"] = 14
    try:
        out["max_postpones"] = int(out.get("max_postpones", 3))
    except (TypeError, ValueError):
        out["max_postpones"] = 3
    try:
        out["extension_days"] = int(out.get("extension_days", 30))
    except (TypeError, ValueError):
        out["extension_days"] = 30
    out["enforce_access_gate"] = bool(out.get("enforce_access_gate", False))
    return out


def save_billing_settings(db: Session, settings: dict) -> dict:
    """Merge + persist. Caller is responsible for super-admin auth."""
    _ensure_system_config_table(db)
    current = get_billing_settings(db)
    for k in ("trial_days", "max_postpones", "extension_days"):
        if k in settings:
            try:
                current[k] = int(settings[k])
            except (TypeError, ValueError):
                pass
    if "enforce_access_gate" in settings:
        current["enforce_access_gate"] = bool(settings["enforce_access_gate"])
    db.execute(
        text(
            """
            INSERT INTO system_configs(key, value, updated_at)
            VALUES (:k, :v, CURRENT_TIMESTAMP)
            ON CONFLICT (key)
            DO UPDATE SET value = EXCLUDED.value, updated_at = CURRENT_TIMESTAMP
            """
        ),
        {"k": BILLING_SETTINGS_KEY, "v": json.dumps(current, ensure_ascii=False)},
    )
    db.commit()
    return current


@dataclass
class AccessStatus:
    access: str  # ACCESS_ALLOWED | ACCESS_PAYMENT_REQUIRED | ACCESS_BLOCKED
    reason: Optional[str]
    tenant_status: str
    subscription_plan: Optional[str]
    subscription_ends_at: Optional[datetime]
    days_remaining: int  # 0 when expired; negative not exposed
    is_expired: bool
    login_post_expiry_count: int
    max_postpones: int
    pending_extension_id: Optional[str]
    pending_extension_requested_at: Optional[datetime]
    enforce: bool

    def to_dict(self) -> dict:
        return {
            "access": self.access,
            "reason": self.reason,
            "tenantStatus": self.tenant_status,
            "subscriptionPlan": self.subscription_plan,
            "subscriptionEndsAt": self.subscription_ends_at.isoformat() if self.subscription_ends_at else None,
            "daysRemaining": self.days_remaining,
            "isExpired": self.is_expired,
            "loginPostExpiryCount": self.login_post_expiry_count,
            "maxPostpones": self.max_postpones,
            "pendingExtensionId": self.pending_extension_id,
            "pendingExtensionRequestedAt": self.pending_extension_requested_at.isoformat()
            if self.pending_extension_requested_at
            else None,
            "enforce": self.enforce,
        }


def evaluate(db: Session, tenant: Tenant) -> AccessStatus:
    """Compute the current access state for a tenant. Pure function; does
    not mutate DB."""
    settings = get_billing_settings(db)
    enforce = settings["enforce_access_gate"]
    max_postpones = settings["max_postpones"]

    now = datetime.utcnow()
    ends_at = tenant.subscription_ends_at
    is_expired = ends_at is not None and now > ends_at
    days_remaining = max(0, (ends_at - now).days) if (ends_at and ends_at > now) else 0

    pending = (
        db.query(PaymentExtensionRequest)
        .filter(
            PaymentExtensionRequest.tenant_id == tenant.id,
            PaymentExtensionRequest.status == EXTENSION_STATUS_PENDING,
        )
        .first()
    )

    # Default: allowed. Flip to denied states only if access gate is on.
    access = ACCESS_ALLOWED
    reason: Optional[str] = None

    if enforce:
        if (tenant.status or "").lower() == "suspended":
            access = ACCESS_BLOCKED
            reason = tenant.suspended_reason or "Cont suspendat"
        elif is_expired and int(tenant.login_post_expiry_count or 0) >= int(max_postpones):
            access = ACCESS_BLOCKED
            reason = f"Ai depășit numărul maxim de amânări ({max_postpones})."
        elif is_expired:
            access = ACCESS_PAYMENT_REQUIRED
            reason = "Abonamentul a expirat. Plătește sau cere o amânare."

    return AccessStatus(
        access=access,
        reason=reason,
        tenant_status=tenant.status or "unknown",
        subscription_plan=tenant.subscription_plan,
        subscription_ends_at=ends_at,
        days_remaining=days_remaining,
        is_expired=is_expired,
        login_post_expiry_count=int(tenant.login_post_expiry_count or 0),
        max_postpones=int(max_postpones),
        pending_extension_id=pending.id if pending else None,
        pending_extension_requested_at=pending.requested_at if pending else None,
        enforce=enforce,
    )


def increment_postpone(db: Session, tenant: Tenant) -> AccessStatus:
    """Bump the post-expiry counter. Only valid when the subscription is
    actually expired; otherwise raises ValueError. Caller commits."""
    snap = evaluate(db, tenant)
    if not snap.is_expired:
        raise ValueError("Abonamentul nu este expirat.")
    if snap.login_post_expiry_count >= snap.max_postpones:
        raise ValueError("Ai atins numărul maxim de amânări.")
    tenant.login_post_expiry_count = int(tenant.login_post_expiry_count or 0) + 1
    db.flush()
    return evaluate(db, tenant)


def reset_post_expiry_counter(db: Session, tenant: Tenant, *, reason: str = "payment") -> None:
    """Wipe the postpone counter. Called on successful payment or when
    super-admin approves an extension / marks as paid."""
    tenant.login_post_expiry_count = 0
    tenant.suspended_reason = None
    db.flush()
