"""Picks the right payment provider for a tenant + creates checkout
sessions using a uniform API. Callers (restaurant orders, bookings,
payment link) use this instead of talking to Stripe directly.

Provider selection order:
  1. Explicit `provider_key` passed in (e.g. request body, admin override).
  2. `SiteConfig.preferred_payment_provider` when set and still configured.
  3. Stripe if configured (backward compat for existing tenants).
  4. First other configured provider.

Order reference prefixes keep the unified webhook honest when the
provider only echoes back our ref:
  - restaurant online order → "ro_<id>"
  - restaurant table / pay-at-table → "rt_<id>"
  - accommodation booking → "bk_<id>"
The webhook parses these to route to the right handler.
"""
from __future__ import annotations

import json
import logging
from typing import Optional

from sqlalchemy.orm import Session

from src.models.site_config import SiteConfig
from .payment_providers import (
    PaymentProvider,
    PaymentProviderError,
    get_configured_provider_keys,
    get_provider,
)
from .payment_providers.base import CheckoutSession


logger = logging.getLogger(__name__)


REF_RESTAURANT_ORDER = "ro_"
REF_RESTAURANT_TABLE = "rt_"
REF_BOOKING = "bk_"
REF_FACILITY_BOOKING = "fb_"


def _preferred_provider_key(tenant_id: str, db: Session) -> Optional[str]:
    sc = db.query(SiteConfig).filter(SiteConfig.tenant_id == tenant_id).first()
    if not sc:
        return None
    v = (getattr(sc, "preferred_payment_provider", None) or "").strip().lower() or None
    return v


def resolve_provider_key(
    tenant_id: str,
    db: Session,
    *,
    explicit: Optional[str] = None,
) -> Optional[str]:
    configured = get_configured_provider_keys(tenant_id, db)
    if not configured:
        return None
    if explicit:
        k = explicit.strip().lower()
        if k in configured:
            return k
    preferred = _preferred_provider_key(tenant_id, db)
    if preferred and preferred in configured:
        return preferred
    if "stripe" in configured:
        return "stripe"
    return configured[0]


def resolve_provider(
    tenant_id: str,
    db: Session,
    *,
    explicit: Optional[str] = None,
) -> Optional[PaymentProvider]:
    key = resolve_provider_key(tenant_id, db, explicit=explicit)
    if not key:
        return None
    return get_provider(tenant_id, key, db)


def build_order_ref(kind: str, entity_id: str) -> str:
    prefix = {
        "restaurant_order": REF_RESTAURANT_ORDER,
        "restaurant_table": REF_RESTAURANT_TABLE,
        "booking": REF_BOOKING,
        "facility_booking": REF_FACILITY_BOOKING,
    }.get(kind, "x_")
    return f"{prefix}{entity_id}"


def parse_order_ref(ref: str) -> tuple[str, str]:
    """Return (kind, entity_id) for a ref minted by build_order_ref."""
    if not ref:
        return ("unknown", "")
    for prefix, kind in (
        (REF_RESTAURANT_ORDER, "restaurant_order"),
        (REF_RESTAURANT_TABLE, "restaurant_table"),
        # Facility booking has a `fb_` prefix that doesn't collide with
        # booking's `bk_`, but check it before `bk_` anyway for clarity.
        (REF_FACILITY_BOOKING, "facility_booking"),
        (REF_BOOKING, "booking"),
    ):
        if ref.startswith(prefix):
            return (kind, ref[len(prefix):])
    return ("unknown", ref)


def create_payment_session(
    tenant_id: str,
    db: Session,
    *,
    kind: str,
    entity_id: str,
    amount_minor: int,
    currency: str,
    success_url: str,
    cancel_url: str,
    notify_url: str,
    provider_key: Optional[str] = None,
    customer_email: Optional[str] = None,
    metadata: Optional[dict[str, str]] = None,
) -> tuple[str, CheckoutSession]:
    """Create a checkout session with whichever provider the tenant has
    configured. Returns (provider_key, CheckoutSession)."""
    provider = resolve_provider(tenant_id, db, explicit=provider_key)
    if not provider:
        raise PaymentProviderError("No payment provider configured for this tenant.")

    order_ref = build_order_ref(kind, entity_id)
    md = dict(metadata or {})
    md["tenant_id"] = tenant_id
    md["kind"] = kind
    md["entity_id"] = entity_id
    md["notify_url"] = notify_url

    # Tell the provider where to journal its outbound calls so the
    # admin "Istoric plăți" screen and bank-dispute exports have
    # request/response pairs scoped to the right tenant + booking.
    set_audit = getattr(provider, "set_audit_context", None)
    if callable(set_audit):
        set_audit(db, tenant_id=tenant_id, order_ref=order_ref)

    session = provider.create_checkout_session(
        order_ref=order_ref,
        amount_minor=amount_minor,
        currency=currency,
        success_url=success_url,
        cancel_url=cancel_url,
        metadata=md,
        customer_email=customer_email,
    )
    logger.info(
        "Payment session created: tenant=%s provider=%s kind=%s entity=%s session=%s",
        tenant_id, provider.key, kind, entity_id, session.session_id,
    )
    return provider.key, session
