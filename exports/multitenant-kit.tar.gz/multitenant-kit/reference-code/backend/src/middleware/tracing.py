"""
Request tracing middleware: request_id, tenant_id, response headers, single request-summary log at end.
"""
from __future__ import annotations

import logging
import time
import uuid
from typing import Optional, cast

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from src.core.config import settings
from src.core.request_context import (
    request_id_var,
    tenant_id_var,
    request_method_var,
    request_path_var,
)
from src.core.tenant_resolver import resolve_tenant_id

logger = logging.getLogger(__name__)

HEADER_REQUEST_ID = "x-request-id"
HEADER_TENANT_ID = "x-tenant-id"
HEADER_TENANT = "x-tenant"


def _client_ip(request: Request) -> str:
    """Client IP from X-Forwarded-For (first hop) or request.client."""
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    if request.client:
        return request.client.host or "-"
    return "-"


class RequestTracingMiddleware(BaseHTTPMiddleware):
    """
    Sets request_id (X-Request-Id or generated) and tenant_id in contextvars and request.state.
    Returns X-Request-Id and X-Tenant-Id in response headers.
    Logs a single request-summary line at end: method path status_code duration_ms client_ip.
    """

    async def dispatch(self, request: Request, call_next: object) -> Response:
        request_id: str = request.headers.get(HEADER_REQUEST_ID) or str(uuid.uuid4())
        path = request.url.path or ""
        method = (request.method or "GET").upper()

        # Tenant: request.state.tenant (if set), then headers, then resolver (path, JWT, query, host)
        request_state_tenant: Optional[str] = getattr(
            request.state, "tenant", None
        ) or getattr(request.state, "tenant_id", None)
        if isinstance(request_state_tenant, str) and not request_state_tenant.strip():
            request_state_tenant = None

        x_tenant_id = request.headers.get(HEADER_TENANT_ID)
        x_tenant = request.headers.get(HEADER_TENANT)
        host = request.headers.get("host") or request.url.hostname
        query_tenant_slug = (
            request.query_params.get("tenant_slug") or request.query_params.get("domain")
            if request.query_params
            else None
        )
        tenant_id = resolve_tenant_id(
            request_state_tenant=request_state_tenant,
            x_tenant_id=x_tenant_id,
            x_tenant=x_tenant,
            host=host,
            main_domain=getattr(settings, "MAIN_DOMAIN", None) or "",
            path=path,
            query_tenant_slug=query_tenant_slug,
            authorization=request.headers.get("authorization"),
            secret_key=getattr(settings, "SECRET_KEY", "") or "",
            algorithm=getattr(settings, "ALGORITHM", "HS256") or "HS256",
        )

        token_id = request_id_var.set(request_id)
        token_tenant = tenant_id_var.set(tenant_id)
        token_path = request_path_var.set(path)
        token_method = request_method_var.set(method)
        request.state.request_id = request_id  # type: ignore[attr-defined]
        request.state.tenant_id = tenant_id   # type: ignore[attr-defined]

        start = time.perf_counter()
        response: Optional[Response] = None
        status_code = 500
        try:
            response = await call_next(request)  # type: ignore[misc]
            status_code = response.status_code
        except Exception:
            status_code = 500
            raise
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            client_ip = _client_ip(request)
            request_id_var.reset(token_id)
            tenant_id_var.reset(token_tenant)
            request_path_var.reset(token_path)
            request_method_var.reset(token_method)
            # Single request-summary line (formatter adds timestamp, req=, tenant=, logger=)
            logger.info(
                "%s %s %s %.0fms %s",
                method,
                path,
                status_code,
                duration_ms,
                client_ip,
                extra={
                    "method": method,
                    "path": path,
                    "status_code": status_code,
                    "duration_ms": round(duration_ms, 2),
                    "client_ip": client_ip,
                },
            )

        if response is not None:
            response.headers[HEADER_REQUEST_ID] = request_id
            response.headers[HEADER_TENANT_ID] = tenant_id
        return cast(Response, response)
